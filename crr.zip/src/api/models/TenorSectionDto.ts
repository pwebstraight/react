/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { GraphDto } from './GraphDto';
import type { OrderDto } from './OrderDto';
import type { TradeDto } from './TradeDto';

export type TenorSectionDto = {
    tenorId?: number;
    instrumentId?: number;
    tenorLabel?: string | null;
    isTest?: boolean;
    pricingDescription?: string | null;
    orderGraph?: GraphDto;
    tradeGraph?: GraphDto;
    price?: number | null;
    hours?: number;
    orders?: Array<OrderDto> | null;
    trades?: Array<TradeDto> | null;
};
