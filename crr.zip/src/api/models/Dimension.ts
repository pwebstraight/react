/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum Dimension {
    ENERGY = 'Energy',
    CURRENCY = 'Currency',
    POWER = 'Power',
}
