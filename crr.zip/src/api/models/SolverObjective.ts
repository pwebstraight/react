/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum SolverObjective {
    MAX_VOLUME = 'MaxVolume',
    MAX_PARTICIPATION = 'MaxParticipation',
}
