/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum ParticipationStatus {
    INACTIVE = 'Inactive',
    ACTIVE = 'Active',
}
