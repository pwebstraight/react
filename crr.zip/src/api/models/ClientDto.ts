/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EmailDto } from './EmailDto';
import type { LiveStatus } from './LiveStatus';
import type { ParticipationStatus } from './ParticipationStatus';

export type ClientDto = {
    clientId?: number;
    clientName?: string | null;
    trayportName?: string | null;
    shortName?: string | null;
    currentParticipationStatus?: ParticipationStatus;
    emails?: Array<EmailDto> | null;
    currentLiveStatus?: LiveStatus;
    isExchange?: boolean;
    trayportCompanyId?: number;
    trayportExchangeInstrumentId?: number | null;
};
