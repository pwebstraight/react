/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ClientDto } from './ClientDto';
import type { TenorSectionDto } from './TenorSectionDto';

export type SolverResultDto = {
    runId?: number;
    tenorSections?: Array<TenorSectionDto> | null;
    clients?: Array<ClientDto> | null;
};
