/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ValueDto } from './ValueDto';

export type GraphArcDto = {
    tenorId?: number;
    sellerId?: number;
    buyerId?: number;
    buyOrder?: ValueDto;
    sellOrder?: ValueDto;
    matchOrder?: ValueDto;
    trade?: ValueDto;
    isBottleneck?: boolean;
    isDry?: boolean;
    isSameDirection?: boolean;
    isOrphan?: boolean;
};
