/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ParticipatingClientsDto } from './ParticipatingClientsDto';
import type { TenorDto } from './TenorDto';
import type { TradeStatus } from './TradeStatus';
import type { ValueDto } from './ValueDto';

export type TradeDto = {
    id?: number;
    sellerId?: number;
    buyerId?: number;
    runId?: number;
    seller?: ParticipatingClientsDto;
    buyer?: ParticipatingClientsDto;
    buyerTraderId?: number;
    buyerTraderName?: string | null;
    sellerTraderId?: number;
    sellerTraderName?: string | null;
    tenorId?: number;
    tenorLabel?: number;
    tenor?: TenorDto;
    instrumentId?: number;
    instrumentName?: string | null;
    tradeDate?: string;
    value?: ValueDto;
    buyOrder?: ValueDto;
    sellOrder?: ValueDto;
    matchOrder?: ValueDto;
    price?: number | null;
    executionTimestamp?: string | null;
    status?: TradeStatus;
};
