/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type InstrumentDto = {
    instrumentId?: number;
    instrumentName?: string | null;
    instrumentShortName?: string | null;
    market?: string | null;
    unitId?: number;
    currencyId?: number;
    flowRateUnitId?: number;
    pricing?: string | null;
};
