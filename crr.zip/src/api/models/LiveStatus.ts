/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum LiveStatus {
    TEST = 'Test',
    LIVE = 'Live',
}
