/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum EmailTemplateType {
    SUBMISSION = 'Submission',
    ANALYSIS = 'Analysis',
}
