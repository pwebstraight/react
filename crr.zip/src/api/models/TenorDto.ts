/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { TenorType } from './TenorType';

export type TenorDto = {
    tenorId?: number;
    tenorLabel?: string | null;
    originalLabel?: string | null;
    tenorType?: TenorType;
    tradingStart?: string;
    tradingEnd?: string;
    periodStart?: string;
    periodEnd?: string;
    hours?: number;
    market?: string | null;
    readonly groupingOrderKey?: number;
};
