/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EmailTemplateType } from './EmailTemplateType';

export type EmailTemplateDto = {
    emailTemplateId?: number;
    subject?: string | null;
    body?: string | null;
    emailTemplateType?: EmailTemplateType;
    runId?: number | null;
};
