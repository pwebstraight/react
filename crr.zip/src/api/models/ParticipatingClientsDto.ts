/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { LiveStatus } from './LiveStatus';
import type { ParticipationStatus } from './ParticipationStatus';
import type { SubmissionStatus } from './SubmissionStatus';

export type ParticipatingClientsDto = {
    clientParticipationId?: number;
    runId?: number;
    clientId?: number;
    clientName?: string | null;
    shortName?: string | null;
    isExchange?: boolean;
    isActive?: ParticipationStatus;
    status?: LiveStatus;
    submissionStatus?: SubmissionStatus;
    receivedDate?: string | null;
    statusDate?: string | null;
    errorMessage?: string | null;
};
