/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserRole } from './UserRole';

export type UserDto = {
    userId?: number;
    isActive?: boolean;
    emailAddress?: string | null;
    firstName?: string | null;
    lastName?: string | null;
    role?: UserRole;
};
