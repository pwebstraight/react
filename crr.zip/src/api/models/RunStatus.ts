/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum RunStatus {
    CREATED = 'Created',
    IN_PROGRESS = 'InProgress',
    DONE = 'Done',
    CANCELLED = 'Cancelled',
    TRANSIENT = 'Transient',
}
