/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type SelectedTenorsDto = {
    selectedTenorIds?: Array<number> | null;
    runId?: number;
};
