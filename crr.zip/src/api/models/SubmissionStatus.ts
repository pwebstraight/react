/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum SubmissionStatus {
    PENDING = 'Pending',
    SENT = 'Sent',
    RECEIVED = 'Received',
    IN_ERROR = 'InError',
    CONFIRMED = 'Confirmed',
}
