/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { GraphArcDto } from './GraphArcDto';

export type GraphDto = {
    arcs?: Array<GraphArcDto> | null;
};
