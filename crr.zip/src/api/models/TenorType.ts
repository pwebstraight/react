/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum TenorType {
    NONE = 'None',
    BOM = 'BOM',
    WEEK = 'Week',
    MONTH = 'Month',
    QUARTER = 'Quarter',
    SEASON = 'Season',
    YEAR = 'Year',
}
