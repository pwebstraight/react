/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EmailTemplateDto } from './EmailTemplateDto';

export type SendEmailRequestDto = {
    runId?: number;
    selectedParticipants?: Array<number> | null;
    emailTemplates?: Array<EmailTemplateDto> | null;
};
