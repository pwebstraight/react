/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Dimension } from './Dimension';

export type ValueDto = {
    originalDimension?: Dimension;
    volume?: number | null;
    notional?: number | null;
    total?: number | null;
};
