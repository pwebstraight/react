/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type FileResponse = {
    fileName?: string | null;
    contentType?: string | null;
    content?: string | null;
};
