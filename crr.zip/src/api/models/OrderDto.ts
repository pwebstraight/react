/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ClientDto } from './ClientDto';
import type { Dimension } from './Dimension';
import type { ValueDto } from './ValueDto';

export type OrderDto = {
    orderId?: number;
    unitId?: number;
    dimension?: Dimension;
    flowRateUnit?: string | null;
    totalUnit?: string | null;
    notionalUnit?: string | null;
    clientSubmissionId?: number;
    counterpartyId?: number;
    client?: ClientDto;
    counterParty?: ClientDto;
    tenorId?: number;
    value?: ValueDto;
    isOrphan?: boolean;
};
