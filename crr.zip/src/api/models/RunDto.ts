/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EmailTemplateDto } from './EmailTemplateDto';
import type { InstrumentDto } from './InstrumentDto';
import type { RunStatus } from './RunStatus';
import type { SolverObjective } from './SolverObjective';
import type { TenorDto } from './TenorDto';

export type RunDto = {
    runId?: number;
    instrument?: InstrumentDto;
    broker?: string | null;
    creationDate?: string;
    tradeDate?: string;
    solverObjective?: SolverObjective;
    minOrderSize?: number;
    maxOrderSize?: number;
    minTradeSize?: number;
    runStatus?: RunStatus;
    emailTemplates?: Array<EmailTemplateDto> | null;
    tenors?: Array<TenorDto> | null;
};
