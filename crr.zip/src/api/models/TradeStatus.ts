/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum TradeStatus {
    PENDING = 'Pending',
    DONE = 'Done',
    IN_ERROR = 'InError',
}
