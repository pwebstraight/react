/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type SetTenorPriceRequest = {
    runId?: number;
    tenorId?: number;
    price?: number | null;
    includeTest?: boolean;
};
