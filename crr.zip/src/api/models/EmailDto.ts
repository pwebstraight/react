/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type EmailDto = {
    emailId?: number;
    clientId?: number;
    emailAddress?: string | null;
    isContact?: boolean;
    isSubmission?: boolean;
    isCustomer?: boolean;
    isTrader?: boolean;
    traderId?: number | null;
    traderName?: string | null;
    description?: string | null;
};
