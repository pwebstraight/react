/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InstrumentDto } from '../models/InstrumentDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class InstrumentService {

    /**
     * @returns InstrumentDto Success
     * @throws ApiError
     */
    public static postApiInstrumentGetInstruments(): CancelablePromise<Array<InstrumentDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Instrument/GetInstruments',
        });
    }

}
