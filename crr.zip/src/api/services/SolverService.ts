/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SetTenorPriceRequest } from '../models/SetTenorPriceRequest';
import type { SolverResultDto } from '../models/SolverResultDto';
import type { TenorSectionDto } from '../models/TenorSectionDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class SolverService {

    /**
     * @param requestBody 
     * @returns SolverResultDto Success
     * @throws ApiError
     */
    public static postApiSolverRunLiveSolver(
requestBody?: number,
): CancelablePromise<SolverResultDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Solver/RunLiveSolver',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns SolverResultDto Success
     * @throws ApiError
     */
    public static postApiSolverRunTestSolver(
requestBody?: number,
): CancelablePromise<SolverResultDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Solver/RunTestSolver',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns TenorSectionDto Success
     * @throws ApiError
     */
    public static postApiSolverSetTenorPrice(
requestBody?: SetTenorPriceRequest,
): CancelablePromise<TenorSectionDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Solver/SetTenorPrice',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
