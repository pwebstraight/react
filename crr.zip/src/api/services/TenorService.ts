/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RunDto } from '../models/RunDto';
import type { SelectedTenorsDto } from '../models/SelectedTenorsDto';
import type { TenorDto } from '../models/TenorDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class TenorService {

    /**
     * @param requestBody 
     * @returns TenorDto Success
     * @throws ApiError
     */
    public static postApiTenorGetTenors(
requestBody?: RunDto,
): CancelablePromise<Array<TenorDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Tenor/GetTenors',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiTenorSaveSelectedTenors(
requestBody?: SelectedTenorsDto,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Tenor/SaveSelectedTenors',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
