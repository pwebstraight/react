/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ParticipatingClientsDto } from '../models/ParticipatingClientsDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ClientParticipationService {

    /**
     * @param requestBody 
     * @returns ParticipatingClientsDto Success
     * @throws ApiError
     */
    public static postApiClientParticipationGetParticipants(
requestBody?: number,
): CancelablePromise<Array<ParticipatingClientsDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/ClientParticipation/GetParticipants',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns ParticipatingClientsDto Success
     * @throws ApiError
     */
    public static postApiClientParticipationUpdateClientParticipant(
requestBody?: ParticipatingClientsDto,
): CancelablePromise<ParticipatingClientsDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/ClientParticipation/UpdateClientParticipant',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
