/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SendEmailRequestDto } from '../models/SendEmailRequestDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class MailService {

    /**
     * @param requestBody 
     * @returns string Success
     * @throws ApiError
     */
    public static postApiMailSendMailWithAttachment(
requestBody?: SendEmailRequestDto,
): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Mail/SendMailWithAttachment',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiMailSendConfirmationEmails(
requestBody?: SendEmailRequestDto,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Mail/SendConfirmationEmails',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @returns any Success
     * @throws ApiError
     */
    public static postApiMailReceiveEmails(): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Mail/ReceiveEmails',
        });
    }

}
