/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RunDto } from '../models/RunDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class RunService {

    /**
     * @returns RunDto Success
     * @throws ApiError
     */
    public static postApiRunGetRuns(): CancelablePromise<Array<RunDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Run/GetRuns',
        });
    }

    /**
     * @param requestBody 
     * @returns RunDto Success
     * @throws ApiError
     */
    public static postApiRunCreateRun(
requestBody?: RunDto,
): CancelablePromise<RunDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Run/CreateRun',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiRunCancelRun(
requestBody?: number,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Run/CancelRun',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiRunCompleteRun(
requestBody?: number,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Run/CompleteRun',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiRunUpdateRun(
requestBody?: RunDto,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Run/UpdateRun',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
