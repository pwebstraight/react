/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { FileResponse } from '../models/FileResponse';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class OrderSheetService {

    /**
     * @param requestBody 
     * @returns FileResponse Success
     * @throws ApiError
     */
    public static postApiOrderSheetGenerateTestOrderSheet(
requestBody?: number,
): CancelablePromise<FileResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/OrderSheet/GenerateTestOrderSheet',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns FileResponse Success
     * @throws ApiError
     */
    public static postApiOrderSheetGenerateLiveOrderSheet(
requestBody?: number,
): CancelablePromise<FileResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/OrderSheet/GenerateLiveOrderSheet',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
