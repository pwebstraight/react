/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RunDto } from '../models/RunDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class EmailTemplateService {

    /**
     * @param requestBody 
     * @returns RunDto Success
     * @throws ApiError
     */
    public static postApiEmailTemplateGetDefaultEmailTemplates(
requestBody?: number,
): CancelablePromise<RunDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/EmailTemplate/GetDefaultEmailTemplates',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiEmailTemplateAddDefaultEmailTemplates(
requestBody?: RunDto,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/EmailTemplate/AddDefaultEmailTemplates',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
