import { useCallback, useEffect } from "react";
import { useRoutes, useNavigate } from 'react-router-dom';
import router from 'src/router';
import 'devextreme/dist/css/dx.light.css';
import { useAppDispatch, useAppSelector } from "src/store/configureStore";
import OktaAuth, { toRelativeUrl } from '@okta/okta-auth-js';
import { Security } from '@okta/okta-react';
import { CssBaseline } from '@mui/material';
import ThemeProvider from './theme/ThemeProvider';
import { getCurrentUser } from "src/store/userSlice";
import { SidebarProvider } from "./contexts/SidebarContext";
import Hub, { SubscribeToNotifications } from "./api/Hub";
import { Store } from "./store/storeUtils";
import { RunDto } from "./api/models/RunDto";
import React from "react";


export const RunContext = React.createContext<Store<RunDto>>(new Store<RunDto>());

function App(props: { oktaAuth: OktaAuth })
{
    const navigate = useNavigate();
    const content = useRoutes(router);
    const dispatch = useAppDispatch();
    const { user } = useAppSelector(state => state.user);

    const restoreOriginalUri = (_oktaAuth, originalUri) =>
    {
        navigate(toRelativeUrl(originalUri || '/', window.location.origin));
    };

    const initApp = useCallback(async () =>
    {
        if (!await props.oktaAuth.isAuthenticated())
        {
            await props.oktaAuth.signInWithRedirect({ originalUri: window.location.origin });
        }
        else
        {
            if (!user)
            {
                await dispatch(getCurrentUser());
            }

            if (!Hub.SignalRConnection)
            {
                SubscribeToNotifications(props.oktaAuth);
            }
        }
    }, [SubscribeToNotifications, getCurrentUser, dispatch]);

    useEffect(() =>
    {
        initApp().then();
    }, [initApp])

    return (
        <Security oktaAuth={props.oktaAuth} restoreOriginalUri={restoreOriginalUri}>
            <SidebarProvider>
                <ThemeProvider>
                    <CssBaseline />
                    {content}
                </ThemeProvider>
            </SidebarProvider>
        </Security>
    );
}

export default App;
