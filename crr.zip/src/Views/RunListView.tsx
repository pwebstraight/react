import { currentTabContext, participatingClientsTab, runDetailTab, runListContext, selectedRunContext } from '../pages/runPage';
import { useState, ReactComponentElement, useContext } from 'react';

import { Button } from '@mui/material';

import DataGrid, {
    Column,
    Editing,
    Paging,
    HeaderFilter,
    Selection
} from 'devextreme-react/data-grid';
import { RunDto, RunStatus, SolverObjective } from 'src/api';
import { RowClickEvent } from 'devextreme/ui/data_grid';
import { usePropertyContext } from '../components/Property';

function RunListView() : ReactComponentElement<any>
{
    const [runList] = usePropertyContext(runListContext);
    const [selectedRun, setSelectedRun] = usePropertyContext(selectedRunContext);
    const [currentTab, setCurrentTab] = usePropertyContext(currentTabContext);

    if (runList == null) return (<> Loading...</>);

    const [selectedRowKeys, setSelectedRowKeys] = useState<number[]>(null);

    function onRowClick(e: RowClickEvent<RunDto>)
    {
        const value = e.data;
        setSelectedRowKeys([value.runId]);
        setSelectedRun(value);
        setCurrentTab(participatingClientsTab);
    }

    function createNewRun()
    {
        setSelectedRun(
        {
            runId: 0,
            instrument: {},
            broker: '',
            tradeDate: '',
            runStatus: RunStatus.TRANSIENT,
            solverObjective: SolverObjective.MAX_VOLUME,
            minOrderSize: 0,
            maxOrderSize: 0,
            minTradeSize: 0,
            emailTemplates: [],
            tenors: []
        });
        setCurrentTab(runDetailTab);
    }

    function determineRunStatus(run: RunDto)
    {
        switch (run.runStatus)
        {
        case RunStatus.CREATED:
            return {
                text: 'Created',
                colour: '#5191ff'
            };
        case RunStatus.IN_PROGRESS:
            return {
                text: 'In Progress',
                colour: 'orange'
            };
        case RunStatus.DONE:
            return {
                text: 'Done',
                colour: '#2ecc71'
            };
        case RunStatus.CANCELLED:
            return {
                text: 'Cancelled',
                colour: '#ff435c'
            };
        default:
            return {
                text: 'Unknown',
                colour: 'red'
            };
        }
    }

    function RunStatusCell(cellInfo: { data: RunDto })
    {
        const { colour, text } = determineRunStatus(cellInfo.data);

        return (
            <div
                className="submissionStatus"
                style={{
                    backgroundColor: colour,
                    boxShadow: '0 1px 4px rgba(0,0,0,.6)'
                }}
            >
                { text }
            </div>
        );
    }

    return (
        <>
            <Button
                variant="outlined"
                color="secondary"
                onClick={createNewRun}
                style={{ marginRight: "20px" }}
            >
                Create New Run
            </Button>
            <div style={{ marginTop: '10px' }}>
                <DataGrid
                    dataSource={runList}
                    keyExpr="runId"
                    showBorders={true}
                    selectedRowKeys={selectedRowKeys}
                    onRowClick={onRowClick}
                    sorting={{ mode: 'single', showSortIndexes: false }}
                >
                    <Selection mode="single" />
                    <HeaderFilter visible={true} />
                    <Paging enabled={false} />
                    <Editing
                        mode="row"
                        useIcons={true}
                        allowUpdating={false}
                        allowAdding={false}
                    />
                    <Column
                        dataField="instrument.instrumentName"
                        caption="Instrument"
                        alignment="left"
                        width={350}
                    />
                    <Column
                        dataField="creationDate"
                        caption="Creation Date"
                        dataType={'date'}
                        format="d MMM yyyy"
                        sortIndex={0}
                        sortOrder={'desc'}
                        alignment="left"
                        width={155}
                    />
                    <Column
                        caption="Status"
                        cellRender={RunStatusCell}
                        alignment="left"
                        width={155}
                    />
                    <Column
                        dataField="broker"
                        caption="Broker"
                        alignment="left"
                        width={250}
                    />
                    <Column
                        dataField="tradeDate"
                        caption="Trade Date"
                        dataType={'date'}
                        format="d MMM yyyy"
                        alignment="left"
                        width={200}
                    />
                </DataGrid>
            </div>
        </>
    );
}

export { RunListView };