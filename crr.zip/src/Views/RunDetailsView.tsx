import { ReactComponentElement, useContext, useState } from 'react';
import { selectedRunContext, instrumentsContext, tenorListTab, currentTabContext } from '../pages/runPage';
import
{
    TextField,
    Box,
    FormControl,
    Select,
    MenuItem,
    SelectChangeEvent
} from '@mui/material';
import { RunService, RunStatus } from '../api';
import moment from 'moment';
import AsyncButton from '../components/AsyncButton';
import { usePropertyContext } from '../components/Property';


function RunDetailsView(): ReactComponentElement<any>
{
    const [selectedRun, setSelectedRun] = usePropertyContext(selectedRunContext);
    const [currentTab, setCurrentTab] = usePropertyContext(currentTabContext);

    if (selectedRun == null) return (<></>);

    const [run, setRun] = useState(selectedRun);

    const instruments = useContext(instrumentsContext);

    function isInvalid()
    {
        return Object.values(run).some(value => value === null || value === '') ||
            run.instrument.instrumentId === 0 ||
            run.minTradeSize < 0 ||
            parseInt(run.maxOrderSize.toString()) <= parseInt(run.minOrderSize.toString()) ||
            parseInt(run.minTradeSize.toString()) > parseInt(run.minOrderSize.toString()) ||
            run.runId != 0;
    }

    async function saveRun()
    {
        setSelectedRun(await RunService.postApiRunCreateRun(run));
        setCurrentTab(tenorListTab);
    }

    function handleChange(e)
    {
        const { name, value } = e.target;
        setRun({ ...run, [name]: value });
    }

    function onInstrumentChanged(e: SelectChangeEvent<number>)
    {
        const id = e.target.value;
        const instrument = instruments.find(i => i.instrumentId == id);
        setRun({ ...run, instrument: instrument });
    }

    return (
        <Box
            sx={{
                display: 'grid',
                columnGap: 3,
                rowGap: 1,
                gridTemplateColumns: 'repeat(2, 1fr)',
                gridTemplateRows: 'repeat(8, 1fr)'
            }}
            style={{ marginTop: '10px', width : '1000px' }}
        >
            <b>Instrument:</b>

            <FormControl
                placeholder='Select ...'
                size="small"
                fullWidth
                variant="outlined"
            >
                <Select
                    value={run.instrument.instrumentId}
                    onChange={onInstrumentChanged}
                    inputProps={{ readOnly: run.runId != 0 }}
                >
                    {instruments.map(instrument => (
                        <MenuItem key={instrument.instrumentId} value={instrument.instrumentId}>
                        {instrument.instrumentName}
                    </MenuItem>
                 )) }
                </Select>
            </FormControl>
            <b>Broker:</b>
            <TextField
                name="broker"
                type="string"
                fullWidth={true}
                size="small"
                value={run.broker}
                InputLabelProps={{ shrink: true }}
                inputProps={{ readOnly: run.runId != 0 }}
                onInputCapture={handleChange}
            />
            <b>Trade Date:</b>
            <TextField
                name="tradeDate"
                type="date"
                InputProps={{
                    inputProps: {
                        min: moment(Date.now() + 3600 * 1000 * 24 * 7).format('YYYY-MM-DD'),
                        readOnly: run.runId != 0
                    }
                }} //sets min trade date to a week from today
                size="small"
                defaultValue={moment(run.tradeDate).format('YYYY-MM-DD')}
                fullWidth={true}
                InputLabelProps={{ shrink: true }}
                onChange={handleChange}
            />
            <b>Solver Objective:</b>
            <FormControl
                placeholder='Select ...'
                size="small"
                fullWidth
                variant="outlined"
            >
                <Select
                    name="solverObjective"
                    value={run.solverObjective}
                    onChange={handleChange}
                    inputProps={{
                        readOnly: run.runId != 0
                    }}
                >
                    <MenuItem value="MaxVolume">Max Volume</MenuItem>
                    <MenuItem value="MaxParticipation">
                        Max Participation
                    </MenuItem>
                </Select>
            </FormControl>
            <b>Minimum Order Size:</b>
            <TextField
                name="minOrderSize"
                type="number"
                fullWidth={true}
                size="small"
                value={run.minOrderSize}
                InputLabelProps={{
                    shrink: true
                }}
                InputProps={{
                    inputProps: { min: 0 },
                    readOnly: run.runId != 0
                }}
                onChange={handleChange}
            />
            <b>Maximum Order Size:</b>
            <TextField
                name="maxOrderSize"
                type="number"
                fullWidth={true}
                size="small"
                value={run.maxOrderSize}
                InputLabelProps={{
                    shrink: true
                }}
                InputProps={{
                    inputProps: { min: 0 },
                    readOnly: run.runId != 0
                }}
                onChange={handleChange}
            />
            <b>Minimum Trade Size:</b>
            <TextField
                className="minTradeSize"
                name="minTradeSize"
                type="number"
                value={run.minTradeSize}
                fullWidth={true}
                size="small"
                InputLabelProps={{
                    shrink: true
                }}
                InputProps={{
                    inputProps: { min: 0 },
                    readOnly: run.runId != 0
                }}
                onChange={handleChange}
            />
            <AsyncButton
                variant="contained"
                size="large"
                style={{ display: run.runStatus == RunStatus.TRANSIENT ? "block" : "none" }}
                disabled={isInvalid()}
                onClick={saveRun}
            >
                Save
            </AsyncButton>
        </Box >
    );
}

export { RunDetailsView };