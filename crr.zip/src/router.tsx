import { Suspense, lazy } from 'react';
import { Navigate } from 'react-router-dom';
import { RouteObject } from 'react-router';
import { LoginCallback } from '@okta/okta-react';
import SidebarLayout from 'src/layouts/SidebarLayout';
import { RequiredAuth } from 'src/components/SecureRoute';

import SuspenseLoader from 'src/components/SuspenseLoader';

const Loader = (Component) => (props) =>
  (
    <Suspense fallback={<SuspenseLoader />}>
      <Component {...props} />
    </Suspense>
  );

// Pages

const Clients = Loader(lazy(() => import('src/pages/clientAdminScreen')));
const Runs = Loader(lazy(() => import('src/pages/runPage')));
const Users = Loader(lazy(() => import('src/pages/users')));


const Status404 = Loader(
  lazy(() => import('src/pages/status404'))
);

const routes: RouteObject[] = [
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/',
        element: <RequiredAuth />,
        children: [
          {
            path: '/',
            element: <Runs />
          },
          {
            path: 'home',
            element: <Navigate to="/" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  }, 
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/clients',
        element: <RequiredAuth />,
        children: [
          {
            path: '/clients',
            element: <Clients />
          },
          {
            path: 'runs',
            element: <Navigate to="/runs" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  },
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/runs',
        element: <RequiredAuth />,
        children: [
          {
            path: '/runs',
            element: <Runs />
          },
          {
            path: 'runs',
            element: <Navigate to="/runs" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  },  
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/users',
        element: <RequiredAuth />,
        children: [
          {
            path: '/users',
            element: <Users />
          },
          {
            path: 'users',
            element: <Navigate to="/users" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  },   
  {
    path: '',
    element: <SidebarLayout />,
    children: [
      {
        path: 'login/callback',
        element: <LoginCallback />
      },
      {
        path: 'loginCallback',
        element: <Navigate to="/" />
      }      
    ]
  },    
];

export default routes;
