import { useRef, useState } from 'react';
import { useOktaAuth } from '@okta/okta-react';
import {  
  Box,
  Button,
  Divider,
  Hidden,
  lighten,
  Popover,
  Typography
} from '@mui/material';

import { styled } from '@mui/material/styles';
import ExpandMoreTwoToneIcon from '@mui/icons-material/ExpandMoreTwoTone';
import LockOpenTwoToneIcon from '@mui/icons-material/LockOpenTwoTone';
import { useAppSelector } from "src/store/configureStore";

const UserBoxButton = styled(Button)(
  ({ theme }) => `
        padding-left: ${theme.spacing(1)};
        padding-right: ${theme.spacing(1)};
`
);

const MenuUserBox = styled(Box)(
  ({ theme }) => `
        background: ${theme.colors.alpha.black[5]};
        padding: ${theme.spacing(2)};
`
);

const UserBoxText = styled(Box)(
  ({ theme }) => `
        text-align: left;
        padding-left: ${theme.spacing(1)};
`
);

const UserBoxLabel = styled(Typography)(
  ({ theme }) => `
        font-weight: ${theme.typography.fontWeightBold};
        color: white;
        display: block;
`
);

const UserBoxLabelBlack = styled(Typography)(
  ({ theme }) => `        
      color: 'black';        
`
);

const UserBoxDescription = styled(Typography)(
  ({ theme }) => `
        color: ${lighten(theme.palette.secondary.main, 0.5)}
`
);

function HeaderUserbox() {

  const { user } = useAppSelector(state => state.user);
  
  const { authState, oktaAuth } = useOktaAuth();
  const ref = useRef<any>(null);
  const [isOpen, setOpen] = useState<boolean>(false);

  const handleOpen = (): void => {
    setOpen(true);
  };

  const handleClose = (): void => {
    setOpen(false);
  };

  const logout = async () => {
    await oktaAuth.signOut();
  };

  return (
    <>    
      {user &&  
        <> 
        <UserBoxButton color="secondary" ref={ref} onClick={handleOpen}>        
          <Hidden mdDown>
            <UserBoxText>
              <UserBoxLabel variant="body1">{user.emailAddress}</UserBoxLabel>
              <UserBoxDescription variant="body2">
                {user.role}
              </UserBoxDescription>
            </UserBoxText>
          </Hidden>
          <Hidden smDown>
            <ExpandMoreTwoToneIcon sx={{ ml: 1 }} style={{color: 'white'}} />
          </Hidden>
        </UserBoxButton>
        <Popover
          anchorEl={ref.current}
          onClose={handleClose}
          open={isOpen}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right'
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right'
          }}
        >
          <MenuUserBox sx={{ minWidth: 210 }} display="flex">          
            <UserBoxText>
              <UserBoxLabelBlack variant="body1">{user.emailAddress}</UserBoxLabelBlack>
              <UserBoxDescription variant="body2">
                {user.role}
              </UserBoxDescription>
            </UserBoxText>
          </MenuUserBox>
          <Divider sx={{ mb: 0 }} />
          
          <Divider />
          <Box sx={{ m: 1 }}>
            <Button color="primary" fullWidth onClick={logout}>
              <LockOpenTwoToneIcon sx={{ mr: 1 }} />
              Sign out
            </Button>
          </Box>
        </Popover> 
        </>
      }  
    </>       
  );
}

export default HeaderUserbox;
