import { useState, useEffect, useRef } from 'react';
import { useAppDispatch, useAppSelector } from "src/store/configureStore";
import { UserNotification } from 'src/models/userNotification';
import { addNotification, saveNotifications } from "src/store/notificationSlice";
import Hub from "src/api/Hub";
import { alpha, Badge, Box, Divider, IconButton, List, ListItem, Popover, Tooltip, Typography } from '@mui/material';
import NotificationsActiveTwoToneIcon from '@mui/icons-material/NotificationsActiveTwoTone';
import { styled } from '@mui/material/styles';
import { formatDistance, subMinutes } from 'date-fns';

const NotificationsBadge = styled(Badge)(
  ({ theme }) => `
    
    .MuiBadge-badge {
        background-color: ${alpha(theme.palette.error.main, 0.1)};
        color: white;
        min-width: 16px; 
        height: 16px;
        padding: 0;

        &::after {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            box-shadow: white;
            content: "";
        }
    }
`
);

function HeaderNotifications() {
  const ref = useRef<any>(null);
  const [isOpen, setOpen] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const { userNotifications } = useAppSelector(state => state.userNotifications);

  useEffect(() => {

    if (Hub.SignalRConnection) {

      Hub.SignalRConnection.on("ReceiveNotification", (notificationMessage) => {
        var notification: UserNotification = notificationMessage;
        notification.isNew = true;
        dispatch(addNotification(notification));

      });
    }
  }, [Hub.SignalRConnection]);

  const handleOpen = (): void => {
    const allNotifications: UserNotification[] = [...userNotifications];
    let readNotifications = [];
    allNotifications.forEach((currentNotification: UserNotification) => {

      var readNotification = {
        message: currentNotification.message,
        description: currentNotification.description,
        user: currentNotification.user,
        dateCreated: currentNotification.dateCreated,
        isNew: false,
      }
      readNotifications.push(readNotification);
    });

    setOpen(true);

    dispatch(saveNotifications(readNotifications));
  };

  const handleClose = (): void => {
    setOpen(false);
  };

  return (
    <>
      <Tooltip arrow title="Notifications">
        <IconButton ref={ref} onClick={handleOpen}>
          <NotificationsBadge
            style={{ color: 'white' }}
            badgeContent={userNotifications.filter(n => n.isNew).length}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right'
            }}
          >
            <NotificationsActiveTwoToneIcon style={{ color: 'white' }} />
          </NotificationsBadge>
        </IconButton>
      </Tooltip>
      <Popover
        anchorEl={ref.current}
        onClose={handleClose}
        open={isOpen}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right'
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right'
        }}
      >
        <Box
          sx={{ p: 2 }}
          display="flex"
          alignItems="center"
          justifyContent="space-between"
        >
          <Typography variant="h5">Notifications</Typography>
        </Box>
        <Divider />
        <List sx={{ p: 0 }}>

          {userNotifications.map((notification, index) => (
            <ListItem key={index}
              sx={{ p: 2, minWidth: 350, display: { xs: 'block', sm: 'flex' } }}
            >
              <Box flex="1">
                <Box display="flex" justifyContent="space-between">
                  <Typography sx={{ fontWeight: 'bold' }}>
                    {notification.message}
                  </Typography>
                  <Typography variant="caption" sx={{ textTransform: 'none' }}>
                    {formatDistance(subMinutes(new Date(notification.dateCreated), 0), new Date(), {
                      addSuffix: true
                    })}
                  </Typography>
                </Box>
                {notification.user &&
                  <Typography
                    component="span"
                    variant="body2"
                    color="text.secondary"
                  >
                    {' '}
                    created by {notification.user.split('@')[0]}
                  </Typography>
                }
                {notification.description &&
                  <Box display="flex" justifyContent="space-between">
                    <Typography
                      component="span"
                      variant="body2"
                      color="text.secondary"
                    >
                      {' '}
                      {notification.description}
                    </Typography>
                  </Box>
                }
              </Box>
            </ListItem>
          ))}
        </List>
      </Popover>
    </>
  );
}

export default HeaderNotifications;
