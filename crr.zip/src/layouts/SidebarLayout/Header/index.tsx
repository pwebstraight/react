import { useState, useContext, useEffect } from 'react';
import { UserNotification } from 'src/models/userNotification';
import Hub from "src/api/Hub";

import {
  Box,
  alpha,
  Stack,
  lighten,
  Divider,
  IconButton,
  Tooltip,
  styled,
  useTheme
} from '@mui/material';
import MenuTwoToneIcon from '@mui/icons-material/MenuTwoTone';
import { SidebarContext } from 'src/contexts/SidebarContext';
import CloseTwoToneIcon from '@mui/icons-material/CloseTwoTone';
import Logo from 'src/components/Logo';

import HeaderButtons from './Buttons';
import HeaderUserbox from './Userbox';

const HeaderWrapper = styled(Box)(
  ({ theme }) => `
        height: ${theme.header.height};
        color: ${theme.header.textColor};
        padding: ${theme.spacing(0, 2)};
        right: 0;
        z-index: 6;        
        backdrop-filter: blur(3px);
        position: fixed;
        justify-content: space-between;
        width: 100%;
        @media (min-width: ${theme.breakpoints.values.lg}px) {
            left: ${theme.sidebar.width};
            width: auto;
        }
`
);

function Header() {
  const { sidebarToggle, toggleSidebar } = useContext(SidebarContext);
  const theme = useTheme();
  const [capiaDocumentTime, setCapiaDocumentTime] = useState("Last loaded capacity from ");

  useEffect(() => {       
      if (Hub.SignalRConnection) {        
          Hub.SignalRConnection.on("CapiaDocumentUpdate", (notificationMessage) => {
            var notification: UserNotification = notificationMessage;
            setCapiaDocumentTime(notification.message);
        });
    }

  }, [Hub.SignalRConnection]);

  return (
    <HeaderWrapper
      display="flex"
      alignItems="center"
      style={{left: '0px', paddingLeft: '20px', zIndex: '1000', boxShadow: 'rgb(0 0 0 / 20%) 0px 2px 4px -1px, rgb(0 0 0 / 14%) 0px 4px 5px 0px, rgb(0 0 0 / 12%) 0px 1px 10px 0px'}}      
      sx={{        
        backgroundColor: '#5F6EEC',
        boxShadow:
          theme.palette.mode === 'dark'
            ? `0 1px 0 ${alpha(
                lighten(theme.colors.primary.main, 0.7),
                0.15
              )}, 0px 2px 8px -3px rgba(0, 0, 0, 0.2), 0px 5px 22px -4px rgba(0, 0, 0, .1)`
            : `0px 2px 8px -3px ${alpha(
                theme.colors.alpha.black[100],
                0.2
              )}, 0px 5px 22px -4px ${alpha(
                theme.colors.alpha.black[100],
                0.1
              )}`
      }}
    >
      <Stack
        direction="row"
        divider={<Divider orientation="vertical" flexItem />}
        alignItems="center"
        spacing={2}
      >       

          <Box mt={3} style={{marginTop: '0px'}}>            
            <Box
              mx={2}
              sx={{
                width: 52,
                backgroundColor: "#5F6EEC"
              }}
            >
              <Logo />
            </Box>
          </Box>    

          <h2 style={{color: 'white', marginLeft: '100px' }}>Credit Risk Reduction</h2>
      </Stack>
      <Box display="flex" alignItems="center">
        <HeaderButtons />
        <div>        
        <HeaderUserbox />
        </div>
        <Box
          component="span"
          sx={{
            ml: 2,
            display: { lg: 'none', xs: 'inline-block' }
          }}
        >
          <Tooltip arrow title="Toggle Menu">
            <IconButton color="primary" onClick={toggleSidebar}>
              {!sidebarToggle ? (
                <MenuTwoToneIcon fontSize="small" />
              ) : (
                <CloseTwoToneIcon fontSize="small" />
              )}
            </IconButton>
          </Tooltip>
        </Box>
      </Box>
    </HeaderWrapper>
  );
}

export default Header;
