import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import { UserService } from 'src/api/services/UserService';
import { UserDto } from "../api/models/UserDto";

interface UserState {    
    user: UserDto;
}

const initialState: UserState = {    
    user: null,
}

export const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        saveUser: (state, action) => {
            state.user = action.payload;
        }
    },
    extraReducers: (builder) => {
        // saving user to the store after getCurrentUser request was fulfilled
        builder.addCase(getCurrentUser.fulfilled, (state, action) => {
            state.user = action.payload;
        })
    }
})

export const getCurrentUser = createAsyncThunk('getCurrentUser', async () =>
{
    const response = await UserService.postApiUserGetCurrentUser();    
    return response;
})  

export const {saveUser} = userSlice.actions;