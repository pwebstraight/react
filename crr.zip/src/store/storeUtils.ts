
class Store<TItem>
{
    list: TItem[];

    index: object;          // dictionary<number (Id), number (index)>

    constructor()
    {
        this.list = [];
        this.index = [];
    }

    static initialize<TItem>(list: TItem[], getKey: (item: TItem) => number)
    {
        var map = {}, index = {};

        for (var i = 0; i < list.length; i++)
        {
            map[getKey(list[i])] = list[i];
            index[getKey(list[i])] = i;
        }

        var result = new Store<TItem>();

        result.list = [ ...list];
        result.index = index;

        return result;
    }

    getItem(key: number) : TItem
    {
        return this.list[this.index[key]];      // O(1) time
    }

    update(key: number, item: TItem): Store<TItem>
    {
        var list = [ ...this.list ];
        var index = { ...this.index };

        if (key in index)
        {
            list[index[key]] = item;
        }
        else
        {
            index[key] = list.length;
            list.push(item);
        }

        var result = new Store<TItem>();
        result.list = list;
        result.index = index;

        return result;
    }
}


class State<TItem>
{
    store: Store<TItem> = new Store<TItem>();
}

export { Store, State };