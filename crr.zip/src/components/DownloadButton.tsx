import { LoadingButton } from '@mui/lab';
import { useState } from 'react';
import { FileResponse } from '../api';

interface IDownloadButtonProps
{
    onClick: () => FileResponse;
    children: any;
}

function DownloadButton(props: IDownloadButtonProps)
{
    const [loading, setLoading] = useState<boolean>(false);

    async function download()
    {
        setLoading(true);

        const result: FileResponse = await props.onClick();

        var element = document.createElement('a');
        element.href = `data:${result.contentType};base64,${result.content}`;
        element.setAttribute('download', result.fileName);
        element.click();
        element.remove();

        setLoading(false);
    }

    return (
        <LoadingButton
            variant="outlined"
            color="secondary"
            style={{ marginRight: "20px" }}
            loading={loading}
            onClick={download} >
            {props.children}
        </LoadingButton>
    );
}

export default DownloadButton;