import { createContext, Context, useState, useEffect, SetStateAction, Dispatch, ReactComponentElement, ReactNode, useContext } from "react";

interface Property<T>
{
    get: T;
    set: Dispatch<SetStateAction<T>>;
    update?: (val: T) => void;
}

interface PropertyContext<T>
{
    underlyingContext: Context<Property<T>>;
    defaultValue: T;
}

function createPropertyContext<T>(defaultValue: T): PropertyContext<T>
{
    var context = createContext<Property<T>>({ get: null, set: null });
    return { underlyingContext: context, defaultValue: defaultValue };
}

function usePropertyState<T>(propertyContext: PropertyContext<T>): [Property<T>, Context<Property<T>>, T, Dispatch<SetStateAction<T>>]
{
    const { underlyingContext, defaultValue } = propertyContext;
    const [get, set] = useState<T>(defaultValue);
    const [property, setProperty] = useState<Property<T>>({ get, set });

    useEffect(() =>
    {
        setProperty({ get, set });
    }, [get]);

    return [property, underlyingContext, get, set];
}

function usePropertyContext<T>(propertyContext: PropertyContext<T>): [T, Dispatch<SetStateAction<T>>, Property<T>]
{
    const property = useContext(propertyContext.underlyingContext);
    return [property.get, property.set, property];
}

export { createPropertyContext, usePropertyState, usePropertyContext };

export default Property;

