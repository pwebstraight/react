




function updateList<T>(list: T[], item: T, getKey: (item: T) => number): T[]
{
    var copy = [...list];
    var key = getKey(item);

    var index = list.findIndex(obj => getKey(obj) == key);

    if (index >= 0)
    {
        copy[index] = item;
    }
    else
    {
        copy.push(item);
    }

    return copy;
}

export default updateList;