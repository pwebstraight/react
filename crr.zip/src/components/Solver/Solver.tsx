import { useState, useEffect, useContext } from 'react';
import 'src/components/ParticipatingClients/style.css';
import TenorSection from 'src/components/TenorSection/TenorSection';

import
{
    Box,
    styled,
    Tab,
    Tabs
} from '@mui/material';
import { TabContext } from '@mui/lab';
import { solverResultContext } from '../../pages/runPage';

const TabsContainerWrapper = styled(Box)(
    ({ theme }) => `
    background-color: ${theme.colors.alpha.black[5]};
    padding: ${theme.spacing(2)};
  `
);

function Solver()
{
    const solverResult = useContext(solverResultContext);

    if (solverResult == null) return (<> Result Loading... </>);

    const [isLoading, setIsLoading] = useState(true);

    console.log(solverResult);

    useEffect(() =>
    {
        if (solverResult != null)
            setCurrentTab(solverResult.tenorSections[0].tenorId.toString());

        const timer = setTimeout(() =>
        {
            setIsLoading(false);
        }, 4000);
        return () => clearTimeout(timer);
    }, []);

    const [currentTab, setCurrentTab] = useState<string>(null);

    function handleTabsChange(_event: React.SyntheticEvent, newValue: string): void
    {
        setCurrentTab(newValue);
    };

    return (
        <>
            <TabsContainerWrapper>
                <TabContext value={currentTab}>
                    <Tabs
                        onChange={handleTabsChange}
                        value={currentTab}
                        variant="scrollable"
                        scrollButtons="auto"
                        textColor="primary"
                        indicatorColor="primary"
                        sx={{
                            '& .MuiButtonBase-root': {
                                paddingLeft: '10px',
                                paddingRight: '10px',
                            },
                        }}
                    >
                        {solverResult?.tenorSections.map((tab) => (
                            <Tab key={tab.tenorId.toString()} label={tab.tenorLabel} value={tab.tenorId.toString()} />
                        ))}
                    </Tabs>
                </TabContext>
            </TabsContainerWrapper>

            {
                solverResult.tenorSections.slice(0, 1).map((tab) => (
                    <div key={tab.tenorId.toString()} style={{ display: (tab.tenorId.toString() == currentTab || isLoading) ? 'block' : 'none', width: '100%', float: 'left' }}>
                        <TenorSection tenorSection={tab} clients={solverResult.clients} runId={solverResult.runId} />
                    </div>
            ))}

            <div style={{
                height: "5000px",
                display: isLoading ? 'block' : 'none',
                margin: '20px 0 0 20px'
            }} />

            {
                solverResult.tenorSections.slice(1).map((tab) => (
                    <div key={tab.tenorId.toString()} style={{ display: (tab.tenorId.toString() == currentTab || isLoading) ? 'block' : 'none', width: '100%', float: 'left' }}>
                        <TenorSection tenorSection={tab} clients={solverResult.clients} runId={solverResult.runId} />
                    </div>
            ))}

        </>
    );
}

export default Solver;
