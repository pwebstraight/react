import { LoadingButton } from '@mui/lab';
import { useState } from 'react';

function AsyncButton(props)
{
    const [busy, setBusy] = useState<boolean>(false);

    async function onClick()
    {
        if (busy) return;
        setBusy(true);

        try { await props.onClick(); }
        finally { setBusy(false); }
    }

    return (
        <LoadingButton
            variant="outlined"
            color="secondary"
            style={{ ...props.style, marginRight: "20px" }}

            loading={busy}
            onClick={onClick}
        >
            {props.children}
        </LoadingButton>
    );
}

export default AsyncButton;