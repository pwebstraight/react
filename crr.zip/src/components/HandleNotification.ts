import { useEffect, useState } from "react";
import Hub from "../api/Hub";


function HandleNotification<TDto>(
    topic: string,
    initialise: () => Promise<void>,
    update: (notification: TDto) => void,
    triggerList?: any[]): void
{
    if (triggerList == null) triggerList = [];

    const [notification, onNotification] = useState<TDto>(null);

    useEffect(() =>
    {
        initialise().then(() =>
        {
            if (Hub.SignalRConnection)
            {
                Hub.SignalRConnection.on(
                    topic, onNotification);
            }
        });
    }, triggerList);

    useEffect(() =>
    {
        if (notification != null) update(notification);
    }, [notification]);
}


export default HandleNotification;