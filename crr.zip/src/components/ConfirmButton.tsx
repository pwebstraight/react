import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from '@mui/material';
import { useState } from 'react';
import CloseIcon from '@mui/icons-material/CloseTwoTone';

interface IConfirmButtonProps
{
    confirmationText: string;
    dialogTitle: string;
    onConfirm: () => void;
    children: any;
}

function ConfirmButton(Props: IConfirmButtonProps)
{
    const [dialogVisible, setDialogVisible] = useState<boolean>(false);

    function onClickOk()
    {
        setDialogVisible(false);
        Props.onConfirm();
    }

    function onClickCancel()
    {
        setDialogVisible(false);
    }

    return (
        <>
            <Button
                variant="outlined"
                color="secondary"
                style={{ marginRight: "20px" }}
                onClick={() => setDialogVisible(true)} >
                { Props.children }
            </Button>
            <Dialog open={dialogVisible} maxWidth="md">
                <DialogTitle sx={{ p: 3 }} >
                    <Typography variant="h4" gutterBottom>
                        { Props.dialogTitle }
                    </Typography>
                    <CloseIcon
                        style={{ float: 'right', marginTop: '-30px', cursor: 'pointer' }}
                        onClick={ onClickCancel }
                    />
                </DialogTitle>
                <DialogContent>
                    <p> { Props.confirmationText } </p>
                </DialogContent>

                <DialogActions>
                    <Button onClick={onClickOk}>
                        Yes
                    </Button>
                    <Button onClick={ onClickCancel } color="primary" variant="contained">
                        No
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export { ConfirmButton };