import { DataGrid } from 'devextreme-react';

import { useEffect, useState } from 'react';
import { RunDto, RunStatus, TenorDto, TenorService } from 'src/api';
import { Column, FilterRow, Grouping, HeaderFilter, Paging, Selection, LoadPanel } from 'devextreme-react/data-grid';
import { RowPreparedEvent, SelectionChangedEvent } from 'devextreme/ui/data_grid';
import { format } from 'date-fns';
import { selectedRunContext } from '../../pages/runPage';
import { usePropertyContext } from '../Property';

function TenorSelection({ })
{
    // #region State Management

    const [ selectedRun ] = usePropertyContext(selectedRunContext);

    if (selectedRun == null) return (<></>);

    const [state, setState] = useState<TenorDto[]>(null);
    const [selection, setSelection] = useState<number[]>(null);

    const [feedbackDisabled, setFeedbackDisabled] = useState<boolean>(false);

    useEffect(() =>
    {
        if (selectedRun.runStatus == RunStatus.CREATED)
        {
            if (feedbackDisabled) return;
            setFeedbackDisabled(true);

            TenorService.postApiTenorGetTenors(selectedRun)
                .then(setState)
                .then(() => setSelection(selectedRun.tenors.map(t => t.tenorId)));
        }
        else
        {
            setFeedbackDisabled(false);
            setState(selectedRun.tenors);
        }
    }, [selectedRun]);

    useEffect(() =>
    {
        if (selectedRun == null) return;
        if (selectedRun.runStatus != RunStatus.CREATED) return;
        if (selection == null) return;
        TenorService.postApiTenorSaveSelectedTenors({ runId: selectedRun.runId, selectedTenorIds: selection });
    }, [selection]);

    // #endregion

    // #region Action

    function handleTenorSelection(e: SelectionChangedEvent<TenorDto, number>)
    {
        setSelection(e.selectedRowKeys);
    }

    // #endregion

    // #region Customise code

    function onRowPrepared(e: RowPreparedEvent<TenorDto, number>)
    {
        if (e.rowType === 'data')
        {
            if (e.rowIndex % 2 === 1)
            {
                e.rowElement.style.backgroundColor = "white";
            }
            else
            {
                e.rowElement.style.backgroundColor = "#f5f5f5";
            }
        }
    }

    function renderCustomGrouptext(e)
    {
        switch (e.value)
        {
        case 1:
            return 'Balance of Month';
        case 2:
            return 'Weeks';
        case 3:
            return 'Months';
        case 4:
            return 'Quarters';
        case 5:
            return 'Seasons';
        case 6:
            return 'Years';
        }
    }

    function DateCell(props)
    {
        if (props.value === null) return <div></div>;
        const date = new Date(props.value);
        const formattedDate = format(date, 'dd MMM yyyy');

        return <div>{formattedDate}</div>;
    }

    // #endregion

    return (
        <div className="left-column" style={{ maxHeight : "60%"} }>
            <DataGrid
                className="datagridTenors"
                dataSource={state}
                columnAutoWidth={true}
                showBorders={true}
                keyExpr="tenorId"
                repaintChangesOnly={true}
                onSelectionChanged={handleTenorSelection}
                selectedRowKeys={selection}                onRowPrepared={onRowPrepared}>
                <LoadPanel enabled />
                <Paging enabled={false} />
                <HeaderFilter visible={true} />
                <Grouping autoExpandAll={true} />
                <FilterRow visible={false} />
                {
                    selectedRun.runStatus == RunStatus.CREATED ?
                    <Selection
                        mode="multiple"
                        selectAllMode={'allPages'}
                        allowSelectAll={true}
                        showCheckBoxesMode={'always'}
                    /> :
                    <></>
                }
                <Column
                    width={0}
                    dataType={'number'}
                    caption={"Tenor Type"}
                    allowSorting="false"
                    groupIndex={0}
                    visible="false"
                    calculateGroupValue={'groupingOrderKey'}
                    customizeText={renderCustomGrouptext}
                />
                <Column
                    dataField="tenorType"
                    caption="Tenor Type"
                    alignment="left"
                    allowResizing={true}
                    width={200}
                />
                <Column
                    dataField="tenorLabel"
                    caption="Tenor Label"
                    alignment="left"
                    allowResizing={true}
                    width={200}
                />
                <Column
                    dataField="hours"
                    caption="Hours"
                    alignment="right"
                    allowResizing={true}
                    width={100}
                />
                <Column
                    dataField="periodStart"
                    caption="Period Start"
                    alignment="right"
                    allowResizing={true}
                    cellRender={DateCell}
                />
                <Column
                    dataField="periodEnd"
                    caption="Period End"
                    alignment="right"
                    allowResizing={true}
                    cellRender={DateCell}
                />
                <Column
                    dataField="tradingEnd"
                    caption="Trading End"
                    alignment="right"
                    allowResizing={true}
                    cellRender={DateCell}
                />
            </DataGrid>
        </div>
    );
}

export default TenorSelection;
