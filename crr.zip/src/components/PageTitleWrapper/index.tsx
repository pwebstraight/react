import { FC, ReactNode } from 'react';
import PropTypes from 'prop-types';
import { Box, Container, styled, Typography } from '@mui/material';

const PageTitle = styled(Box)(
  ({ theme }) => `
        padding: ${theme.spacing(2)};        
`
);

interface PageTitleWrapperProps {
  children?: ReactNode;
}

const PageTitleWrapper: FC<PageTitleWrapperProps> = ({ children }) => {
  return (
    <PageTitle className="MuiPageTitle-wrapper" style={{marginBottom: '15px'}}>
      <Typography style={{color: '#9F9F9F'}} variant="h3" component="h4" gutterBottom>
        {children}
      </Typography>      
    </PageTitle>
  );
};

PageTitleWrapper.propTypes = {
  children: PropTypes.node.isRequired
};

export default PageTitleWrapper;
