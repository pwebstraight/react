import { FC, ReactNode } from 'react';

import {  
  Card,   
} from "@mui/material";

interface PageContainerWrapperProps {
  children?: ReactNode;
}

const PageContainer: FC<PageContainerWrapperProps> = ({ children }) => {
  return (
    <Card style={{paddingLeft: '10px', paddingRight: '30px', margin: '10px', paddingBottom: '10px'}}>      
      {children}      
    </Card>
  );
};

export default PageContainer;
