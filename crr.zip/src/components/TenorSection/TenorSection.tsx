import { useState, useEffect, useRef, ReactNode } from 'react';
import 'src/components/ParticipatingClients/style.css';

import DataGrid, { Column, Paging, Selection } from 'devextreme-react/data-grid';

import { Box, styled, TextField, Typography } from '@mui/material';

import
{
    TenorSectionDto,
    TradeDto,
    ClientDto,
    SolverService,
    OrderDto,
    Dimension,
    GraphArcDto
} from 'src/api';
import { Network } from 'vis-network';
import vis from 'vis-data';
import { SelectionChangedEvent } from 'devextreme/ui/data_grid';

const SolverContainer = styled(Box)(
    ({ theme }) => `
    canvas {
      transform: translateY(0);
      height: 500px!Important;
    };
    .vis-network {
      height: 500px!Important;
    }
  `
);

interface Props
{
    tenorSection: TenorSectionDto;
    clients: ClientDto[];
    runId: number;
}

function TenorSection(props: Props)
{
    const [orderGraph, setOrderGraph] = useState<any>(null);
    const [tradeGraph, setTradeGraph] = useState<any>(null);
    const [currentClients, setCurrentClients] = useState<ClientDto[]>();
    const [selectedClients, setSelectedClients] = useState<number[]>();
    const [currentTrades, setCurrentTrades] = useState<TradeDto[]>();
    const [currentOrders, setCurrentOrders] = useState<OrderDto[]>();
    const [tenorSection, setTenorSection] = useState<TenorSectionDto>(null);
    const [graphArcDto, setGraphArcDto] = useState<GraphArcDto[]>();

    const [tenorPriceInput, setTenorPriceInput] = useState<string>(null);
    const orderGraphContainer = useRef(null);
    const tradeGraphContainer = useRef(null);
    const selectedClientsRef = useRef<number[]>([]);

    selectedClientsRef.current = selectedClients;

    useEffect(() =>
    {
        var selected: number[] = [];

        props.clients.forEach((c) =>
        {
            selected.push(c.clientId);
        });

        setSelectedClients(selected);
        setCurrentClients(props.clients);
        setTenorSection(props.tenorSection);
        setTenorPriceInput(props.tenorSection.price?.toString());
        setGraphArcDto(props.tenorSection.tradeGraph.arcs);
    }, []);

    useEffect(() =>
    {
        if (tenorSection != null)
        {
            parseSolver();
        }
    }, [tenorSection]);

    function parseSolver()
    {
        setCurrentTrades(tenorSection.trades);
        setCurrentOrders(tenorSection.orders);
        createOrderGraph();
        createTradeGraph();
    }

    const options = {
        layout: {
            hierarchical: false
        },
        edges: {
            color: '#4472C4',
            width: 1,
            shadow: true
        },
        height: '600px',
        autoResize: false,
        interaction: {
            navigationButtons: true,
            keyboard: true
        },
        nodes:
        {
            shadow: true
        }
    };

    function selectionChanged(e: SelectionChangedEvent<ClientDto, number>)
    {
        setSelectedClients(e.selectedRowKeys);
    }

    useEffect(() =>
    {
        const tradeNetwork =
            tradeGraphContainer.current &&
            new Network(tradeGraphContainer.current, tradeGraph, options);
    }, [tradeGraphContainer, tradeGraph]);

    useEffect(() =>
    {
        const orderNetwork =
            orderGraphContainer.current &&
            new Network(orderGraphContainer.current, orderGraph, options);
    }, [orderGraphContainer, orderGraph]);

    useEffect(() =>
    {
        if (orderGraph == null) return;
        orderGraph.nodes.refresh();
    }, [selectedClients, orderGraph]);

    function nodesFilter(node): boolean
    {
        if (!selectedClientsRef.current) return true;
        return selectedClientsRef.current.findIndex((id) => id == node.id) != -1;
    }

    function createOrderGraph()
    {
        var arcs = tenorSection.orderGraph.arcs;

        var nodeExists = {};

        var nodes = [];
        var edges = [];

        arcs.forEach((arc) =>
        {
            nodeExists[arc.sellerId] = true;
            nodeExists[arc.buyerId] = true;

            edges.push({
                from: arc.sellerId,
                to: arc.buyerId,
                arrows: {
                    from: { enabled: false },
                    to: { enabled: true }
                },
                //title: "Buy : " + arc.buyOrder.toString() + ", Sell : " + arc.sellOrder.toString(),
                label: arc?.matchOrder?.volume?.toString() // todo changed based on Unit
            });
        });

        currentClients.forEach((client) =>
        {
            if (client.clientId in nodeExists)
            {
                nodes.push({
                    id: client.clientId,
                    label: client.shortName,
                    title: client.clientName
                });
            }
        });

        const nodesView = new vis.DataView(new vis.DataSet(nodes), {
            filter: nodesFilter
        });

        setOrderGraph({ edges, nodes: nodesView });
    }

    function createTradeGraph()
    {
        let graph = {
            nodes: [],
            edges: []
        };

        var arcs = tenorSection.tradeGraph.arcs;

        var clients = {};
        props.clients.forEach((client) =>
        {
            clients[client.clientId] = client;
        });

        var nodeExists = {};

        arcs.forEach((arc) =>
        {
            nodeExists[arc.sellerId] = true;
            nodeExists[arc.buyerId] = true;

            graph.edges.push({
                from: arc.sellerId,
                to: arc.buyerId,
                arrows: {
                    from: { enabled: false },
                    to: { enabled: true }
                },
                label: arc.trade?.volume?.toString()
            });
        });

        props.clients.forEach((client) =>
        {
            if (client.clientId in nodeExists)
            {
                graph.nodes.push({
                    id: client.clientId,
                    label: client.shortName,
                    title: client.clientName
                });
            }
        });

        setTradeGraph(graph);
        console.log(tradeGraph);
    }

    const savePrice = async (price: number) =>
    {
        if (tenorSection == null) return;

        const newtenorSection = await SolverService.postApiSolverSetTenorPrice({
            runId: props.runId,
            tenorId: tenorSection.tenorId,
            price: price,
            includeTest: props.tenorSection.isTest
        });

        console.log("server replied" + price);

        if (newtenorSection)
        {
            setTenorSection(newtenorSection);
        }
    };
     
    const handlePriceChange = async (event: React.ChangeEvent<HTMLInputElement>) =>
    {
        if (event.target.value === '')
        {
            setTenorPriceInput(null);
            savePrice(null);
        }
        else
        {
            var value = Number(event.target.value);

            setTenorPriceInput(event.target.value);
            savePrice(value);
            await savePrice(value);
        }
    }

    function RenderShortNameCell(cellData: { data: ClientDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title={cellData.data.clientName}>
                    {cellData.data.shortName}
                </div>
            </div>
        );
    }

    function RenderBuyerCell(cellData: { data: TradeDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title={cellData.data.buyer.clientName}>
                    {cellData.data.buyer.shortName}
                </div>
            </div>
        );
    }

    function RenderSellerCell(cellData: { data: TradeDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title={cellData.data.seller.clientName}>
                    {cellData.data.seller.shortName}
                </div>
            </div>
        );
    }

    function RenderCounterPartyCell(cellData: { data: OrderDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title={cellData.data.counterParty.clientName}>
                    {cellData.data.counterParty.shortName}
                </div>
            </div>
        );
    }

    function RenderClientCell(cellData: { data: OrderDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title={cellData.data.client.clientName}>
                    {cellData.data.client.shortName}
                </div>
            </div>
        );
    }

    function RenderVolumeCell(cellData: { data: OrderDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0", fontWeight: cellData.data.value.originalDimension == Dimension.POWER ? "bold" : "normal" }}>
                <div style={{ margin: "-7px", padding: "7px" }}>
                    {cellData.data.value.volume}
                </div>
            </div>
        );
    }

    function RenderNotionalCell(cellData: { data: OrderDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0", fontWeight: cellData.data.value.originalDimension == Dimension.CURRENCY ? "bold" : "normal" }}>
                <div style={{ margin: "-7px", padding: "7px" }}>
                    {cellData.data.value.notional}
                </div>
            </div>
        );
    }

    function RenderTotalCell(cellData: { data: OrderDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0", fontWeight: cellData.data.value.originalDimension == Dimension.ENERGY ? "bold" : "normal" }}>
                <div style={{ margin: "-7px", padding: "7px" }}>
                    {cellData.data.value.total}
                </div>
            </div>
        );
    }


    return (
        <>
            {orderGraph && tradeGraph && tenorSection && (
                <>
                    <div style={{ maxHeight: '100vh', overflow: 'auto' }}>
                        <div style={{ margin: '20px 0 0 20px' }}>
                            <TextField
                                label="Price"
                                type="number"
                                value={tenorPriceInput}
                                onChange={handlePriceChange}
                                title={tenorSection.pricingDescription}

                            inputProps={{
                                form: {
                                    autocomplete: 'off',
                                },
                            }}
                            />
                        </div>
                        <div
                            style={{
                                float: 'left',
                                margin: '20px',
                                marginTop: '42px'
                            }}
                        >
                            Clients
                            <DataGrid
                                dataSource={currentClients}
                                keyExpr="clientId"
                                showBorders={true}
                                defaultSelectedRowKeys={selectedClients}
                                onSelectionChanged={selectionChanged}
                            >
                                <Selection
                                    mode="multiple"
                                    selectAllMode={true}
                                    showCheckBoxesMode="onClick"
                                />
                                <Column
                                    dataField="shortName"
                                    caption="Short Name"
                                    alignment="right"
                                    width={150}
                                    cellRender={RenderShortNameCell}
                                />
                            </DataGrid>
                        </div>
                        <SolverContainer className="Container" style={{ height: '500px' }}>
                            <div
                                className="Container"
                                style={{ width: '42%', float: 'left', margin: '10px' }}
                            >
                                <Typography
                                    style={{
                                        color: '#9F9F9F',
                                        textAlign: 'center',
                                        marginTop: '15px'
                                    }}
                                    variant="h3"
                                    component="h4"
                                    gutterBottom
                                >
                                    Order Graph
                                </Typography>
                                <div
                                    style={{
                                        border: '1px solid lightgrey',
                                        background: '#F8F8F8'
                                    }}
                                    ref={orderGraphContainer}
                                />
                            </div>
                            <div
                                className="Container"
                                style={{ width: '42%', float: 'left', margin: '10px' }}
                            >
                                <Typography
                                    style={{
                                        color: '#9F9F9F',
                                        textAlign: 'center',
                                        marginTop: '15px'
                                    }}
                                    variant="h3"
                                    component="h4"
                                    gutterBottom
                                >
                                    Trade Graph
                                </Typography>
                                <div
                                    style={{
                                        border: '1px solid lightgrey',
                                        background: '#F8F8F8'
                                    }}
                                    ref={tradeGraphContainer}
                                />
                            </div>
                        </SolverContainer>
                        <div style={{ float: 'left', margin: '20px 0 0 20px' }}>
                            Orders
                            <DataGrid
                                dataSource={currentOrders}
                                showBorders={true}>
                                <Paging enabled={false} />
                                <Column
                                    dataField="client.shortName"
                                    caption="Client"
                                    alignment="right"
                                    width={100}
                                    cellRender={RenderClientCell}
                                />
                                <Column
                                    dataField="counterParty.shortName"
                                    caption="Counterparty"
                                    alignment="right"
                                    width={100}
                                    cellRender={RenderCounterPartyCell}
                                />
                                <Column
                                    dataField="value.volume"
                                    caption="Volume"
                                    alignment="right"
                                    width={100}
                                    cellRender={RenderVolumeCell}
                                />
                                <Column
                                    dataField="value.total"
                                    caption="Total"
                                    alignment="right"
                                    width={100}
                                    cellRender={RenderTotalCell}
                                />
                                <Column
                                    dataField="value.notional"
                                    caption="Notional"
                                    alignment="right"
                                    width={100}
                                    cellRender={RenderNotionalCell}
                                />
                            </DataGrid>
                        </div>
                        <div style={{ float: 'left', margin: '20px 40px 20px' }}>
                            Trades
                            <DataGrid dataSource={currentTrades} showBorders={true}>

                                <Paging enabled={false} />


                                <Column caption="Sell Order">

                                    <Column
                                        dataField="seller.shortName"
                                        caption="Seller"
                                        alignment="right"
                                        width={90}
                                        cellRender={RenderSellerCell}
                                    />

                                    <Column
                                        dataField="sellOrder.volume"
                                        caption="Volume"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="sellOrder.total"
                                        caption="Total"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="sellOrder.notional"
                                        caption="Notional"
                                        alignment="right"
                                        width={90}
                                    />
                                </Column>

                                <Column width={4} />

                                <Column caption="Buy Order">

                                    <Column
                                        dataField="buyer.shortName"
                                        caption="Buyer"
                                        alignment="right"
                                        width={90}
                                        cellRender={RenderBuyerCell}
                                    />


                                    <Column
                                        dataField="buyOrder.volume"
                                        caption="Volume"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="buyOrder.total"
                                        caption="Total"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="buyOrder.notional"
                                        caption="Notional"
                                        alignment="right"
                                        width={90}
                                    />

                                </Column>

                                <Column width={4} />

                                <Column caption="Match">

                                    <Column
                                        dataField="matchOrder.volume"
                                        caption="Volume"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="matchOrder.total"
                                        caption="Total"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="matchOrder.notional"
                                        caption="Notional"
                                        alignment="right"
                                        width={90}
                                    />

                                </Column>
                                <Column caption="Trade">

                                    <Column
                                        dataField="value.volume"
                                        caption="Volume"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="value.total"
                                        caption="Total"
                                        alignment="right"
                                        width={90}
                                    />
                                    <Column
                                        dataField="value.notional"
                                        caption="Notional"
                                        alignment="right"
                                        width={90}
                                    />

                                </Column>
                            </DataGrid>
                            <div style={{ height: '20px'}} />
                        </div>
                    </div>
                </>
            )
            }
        </>
    );
}

export default TenorSection;
