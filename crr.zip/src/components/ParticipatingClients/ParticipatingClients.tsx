import { useState, useEffect, ChangeEvent, useRef } from 'react';
import Editor from 'src/components/Editor';
import { ClientParticipationService } from 'src/api/services/ClientParticipationService';
import { format } from 'date-fns';
import 'src/components/ParticipatingClients/style.css';
import InfoIcon from '@mui/icons-material/InfoOutlined';
import
{
    Button,
    Typography,
    Box,
    styled,
    Tabs,
    Tab,
    Dialog,
    DialogContent,
    DialogTitle,
    DialogActions,
    useTheme,
    Tooltip
} from '@mui/material';

import { LoadingButton } from '@mui/lab';

import DataGrid,
{
    Column,
    Editing,
    Paging,
    HeaderFilter,
    Selection,
    LoadPanel
} from 'devextreme-react/data-grid';

import CloseIcon from '@mui/icons-material/CloseTwoTone';
import
{
    EmailTemplateService,
    EmailTemplateType,
    LiveStatus,
    MailService,
    ParticipationStatus,
    ParticipatingClientsDto,
    RunDto,
    RunService,
    SendEmailRequestDto,
    SubmissionStatus,
    OrderSheetService,
    RunStatus
} from 'src/api';
import { runListTab, stpExecutionTab, selectedRunContext, currentTabContext, participantListContext } from '../../pages/runPage';
import { usePropertyContext } from '../Property';

const TabsContainerWrapper = styled(Box)(
    ({ theme }) => `
    background-color: ${theme.colors.alpha.black[5]};
    padding: ${theme.spacing(2)};
  `
);

function IsRunFinished(run: RunDto): boolean
{
    return run.runStatus == RunStatus.DONE ||
        run.runStatus == RunStatus.CANCELLED;
}

function IsRunDone(run: RunDto): boolean
{
    return run.runStatus == RunStatus.DONE;
}

function IsListLocked(run: RunDto): boolean
{
    return run.runStatus != RunStatus.CREATED;
}

function ParticipatingClients()
{
    const [selectedRun, setSelectedRun] = usePropertyContext(selectedRunContext);
    const [_, setCurrentTab] = usePropertyContext(currentTabContext);
    const [participantList] = usePropertyContext(participantListContext);


    const [state, setState] = useState([]);

    const theme = useTheme();
    const dataGridRef = useRef(null);

    if (selectedRun == null) return (<></>);

    //const [state, setState] = useState<ParticipatingClientsDto[]>(null);
    const [selection, setSelection] = useState<ParticipatingClientsDto[]>([]);

    const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
    const [cancelRunRequest, setCancelRunRequest] = useState<boolean>(false);
    const [showEmailTemplatesPopup, setShowEmailTemplatesPopup] = useState<boolean>(false);

    const [currentTabsub, setCurrentTabSub] = useState<string>('submission');           // todo refactor

    const [sendSheetsRequest, setSendSheetsRequest] = useState<boolean>(false);
    const [ButtonLoading, setButtonLoading] = useState<boolean>(false);

    const tabs =
    [
        { value: 'submission', label: 'Submission' },
        { value: 'analysis', label: 'Analysis' }
    ];

    useEffect(() =>
    {
        if (IsListLocked(selectedRun))
        {
            setState(participantList.filter(p => p.isActive === ParticipationStatus.ACTIVE));
        }
        else
        {
            setState(participantList);
        }
    }, [participantList, selectedRun]);

    function handleTabsChange(_event: ChangeEvent<{}>, value: string): void
    {
        setCurrentTabSub(value);
    }

    function closeEmailTemplatesPopup()
    {
        setShowEmailTemplatesPopup(false);
        setTimeout(() => setSendSheetsRequest(false), 500);
    }

    function determineStatus(cellInfo: any)
    {
        let status =
        {
            text: '',
            colour: '',
            textColour: ''
        };

        switch (cellInfo.submissionStatus)
        {
            case SubmissionStatus.IN_ERROR:
                status.textColour = 'white';
                status.text = 'Error';
                status.colour = '#ff435c';
                break;
            case SubmissionStatus.PENDING:
                status.textColour = 'white';
                status.text = 'Pending';
                status.colour = 'orange';
                break;
            case SubmissionStatus.RECEIVED:
                status.textColour = 'black';
                status.text = 'Received';
                status.colour = '#fde502';
                break;
            case SubmissionStatus.SENT:
                status.textColour = 'white';
                status.text = 'Sent';
                status.colour = '#5191ff';
                break;
            case SubmissionStatus.CONFIRMED:
                status.textColour = 'white';
                status.text = 'Confirmed';
                status.colour = '#2ecc71';
                break;
        }

        return status;
    }

    async function openEmailTemplateScreen(runId: number)
    {
        const apiResponse =
            await EmailTemplateService.postApiEmailTemplateGetDefaultEmailTemplates(runId);

        setSelectedRun(apiResponse);
        setShowEmailTemplatesPopup(true);
    }

    function emailTemplateUpdate (currentTemplate)
    {
        var currentRunCopy = { ...selectedRun };
        currentRunCopy.emailTemplates.filter(
            (cr) => cr.emailTemplateType == currentTemplate[0].emailTemplateType
        )[0] = currentTemplate[0];
        setSelectedRun(currentRunCopy);
    }

    async function saveDefaultEmailTemplates(runDto: RunDto)
    {
        setButtonLoading(true);
        await EmailTemplateService.postApiEmailTemplateAddDefaultEmailTemplates(runDto);
        setShowEmailTemplatesPopup(false);
        setButtonLoading(false);
    }

    function handleParticipantSelection(e)
    {
        setSelection(e.selectedRowsData);
    }

    function handleSendSheetsButton()
    {
        setSendSheetsRequest(true);
        openEmailTemplateScreen(selectedRun.runId);
    }

    async function sendEmailsToParticipants(runDto: RunDto)
    {
        setButtonLoading(true);
        await MailService.postApiMailSendMailWithAttachment(
            {
                runId: runDto.runId,
                emailTemplates: runDto.emailTemplates,
                selectedParticipants: selection.map((p: ParticipatingClientsDto) => p.clientParticipationId)
            });
        setShowEmailTemplatesPopup(false);
        setButtonLoading(false);
        dataGridRef.current.instance.deselectAll();
    }

    async function cancelRun()
    {
        await RunService.postApiRunCancelRun(selectedRun.runId)
        setCurrentTab(runListTab);
    }

    async function completeRun()
    {
        await RunService.postApiRunCompleteRun(selectedRun.runId);
        setCurrentTab(stpExecutionTab);
    }

    function onEditorPreparing(e)
    {
        if (e.parentType === 'dataRow')
        {
            e.editorOptions.disabled =
                e.row.data.isActive == ParticipationStatus.INACTIVE ||
                e.row.data.isExchange;

            e.editorOptions.visible = !e.editorOptions.disabled;
        }
    };

    function StatusCell(cellInfo)
    {
        const submissionStatus = determineStatus(cellInfo.data);

        return (
            <Tooltip
                title={submissionStatus.text === 'Error' ? cellInfo.data.errorMessage : ''}
                classes={{ tooltip: 'inError-tooltip' }}>
                    <div
                        className="submissionStatus"
                        style={{
                            color: submissionStatus.textColour,
                            backgroundColor: submissionStatus.colour,
                            boxShadow:
                                submissionStatus.text === '' ? '' : '0 1px 4px rgba(0,0,0,.6)'
                        }}
                    >
                        {submissionStatus.text}
                        {submissionStatus.text === 'Error' && (
                            <InfoIcon className="error-icon" />
                        )}
                    </div>
            </Tooltip>
        );
    };

    function ClientCellRender(cellInfo)
    {
        return (
            <div
                style={{ fontStyle: cellInfo.data.isExchange ? 'italic' : 'normal' }}
            >
                {cellInfo.data.isExchange ? (
                    <div>
                        {cellInfo.value}
                        <Tooltip title={cellInfo.data.isExchange ? 'Exchange' : ''}>
                            <InfoIcon className="error-icon" />
                        </Tooltip>
                    </div>
                ) : (
                    cellInfo.value
                )}
            </div>
        );
    };

    function DateCell(props: any)
    {
        if (props.value === null)
        {
            return <div></div>;
        }
        const date = new Date(props.value);
        const formattedDate = format(date, 'd MMM yyyy, HH:mm');

        return <div>{formattedDate}</div>;
    }

    function RenderActionButton(cellInfo: { data: ParticipatingClientsDto })
    {
        const activeLabel = 'Active';
        const inactiveLabel = 'Inactive';

        let caption = activeLabel;
        let status = ParticipationStatus.INACTIVE;
        let color = '#2ecc71';
        let fontColor = '#ecf0f1';

        const selectedClient = cellInfo.data;

        if (selectedClient.isActive == ParticipationStatus.INACTIVE)
        {
            caption = inactiveLabel;
            status = ParticipationStatus.ACTIVE;
            color = 'gray';
        }

        return (
            <div
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}
            >
                <Button
                    className="statusButton"
                    disabled={IsListLocked(selectedRun)}
                    onClick={() => updateParticipationStatus(selectedClient, status)}
                    style={{ backgroundColor: `${color}`, color: `${fontColor}` }}
                    variant="text"
                >
                    {caption}
                </Button>
            </div>
        );
    }

    function RenderStatusActionButton(cellInfo: { data: ParticipatingClientsDto })
    {
        const liveLabel = 'Live';
        const testLabel = 'Test';

        let caption = liveLabel;
        let status = LiveStatus.TEST;
        let color = '#2ecc71';
        let fontColor = '#ecf0f1';

        const selectedClient = cellInfo.data;

        if (selectedClient.status == LiveStatus.TEST)
        {
            caption = testLabel;
            status = LiveStatus.LIVE;
            color = '#5191ff';
        }

        if (selectedClient.isActive == ParticipationStatus.INACTIVE)
        {
            color = 'gray';
        }

        return (
            <div
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}
            >
                <Button
                    className="statusButton"
                    disabled={IsListLocked(selectedRun)}
                    onClick={() => updateLiveStatus(selectedClient, status)}
                    style={{ backgroundColor: `${color}`, color: `${fontColor}` }}
                    variant="text"
                >
                    {caption}
                </Button>
            </div>
        );
    }


    function updateParticipationStatus(client: ParticipatingClientsDto, status: ParticipationStatus)
    {
        ClientParticipationService.postApiClientParticipationUpdateClientParticipant({ ...client, isActive: status });
            //.then(result =>
            //{
            //    var index = state.findIndex(c => c.clientParticipationId == client.clientParticipationId);

            //    var newState = [...state];
            //    newState[index] = result;
            //    setState(newState);
            //});
    }

    function updateLiveStatus(client: ParticipatingClientsDto, status: LiveStatus)
    {
        ClientParticipationService.postApiClientParticipationUpdateClientParticipant({ ...client, status: status });
            //.then(result =>
            //{
            //    var index = state.findIndex(c => c.clientParticipationId == client.clientParticipationId);

            //    var newState = [...state];
            //    newState[index] = result;
            //    setState(newState);
            //});
    }

    function onRowPrepared(row: any)
    {
        if (row.rowType === 'data')
        {
            if (row.data.isActive === 'Inactive')
            {
                row.rowElement.classList.add('inactive-row');
            } else if (row.rowIndex % 2 === 0)
            {
                row.rowElement.classList.add('alternative-row');
            }
        }
    }

    function closeConfirmation()
    {
        setShowConfirmation(false);
        setTimeout(() => setCancelRunRequest(false), 500);
    }

    function showCancel()
    {
        setShowConfirmation(true);
        setCancelRunRequest(true);
    }

    function showComplete()
    {
        setCancelRunRequest(false);
        setShowConfirmation(true);
    }

    function handleConfirmation()
    {
        if (cancelRunRequest)
        {
            cancelRun();
        }
        else
        {
            completeRun();
        }
    }

    async function sendTradesConfirmation()
    {
        setButtonLoading(true);
        await MailService.postApiMailSendConfirmationEmails({
            runId: selectedRun.runId,
            emailTemplates: [],
            selectedParticipants: selection.map((p: ParticipatingClientsDto) => p.clientParticipationId)
        })
        setButtonLoading(false);
    }


    return (
        <>
            <Button
                color="secondary"
                onClick={() => openEmailTemplateScreen(selectedRun.runId)}
                size="large"
            >
                {IsRunFinished(selectedRun) ? 'View Email Template' : 'Edit Email Template'}
            </Button>
            <Button
                color="secondary"
                onClick={() => handleSendSheetsButton()}
                disabled={
                    IsRunFinished(selectedRun) ||
                    selection.length == null ||
                    selection.length == 0
                }
                size="large"
            >
                Send Sheets
            </Button>

            <Button
                color="secondary"
                disabled={!IsListLocked(selectedRun)}
                onClick={async () =>
                {
                    var file =
                        await OrderSheetService.postApiOrderSheetGenerateTestOrderSheet(
                            selectedRun.runId
                        );
                    var element = document.createElement('a');
                    element.href = `data:${file.contentType};base64,${file.content}`;
                    element.setAttribute('download', file.fileName);
                    element.click();
                    element.remove();
                }}
                size="large"
            >
                Download Test Order Sheet
            </Button>

            <Button
                color="secondary"
                disabled={!IsListLocked(selectedRun)}
                onClick={async () =>
                {
                    var file =
                        await OrderSheetService.postApiOrderSheetGenerateLiveOrderSheet(
                            selectedRun.runId
                        );
                    var element = document.createElement('a');
                    element.href = `data:${file.contentType};base64,${file.content}`;
                    element.setAttribute('download', file.fileName);
                    element.click();
                    element.remove();
                }}
                size="large"
            >
                Download Live Order Sheet
            </Button>
            <LoadingButton
                color="secondary"
                onClick={() => sendTradesConfirmation()}
                size="large"
                disabled={
                    selection.length == null ||
                    selection.length == 0 ||
                    !IsRunDone(selectedRun)
                }
                loading={ButtonLoading}
            >
                Send Trades Confirmation
            </LoadingButton>
            <Button
                color="secondary"
                onClick={() => showCancel()}
                size="large"
                disabled={IsRunFinished(selectedRun)}
                style={{ marginLeft: '198px' }}
            >
                Cancel Run
            </Button>

            <Button
                color="secondary"
                onClick={() => showComplete()}
                size="large"
                disabled={IsRunFinished(selectedRun)}
            >
                Complete Run
            </Button>

            <div style={{ marginTop: '10px' }}>
                <DataGrid
                    id="participatingClientsDataGrid"
                    ref={dataGridRef}
                    dataSource={state}
                    keyExpr="clientId"
                    onEditorPreparing={(e) => onEditorPreparing(e)}
                    onSelectionChanged={(e) => handleParticipantSelection(e)}
                    repaintChangesOnly={true}
                    onRowPrepared={onRowPrepared}
                    showBorders={true}
                    sorting={{ mode: 'multiple', showSortIndexes: false }}
                >
                    <LoadPanel enabled={false}/>
                    <Selection
                        mode="multiple"
                        selectAllMode={true}
                        showCheckBoxesMode="onClick"
                    />
                    <HeaderFilter visible={true} />
                    <Paging enabled={false} />
                    <Editing mode="row" useIcons={true} allowUpdating={false} />
                    <Column
                        dataField="clientName"
                        caption="Client Name"
                        cellRender={ClientCellRender}
                        width={350}
                        sortIndex={2}
                        sortOrder={'asc'}
                    />
                    <Column
                        dataField="status"
                        caption="Is Live"
                        alignment="center"
                        width={150}
                        cellRender={RenderStatusActionButton}
                        visible={true}
                        showInColumnChooser={false}
                    />
                    <Column
                        dataField="isActive"
                        caption="Is Active"
                        alignment="center"
                        width={150}
                        cellRender={RenderActionButton}
                        visible={true}
                        showInColumnChooser={false}
                        sortIndex={0}
                        sortOrder={'asc'}
                    />
                    <Column
                        dataField="submissionStatus"
                        caption="Status"
                        alignment="center"
                        cellRender={StatusCell}
                        width={150}
                        visible={true}
                        showInColumnChooser={false}
                    />
                    <Column
                        dataField="statusDate"
                        caption="Status Date"
                        alignment="center"
                        cellRender={DateCell}
                        width={150}
                        visible={true}
                        showInColumnChooser={false}
                    />
                    <Column
                        dataField="receivedDate"
                        caption="Date Received"
                        alignment="center"
                        cellRender={DateCell}
                        width={150}
                        visible={true}
                        showInColumnChooser={false}
                    />
                    <Column
                        dataField="isExchange"
                        visible={false}
                        sortIndex={1}
                        sortOrder={'asc'}
                    />
                </DataGrid>
            </div>

            <Dialog
                onClose={closeConfirmation}
                open={showConfirmation}
                maxWidth="md"
            >
                <DialogTitle
                    sx={{
                        p: 3
                    }}
                >
                    <Typography variant="h4" gutterBottom>
                        {cancelRunRequest ? 'Cancel Run' : 'Complete Run'}
                    </Typography>
                    <CloseIcon
                        style={{ float: 'right', marginTop: '-30px', cursor: 'pointer' }}
                        onClick={closeConfirmation}
                    />
                </DialogTitle>
                <DialogContent>
                    <p>
                        {' '}
                        Are you sure you want to{' '}
                        {cancelRunRequest ? ' CANCEL' : ' COMPLETE'} the run?
                    </p>
                </DialogContent>

                <DialogActions>
                    <Button onClick={handleConfirmation}>
                        Yes
                    </Button>
                    <Button onClick={closeConfirmation} color="primary" variant="contained">
                        No
                    </Button>
                </DialogActions>
            </Dialog>

            <Dialog
                onClose={closeEmailTemplatesPopup}
                open={showEmailTemplatesPopup}
                fullWidth={true}
                maxWidth="md"
            >
                <DialogTitle
                    sx={{
                        p: 3
                    }}
                >
                    <Typography variant="h4" gutterBottom>
                        {sendSheetsRequest ? 'Send Sheets' : 'Email Template'}
                    </Typography>
                    <CloseIcon
                        style={{ float: 'right', marginTop: '-20px', cursor: 'pointer' }}
                        onClick={ closeEmailTemplatesPopup }
                    />
                </DialogTitle>
                <DialogContent>
                    <>
                        <TabsContainerWrapper>
                            <Tabs
                                onChange={handleTabsChange}
                                value={currentTabsub}
                                variant="scrollable"
                                scrollButtons="auto"
                                textColor="primary"
                                indicatorColor="primary"
                            >
                                {tabs.map((tab) => (
                                    <Tab key={tab.value} label={tab.label} value={tab.value} />
                                ))}
                            </Tabs>
                        </TabsContainerWrapper>
                        {currentTabsub == 'submission' && (
                            <Editor
                                emailTemplate={selectedRun.emailTemplates.filter(
                                    e => e.emailTemplateType == EmailTemplateType.SUBMISSION
                                )}
                                onEmailTemplateChange={emailTemplateUpdate}
                                recipients={selection.filter(
                                    sc => sc.submissionStatus == SubmissionStatus.PENDING
                                )}
                                sendSheetsRequest={sendSheetsRequest}
                            />
                        )}
                        {currentTabsub == 'analysis' && (
                            <Editor
                                emailTemplate={selectedRun.emailTemplates.filter(
                                    e => e.emailTemplateType == EmailTemplateType.ANALYSIS
                                )}
                                onEmailTemplateChange={emailTemplateUpdate}
                                recipients={selection.filter(
                                    sc =>
                                        sc.submissionStatus != SubmissionStatus.PENDING
                                )}
                                sendSheetsRequest={sendSheetsRequest}
                            />
                        )}
                    </>
                </DialogContent>

                <DialogActions>
                    {sendSheetsRequest && (
                        <Box
                            pr={58}
                            sx={{
                                pt: `${theme.spacing(0)}`,
                                pb: { xs: 1, md: 0 }
                            }}
                            alignSelf="center"
                        >
                            <b>{'*Emails are sent separately to clients'}</b>
                        </Box>
                    )}

                    <Button
                        color="secondary"
                        onClick={closeEmailTemplatesPopup}
                    >
                        Cancel
                    </Button>

                    {sendSheetsRequest ? (
                        <LoadingButton
                            color="primary"
                            onClick={e => sendEmailsToParticipants(selectedRun)}
                            loading={ButtonLoading}
                            variant="contained"
                        >
                            Send
                        </LoadingButton>
                    ) : (
                        <LoadingButton
                            color="primary"
                                onClick={e => saveDefaultEmailTemplates(selectedRun)}
                            loading={ButtonLoading}
                            variant="contained"
                                disabled={IsRunFinished(selectedRun)}
                        >
                            Save
                        </LoadingButton>
                    )}
                </DialogActions>
            </Dialog>
        </>
    );
}

export default ParticipatingClients;
