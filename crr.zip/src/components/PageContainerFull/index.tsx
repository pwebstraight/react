import { FC, ReactNode } from 'react';
import PageContainer from 'src/components/PageContainer';

import {  
  Grid,
  CardContent,   
} from "@mui/material";

interface PageContainerFullWrapperProps {
  children?: ReactNode;
}

const PageContainerFull: FC<PageContainerFullWrapperProps> = ({ children }) => {
  return (
    <PageContainer>
      <CardContent style={{paddingTop: '15px'}}>      
        <Grid style={{marginTop: '0px', marginLeft: '0px'}} container spacing={4}>
          <Grid item xs={12}>       
            {children}
          </Grid>
        </Grid> 
      </CardContent>
    </PageContainer>
  )
};

export default PageContainerFull;
