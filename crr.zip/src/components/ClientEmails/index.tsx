import _ from 'lodash';

import DataGrid, {
  Column,
  Editing,
  Paging,
  HeaderFilter,
  MasterDetail,
  Button,
  Selection
} from 'devextreme-react/data-grid';
import { ClientDto, ClientService, EmailDto } from 'src/api';
import { useEffect, useRef, useState } from 'react';
import { Button as MaterialButton } from '@mui/material';
import { setTimeout } from 'timers/promises';

const ClientEmails = (prevProps) => {
  let _dataGrid = useRef(null);
  const [isLoading, setIsLoading] = useState(false);
  const [clients, setClients] = useState<ClientDto[]>([]);
  const [emailToAdd, setEmailToAdd] = useState<EmailDto>({
    emailId: 0,
    clientId: prevProps.data.data.clientId,
    emailAddress: '',
    isContact: false,
    isSubmission: false,
    isCustomer: false,
    isTrader: false,
    traderId: null,
    traderName: '',
    description: ''
  });

  const [emails, setEmails] = useState<any>(prevProps.data.data.emails);

  const [clientToAdd, setClientToAdd] = useState<ClientDto>(prevProps.data.data);

  async function onEmailRowUpdated(e) {
    let gridEmail = _.cloneDeep(e.oldData);
    const updatedProperties = Object.keys(e.newData);
    const updatedValues = Object.values(e.newData);

    updatedProperties.forEach(function (key, index) {
      gridEmail[key] = updatedValues[index];
    });

    let currentClients = clients;
    let currentClient = currentClients.find(
      (c) => c.clientId == prevProps.data.data.clientId
    );

    if (gridEmail.isTrader) {
      currentClient.emails.forEach((e) => (e.isTrader = false));
    }
    var currentIndex = currentClient.emails.findIndex(
      (t) => t.emailId == gridEmail.emailId
    );
    currentClient.emails[currentIndex] = gridEmail;

    console.log(currentClient);
    saveEmail(currentClient);
    setEmails(currentClient.emails);
    loadClients();
  }

  async function onEmailRowInserting(e) {
    let gridEmail = _.cloneDeep(e.data);
    gridEmail.emailId = 0;
    let currentClients = clients;
    let currentClient = currentClients.find(
      (c) => c.clientId == prevProps.data.data.clientId
    );
    if (gridEmail.isTrader) {
      currentClient.emails.forEach((e) => (e.isTrader = false));
    }
    currentClient.emails.push(gridEmail);
    saveEmail(currentClient);
    await loadClients();
    const updatedClient = clients.find(
      (c) => c.clientId == currentClient.clientId
    );
    console.log(updatedClient);
    setEmails(updatedClient.emails);
  }

  async function saveEmail(currentClient) {
    await ClientService.postApiClientEditClient(currentClient);
    loadClients();
  }
  async function loadClients() {
    const clients = await ClientService.postApiClientGetClients();
    setClients(clients);
  }

  function addNewRow() {
    _dataGrid.current.instance.addRow();
  }

  const onInitNewRow = (e: any) => {
    e.data.isContact = false;
    e.data.isCustomer = false;
    e.data.isSubmission = false;
    e.data.isTrader = false;
  };

  const onCellPrepared = (e: any) => {
    if (e.rowType === 'header') {
      switch (e.column.caption) {
        case 'Email Address':
          e.cellElement.title = "*Required";
          break;
        case 'Description':
          e.cellElement.title = "*Not required";
          break;
        case 'Contact':
          e.cellElement.title =
            "Email address will display under the 'Contacts' column of the submission sheet.";
            break;
        case 'Customer':
          e.cellElement.title =
            "Email address will display under the 'Customer Email' column of the order sheet. Used by matchbook.";
            break;
        case 'Submission':
          e.cellElement.title =
            'Email address will receive the submission/analysis sheet.';
            break;
        case 'Trader':
          e.cellElement.title =
            "Sets the client's current trader. Hence, only one can be selected at a time.";
            break;
        case 'Trader Name':
          e.cellElement.title = "Trayport Dealer Name. *Required for a trader";
            break;
        case 'Trader Id':
          e.cellElement.title = "Trayport Dealer Id. *Required for a trader";
            break;
      }
    }
  };

  useEffect(() => {
    loadClients();
  }, []);

  return (
    <>
      <div style={{ marginBottom: '10px' }}>
        <MaterialButton color="secondary" onClick={addNewRow} size="large">
          {'Add Email'}
        </MaterialButton>
      </div>
      <DataGrid
        ref={_dataGrid}
        dataSource={emails}
        keyExpr="emailId"
        showBorders={true}
        onRowUpdating={onEmailRowUpdated}
        onRowInserting={onEmailRowInserting}
        onInitNewRow={onInitNewRow}
        onCellPrepared={onCellPrepared}
      >
        <Selection mode="single" />
        <HeaderFilter visible={true} />
        <Paging enabled={false} />
        <Editing
          mode="row"
          useIcons={true}
          allowUpdating={true}
          allowAdding={false}
        />
        <Column
          dataField="emailAddress"
          caption="Email Address"
          width={350}
          sortOrder={'asc'}
        />
        <Column dataField="description" caption="Description" width={250} />
        <Column
          dataField="isContact"
          caption="Contact"
          width={180}
          dataType="boolean"
        />
        <Column
          dataField="isCustomer"
          caption="Customer"
          width={180}
          dataType="boolean"
        />
        <Column
          dataField="isSubmission"
          caption="Submission"
          width={180}
          dataType="boolean"
        />
        <Column
          dataField="isTrader"
          caption="Trader"
          width={180}
          dataType="boolean"
        />
        <Column dataField="traderName" caption="Trader Name" width={250} />
        <Column dataField="traderId" caption="Trader Id" width={180} />
        <Column type="buttons" width={110} caption="Actions">
          <Button name="edit" />
        </Column>
      </DataGrid>
    </>
  );
};

export default ClientEmails;
