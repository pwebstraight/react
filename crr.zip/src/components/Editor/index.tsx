import
{
    Box,
    Grid,
    TextField,
    useTheme
} from '@mui/material';
import HtmlEditor,
{
    Toolbar,
    MediaResizing,
    Item
} from 'devextreme-react/html-editor';
import { EmailTemplateDto } from 'src/api';
import { useState } from 'react';

function Editor(props)
{
    const clientNames = props.recipients.map((r) => r.shortName);
    const theme = useTheme();

    const sizeValues = ['8pt', '10pt', '12pt', '14pt', '18pt', '24pt', '36pt'];
    const fontValues = [
        'Arial',
        'Courier New',
        'Georgia',
        'Impact',
        'Lucida Console',
        'Tahoma',
        'Times New Roman',
        'Verdana'
    ];

    const headerValues = [false, 1, 2, 3, 4, 5];
    const [currentEmailTemplate, setCurrentEmailTemplate] =
        useState<EmailTemplateDto>(props.emailTemplate);

    const OnSubjectChange = (e: any) =>
    {
        let copyTemplate = { ...currentEmailTemplate };
        copyTemplate[0].subject = e.target.value;
        setCurrentEmailTemplate(copyTemplate);
        props.onEmailTemplateChange(copyTemplate);
    };

    const OnBodyChange = (e: any) =>
    {
        let copyTemplate = { ...currentEmailTemplate };
        copyTemplate[0].body = e.event.target.innerHTML;
        setCurrentEmailTemplate(copyTemplate);
        props.onEmailTemplateChange(copyTemplate);
    };

    return (
        <div>
            <Grid item container spacing={0} xs={12}>
                {props.sendSheetsRequest && (
                    <>
                        <Grid item xs={12} sm={2} md={2} justifyContent="flex-end">
                            <Box
                                pr={3}
                                sx={{
                                    pt: `${theme.spacing(2)}`,
                                    pb: { xs: 1, md: 0 }
                                }}
                                alignSelf="center"
                            >
                                <b>{'To'}:</b>
                            </Box>
                        </Grid>
                        <Grid
                            sx={{
                                mb: `${theme.spacing(0)}`
                            }}
                            item
                            xs={12}
                            sm={10}
                            md={10}
                        >
                            <Box
                                pr={3}
                                sx={{
                                    pt: `${theme.spacing(2)}`,
                                    pb: { xs: 1, md: 0 }
                                }}
                                alignSelf="center">
                                <b>
                                    {' '}
                                    {clientNames.length > 0 ? clientNames.join(', ') : 'N/A'}
                                </b>
                            </Box>
                        </Grid>
                    </>
                )}
                <Grid item xs={12} sm={2} md={2} justifyContent="flex-end">
                    <Box
                        pr={3}
                        sx={{
                            pt: `${theme.spacing(3)}`,
                            pb: { xs: 1, md: 0 }
                        }}
                        alignSelf="center"
                    >
                        <b>{'Subject'}:</b>
                    </Box>
                </Grid>
                <Grid
                    sx={{
                        mt: `${theme.spacing(2)}`,
                        mb: `${theme.spacing(2)}`
                    }}
                    item
                    xs={12}
                    sm={10}
                    md={10}
                >
                    <TextField
                        type="string"
                        name=""
                        value={currentEmailTemplate[0]?.subject}
                        fullWidth={true}
                        size="small"
                        InputLabelProps={{
                            shrink: true
                        }}
                        onChange={(e) => OnSubjectChange(e)}
                    />
                </Grid>
            </Grid>

            <HtmlEditor
                height="525px"
                defaultValue={currentEmailTemplate[0].body}
                onFocusOut={OnBodyChange}
            >
                <MediaResizing enabled={true} />
                <Toolbar multiline={true}>
                    <Item name="undo" />
                    <Item name="redo" />
                    <Item name="separator" />
                    <Item name="size" acceptedValues={sizeValues} />
                    <Item name="font" acceptedValues={fontValues} />
                    <Item name="separator" />
                    <Item name="bold" />
                    <Item name="italic" />
                    <Item name="strike" />
                    <Item name="underline" />
                    <Item name="separator" />
                    <Item name="alignLeft" />
                    <Item name="alignCenter" />
                    <Item name="alignRight" />
                    <Item name="alignJustify" />
                    <Item name="separator" />
                    <Item name="orderedList" />
                    <Item name="bulletList" />
                    <Item name="separator" />
                    <Item name="header" acceptedValues={headerValues} />
                    <Item name="separator" />
                    <Item name="color" />
                    <Item name="background" />
                    <Item name="separator" />
                    <Item name="link" />
                    <Item name="image" />
                    <Item name="separator" />
                    <Item name="clear" />
                    <Item name="codeBlock" />
                    <Item name="blockquote" />
                    <Item name="separator" />
                    <Item name="insertTable" />
                    <Item name="deleteTable" />
                    <Item name="insertRowAbove" />
                    <Item name="insertRowBelow" />
                    <Item name="deleteRow" />
                    <Item name="insertColumnLeft" />
                    <Item name="insertColumnRight" />
                    <Item name="deleteColumn" />
                </Toolbar>
            </HtmlEditor>
        </div>
    );
}

export default Editor;
