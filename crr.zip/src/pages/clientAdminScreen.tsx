import { useState, useEffect, useRef } from 'react';
import PageContainerFull from 'src/components/PageContainerFull';
import ClientEmails from 'src/components/ClientEmails';
import { ClientService } from 'src/api/services/ClientService';
import _ from 'lodash';
import 'src/components/ParticipatingClients/style.css';

import
{
    Button,
    Box,
    styled
} from '@mui/material';

import DataGrid, {
    Column,
    Editing,
    Paging,
    HeaderFilter,
    MasterDetail,
    Selection
} from 'devextreme-react/data-grid';
import { ClientDto, LiveStatus, ParticipationStatus } from 'src/api';
import { RowInsertingEvent, RowUpdatedEvent, RowUpdatedInfo } from 'devextreme/ui/data_grid';

function ClientAdminScreen ()
{
    const [clients, setClients] = useState<ClientDto[]>([]);

    useEffect(() =>
    {
        ClientService.postApiClientGetClients().then(setClients);
    }, []);

    let datagridReference = useRef(null);

    function setParticipationStatus(client: ClientDto, status: ParticipationStatus)
    {
        if (client.clientId != null)            // the client is persisted
        {
            persistClient({ ...client, currentParticipationStatus: status });
        }
        else
        {
            client.currentParticipationStatus = status;
        }
    }

    function setLiveStatus(client: ClientDto, status: LiveStatus)
    {
        if (client.clientId != null)            // the client is persisted
        {
            persistClient({ ...client, currentLiveStatus : status });
        }
        else
        {
            client.currentLiveStatus = status;
        }
    }

    const RenderParticipationStatusButton = (e: { cellInfo: { data : ClientDto} }) =>
    {
        const activeLabel = 'Active';
        const inactiveLabel = 'Inactive';

        let caption = activeLabel;
        let status = ParticipationStatus.INACTIVE;
        let color = '#2ecc71';
        let fontColor = '#ecf0f1'

        const selectedClient = e.cellInfo.data;

        if (selectedClient.currentParticipationStatus == ParticipationStatus.INACTIVE)
        {
            caption = inactiveLabel;
            status = ParticipationStatus.ACTIVE;
            color = 'gray';
        }

        return (
            <div
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}
            >
                <Button
                    className="statusButton"
                    onClick={() => setParticipationStatus(selectedClient, status)}
                    style={{ backgroundColor: `${color}`, color: `${fontColor}` }}
                    variant="text"
                >
                    {caption}
                </Button>
            </div>
        );
    };

    const RenderLivestatusButton = (e: { cellInfo: { data: ClientDto } }) =>
    {
        const liveLabel = 'Live';
        const testLabel = 'Test';

        let caption = liveLabel;
        let status = LiveStatus.TEST;
        let color = '#2ecc71';
        let fontColor = '#ecf0f1'

        const selectedClient = e.cellInfo.data;

        if (selectedClient.currentLiveStatus == LiveStatus.TEST)
        {
            caption = testLabel;
            status = LiveStatus.LIVE;
            color = '#5191ff';
        }

        if (selectedClient.currentParticipationStatus == ParticipationStatus.INACTIVE)
        {
            color = 'gray';
        }

        return (
            <div
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}
            >
                <Button
                    className="statusButton"
                    onClick={() => setLiveStatus(selectedClient, status)}
                    style={{ backgroundColor: `${color}`, color: `${fontColor}` }}
                    variant="text"
                >
                    {caption}
                </Button>
            </div>
        );
    };

    function addNewRow()
    {
        datagridReference.current.instance.addRow();
    }

    function onRowUpdating(e)
    {
        let gridClient = _.cloneDeep(e.oldData);
        const updatedProperties = Object.keys(e.newData);
        const updatedValues = Object.values(e.newData);

        updatedProperties.forEach(function (key, index)
        {
            gridClient[key] = updatedValues[index];
        });

        let clientToEdit: ClientDto = gridClient;
        console.log(clientToEdit);
        persistClient(clientToEdit);
    }

    function onRowInserting(e: RowInsertingEvent<ClientDto, number>)
    {
        let client: ClientDto =
        {
            ...e.data,
            clientId: 0,
            emails: []
        };
        addClient(client);
    }

    async function persistClient(client)
    {
        try
        {
            await ClientService.postApiClientEditClient(client);
        }
        catch
        {

        }
    }

    async function addClient(client)
    {
        try
        {
            await ClientService.postApiClientAddClient(client);
        }
        catch
        {

        }
    }

    const onCellPrepared = (e) =>
    {
        if (e.rowType === "header")
        {
            switch (e.column.caption)
            {
                case ("Client Name"):
                    e.cellElement.title = "*Required";
                    break;
                case ("Trayport Name"):
                    e.cellElement.title = "*Required";
                    break;
                case ("Short Name"):
                    e.cellElement.title = "*Required";
                    break;
                case ("Exchange Id"):
                    e.cellElement.title = "Trayport Exchange Instrument Id. *Required for an exchange";
                    break;
                case ("Company Id"):
                    e.cellElement.title = "Trayport Company Id. *Required";
                    break;
                case ("Status"):
                    e.cellElement.title = "If client is active, this sets the client to be live or test status for a run.";
                    break;
                case ("Is Active"):
                    e.cellElement.title = "Sets client's current participation status to active (participating in a run) or inactive (not participating in a run)."
                    break;
            }
        }
    }

    const onInitNewRow = (e: any) =>
    {
        e.data.isExchange = false;
    };

    return (
        <>
            <PageContainerFull>
                <>
                    <div style={{ marginBottom: '10px' }}>
                        <Button color="secondary" onClick={addNewRow} size="large">
                            {'Add Client'}
                        </Button>
                    </div>
                    <DataGrid
                        ref={datagridReference}
                        dataSource={clients}
                        keyExpr="clientId"
                        showBorders={true}
                        onRowUpdating={onRowUpdating}
                        onRowInserting={onRowInserting}
                        onInitNewRow={onInitNewRow}
                        onCellPrepared={(e) => onCellPrepared(e)}
                    >
                        <Selection mode="single" />
                        <HeaderFilter visible={true} />
                        <Paging enabled={false} />
                        <Editing
                            mode="row"
                            useIcons={true}
                            allowUpdating={true}
                            allowAdding={false}
                        />

                        <MasterDetail enabled={true} component={ClientEmails} />
                        <Column dataField="clientName" caption="Client Name" sortOrder={'asc'} />
                        <Column
                            dataField="trayportName"
                            caption="Trayport Name"
                        />
                        <Column
                            dataField="shortName"
                            caption="Short Name"
                            width={150}
                        />
                        <Column
                            dataField="currentLiveStatus"
                            caption="Status"
                            cellRender={RenderLivestatusButton}
                            width={115}
                            visible={true}
                            allowEditing={false}
                            alignment="center"
                            showInColumnChooser={false}
                        />
                        <Column
                            dataField="currentParticipationStatus"
                            width={115}
                            caption="Is Active"
                            allowEditing={false}
                            alignment="center"
                            cellRender={RenderParticipationStatusButton}
                            visible={true}
                            showInColumnChooser={false}
                        />
                        <Column dataField="isExchange" caption="Exchange" width={120} />
                        <Column
                            dataField="trayportCompanyId"
                            caption="Company Id"
                            width={250}
                        />
                        <Column
                            dataField="trayportExchangeInstrumentId"
                            caption="Exchange Id"
                            width={250}
                        />
                        <Column caption="Actions" type="buttons" width={110}>
                            <Button name="edit" />
                        </Column>
                    </DataGrid>
                </>
            </PageContainerFull>
        </>
    );
};

export default ClientAdminScreen;
