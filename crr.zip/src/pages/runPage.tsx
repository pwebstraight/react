import { useState, useEffect, createContext, ReactComponentElement } from 'react';
import { ClientParticipationService, InstrumentDto, InstrumentService, ParticipatingClientsDto, RunDto, RunService, RunStatus, SolverResultDto, SolverService } from '../api';
import { Box, Card, Tab, Tabs } from '@mui/material';
import { TabContext, TabPanel } from '@mui/lab';
import { RunListView } from '../Views/RunListView';
import { RunDetailsView } from '../Views/RunDetailsView';
import ParticipatingClients from '../components/ParticipatingClients/ParticipatingClients';
import TenorSelection from '../components/TenorSelection/TenorSelection';
import Solver from '../components/Solver/Solver';
import { createPropertyContext, usePropertyState } from '../components/Property';
import updateList from '../components/updateList';
import HandleNotification from '../components/HandleNotification';

const runListContext = createPropertyContext<RunDto[]>([]);
const participantListContext = createPropertyContext<ParticipatingClientsDto[]>([]);
const selectedRunContext = createPropertyContext<RunDto>(null);
const instrumentsContext = createContext<InstrumentDto[]>([]);
const solverResultContext = createContext<SolverResultDto>(null);

const runListTab = "RunList";
const runDetailTab = "RunDetail";
const tenorListTab = "TenorList";
const participatingClientsTab = "ParticipatingClients";
const liveSolverResultTab = "LiveSolverResult";
const testSolverResultTab = "TestSolverResult";
const stpExecutionTab = "StpExecutions";

const currentTabContext = createPropertyContext<string>(runListTab);

export { runListTab, runDetailTab, tenorListTab, participatingClientsTab, stpExecutionTab };
export { runListContext, selectedRunContext, instrumentsContext, solverResultContext, currentTabContext, participantListContext };

function RunPage(): ReactComponentElement<any>
{
    // #region Transient state

    const [selectedRunProperty, selectedRunPropertyContext, selectedRun, setSelectedRun ] = usePropertyState<RunDto>(selectedRunContext);
    const [currentTabProperty, currentTabPropertyContext, currentTab, setCurrentTab] = usePropertyState<string>(currentTabContext);

    // #endregion

    // #region Persisted state

    const [runListProperty, runListPropertyContext, runList, setRunList] = usePropertyState<RunDto[]>(runListContext);
    const [participantListProperty, participantListPropertyContext, participantList, setParticipantList] = usePropertyState<ParticipatingClientsDto[]>(participantListContext);

    function onRunUpdated(notification: RunDto)
    {
        setRunList(updateList(runList, notification, run => run.runId));

        if (selectedRun == null) return;
        if (selectedRun.runId != notification.runId) return;

        setSelectedRun(notification);
    }

    function onParticipantUpdated(notification: ParticipatingClientsDto)
    {
        if (selectedRun == null) return;
        if (selectedRun.runId != notification.runId) return;

        setParticipantList(updateList(participantList, notification, participant => participant.clientParticipationId));
    }

    HandleNotification<RunDto>(
        'UpdateRun',
        () => RunService.postApiRunGetRuns().then(setRunList),
        onRunUpdated);

    HandleNotification<ParticipatingClientsDto>(
        'UpdateParticipant',
        () => selectedRun != null ?
            ClientParticipationService.postApiClientParticipationGetParticipants(selectedRun.runId).then(setParticipantList)
            : new Promise((resolve, reject) => resolve()),
        onParticipantUpdated,
        [selectedRun]);

    // #endregion

    // #region Static data

    const [instruments, setInstruments] = useState<InstrumentDto[]>([]);

    useEffect(() =>
    {
        InstrumentService.postApiInstrumentGetInstruments()
            .then(setInstruments);
    }, []);

    // #endregion

    // #region Customisation lambdas

    function currentRunName(): string
    {
        if (selectedRun == null) return "Run Details";

        return 'Run Details - ' +
            selectedRun.instrument.instrumentName + ' | ' +
            selectedRun.tradeDate.slice(0, 10);
    }

    // #endregion

    // #region Solver Result

    const [liveSolverResult, setLiveSolverResult] = useState<SolverResultDto>(null);
    const [testSolverResult, setTestSolverResult] = useState<SolverResultDto>(null);

    useEffect(() =>
    {
        setLiveSolverResult(null);
        setTestSolverResult(null);

        if (selectedRun == null) return;
        if (selectedRun.runStatus == RunStatus.TRANSIENT) return;
        if (selectedRun.runStatus == RunStatus.CREATED) return;

        SolverService.postApiSolverRunLiveSolver(selectedRun.runId)
            .then(setLiveSolverResult);

        SolverService.postApiSolverRunLiveSolver(selectedRun.runId)
            .then(setTestSolverResult);

    }, [selectedRun]);

    // #endregion

    return (
        <currentTabPropertyContext.Provider value={currentTabProperty}>
            <TabContext value={currentTab}>
                <Box style={{ margin: '10px', marginBottom: '0' }}>
                    <Tabs
                        TabIndicatorProps={{ style: { borderRadius: '6px', borderBottomLeftRadius: '0', borderBottomRightRadius: '0' } }}
                        onChange={(e, value) => setCurrentTab(value)}
                        value={currentTab}>
                        <Tab
                            key={0}
                            label="Runs"
                            value={runListTab} />
                        <Tab
                            key={1}
                            disabled={selectedRun == null}
                            label={currentRunName()}
                            value={runDetailTab} />
                        <Tab
                            key={2}
                            disabled={selectedRun == null || selectedRun.runStatus == RunStatus.TRANSIENT}
                            label="Tenor List"
                            value={tenorListTab} />
                        <Tab
                            key={3}
                            disabled={selectedRun == null || selectedRun.runStatus == RunStatus.TRANSIENT}
                            label="Participating Clients"
                            value={participatingClientsTab} />
                        <Tab
                            key={4}
                            disabled={selectedRun == null || liveSolverResult == null}
                            label="Live Solver Result"
                            value={liveSolverResultTab} />
                        <Tab
                            key={5}
                            disabled={selectedRun == null || testSolverResult == null}
                            label="Test Solver Result"
                            value={testSolverResultTab} />
                        <Tab
                            key={6}
                            disabled={selectedRun == null || selectedRun.runStatus != RunStatus.DONE}
                            label="Executions"
                            value={stpExecutionTab} />
                    </Tabs>
                </Box>
                <Card style={{ borderTopLeftRadius: "0px", borderTopRightRadius: "0px" }}>
                    <TabPanel value={runListTab}>
                        <runListPropertyContext.Provider value={runListProperty}>
                            <selectedRunPropertyContext.Provider value={selectedRunProperty}>
                                <RunListView />
                            </selectedRunPropertyContext.Provider>
                        </runListPropertyContext.Provider>
                    </TabPanel>

                    <TabPanel value={runDetailTab}>
                        <instrumentsContext.Provider value={instruments} >
                            <selectedRunPropertyContext.Provider value={selectedRunProperty}>
                                <RunDetailsView />
                            </selectedRunPropertyContext.Provider>
                        </instrumentsContext.Provider>
                    </TabPanel>

                    <TabPanel value={tenorListTab}>
                        <selectedRunPropertyContext.Provider value={selectedRunProperty}>
                            <TenorSelection />
                        </selectedRunPropertyContext.Provider>
                    </TabPanel>

                    <TabPanel value={participatingClientsTab}>
                        <selectedRunPropertyContext.Provider value={selectedRunProperty}>
                            <participantListPropertyContext.Provider value={participantListProperty}>
                                <ParticipatingClients />
                            </participantListPropertyContext.Provider>
                        </selectedRunPropertyContext.Provider>
                    </TabPanel>

                    <TabPanel value={liveSolverResultTab}>
                        <solverResultContext.Provider value={liveSolverResult}>
                            <Solver />
                        </solverResultContext.Provider>
                    </TabPanel>

                    <TabPanel value={testSolverResultTab}>
                        <solverResultContext.Provider value={testSolverResult}>
                            <Solver />
                        </solverResultContext.Provider>
                    </TabPanel>

                    <TabPanel value={stpExecutionTab}>
                        <selectedRunPropertyContext.Provider value={selectedRunProperty}>
                            <div>"todo stp view"</div>
                        </selectedRunPropertyContext.Provider>
                    </TabPanel>
                </Card>
            </TabContext>
        </currentTabPropertyContext.Provider>
    );
}

export default RunPage;