import { useState, useEffect, useRef, ChangeEvent } from 'react';
import PageContainerFull from 'src/components/PageContainerFull';
import ClientEmails from 'src/components/ClientEmails';
import { ClientService } from 'src/api/services/ClientService';
import _ from 'lodash';
import 'src/components/ParticipatingClients/style.css';

import
    {
        Button as MaterialButton,
        Typography,
        Box,
        styled,
        TextField,
        Tabs,
        Tab,
        Tooltip
    } from '@mui/material';

import DataGrid, {
    Column,
    Editing,
    Paging,
    HeaderFilter,
    MasterDetail,
    Button,
    Selection
} from 'devextreme-react/data-grid';
import { ClientDto, LiveStatus, ParticipationStatus } from 'src/api';
import { RowInsertingEvent } from 'devextreme/ui/data_grid';

const TabsContainerWrapper = styled(Box)(
    ({ theme }) => `
    background-color: ${theme.colors.alpha.black[5]};
    padding: ${theme.spacing(2)};
  `
);

const Clients = () =>
{
    const [clients, setClients] = useState<ClientDto[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    const [emptyClientParticipationStatus, setEmptyClientParticipationStatus] = useState<ParticipationStatus>(ParticipationStatus.ACTIVE);
    const [emptyClientLiveStatus, setEmptyClientLiveStatus] = useState<LiveStatus>(LiveStatus.LIVE);

    useEffect(() =>
    {
        loadClients();
    }, []);

    async function loadClients()
    {
        if (!isLoading)
        {
            setIsLoading(true);
            try
            {
                const clients = await ClientService.postApiClientGetClients();
                setClients(clients);
            } catch {
            } finally
            {
                setIsLoading(false);
            }
        }
    }

    const getSelectedClient = (cellInfo: any): ClientDto | undefined =>
    {
        return clients.find(
            (r) => r.clientId === cellInfo.cellInfo.data.clientId
        );
    }

    let _dataGrid = useRef(null);

    const updateClient = (cellInfo: any, action: string) =>
    {
        if (cellInfo.cellInfo.data.clientId != null)
        {
            let currentClients = [...clients];
            const selectedClient = getSelectedClient(cellInfo);
            const clientIndex = currentClients.findIndex(
                (c) => c.clientId === selectedClient.clientId
            );

            switch (action)
            {
                case 'Active':
                case 'Inactive':
                    currentClients[clientIndex].currentParticipationStatus =
                        selectedClient.currentParticipationStatus ===
                            ParticipationStatus.ACTIVE
                            ? ParticipationStatus.INACTIVE
                            : ParticipationStatus.ACTIVE;
                    break;
                case 'Live':
                case 'Test':
                    currentClients[clientIndex].currentLiveStatus =
                        selectedClient.currentLiveStatus === LiveStatus.LIVE
                            ? LiveStatus.TEST
                            : LiveStatus.LIVE;
                    break;
            }

            setClients(currentClients);
            editClient(currentClients[clientIndex])
        }
        else
        {
            switch (action)
            {
                case 'Active':
                case 'Inactive':
                    const emptyClientParticipationStatusCopy = emptyClientParticipationStatus === ParticipationStatus.ACTIVE ? ParticipationStatus.INACTIVE : ParticipationStatus.ACTIVE
                    setEmptyClientParticipationStatus(emptyClientParticipationStatusCopy);
                    break;
                case 'Live':
                case 'Test':
                    const emptyClientLiveStatusCopy = emptyClientLiveStatus === LiveStatus.LIVE ? LiveStatus.TEST : LiveStatus.LIVE;
                    setEmptyClientLiveStatus(emptyClientLiveStatusCopy);
                    break;
            }
        };
    }
    const RenderActionButton = (cellInfo: any) =>
    {
        const activeLabel = 'Active';
        const inactiveLabel = 'Inactive';

        let caption = activeLabel;
        let action = activeLabel;
        let color = '#2ecc71';
        let fontColor = '#ecf0f1'

        const selectedClient = getSelectedClient(cellInfo);
        if (selectedClient != null)
        {
            if (selectedClient?.currentParticipationStatus == ParticipationStatus.INACTIVE)
            {
                caption = inactiveLabel;
                action = inactiveLabel;
                color = 'gray';
            }
        }
        else
        {
            if (emptyClientParticipationStatus == ParticipationStatus.INACTIVE)
            {
                caption = inactiveLabel;
                action = inactiveLabel;
                color = 'gray';
            }
        }

        return (
            <div
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}
            >
                <MaterialButton
                    className="statusButton"
                    onClick={() => updateClient(cellInfo, action)}
                    style={{ backgroundColor: `${color}`, color: `${fontColor}` }}
                    variant="text"
                >
                    {caption}
                </MaterialButton>
            </div>
        );
    };

    const RenderStatusActionButton = (cellInfo: any) =>
    {
        const liveLabel = 'Live';
        const testLabel = 'Test';

        let caption = liveLabel;
        let action = liveLabel;
        let color = '#2ecc71';
        let fontColor = '#ecf0f1'

        const selectedClient = getSelectedClient(cellInfo);

        if (selectedClient != null)
        {
            if (selectedClient?.currentLiveStatus == LiveStatus.TEST)
            {
                caption = testLabel;
                action = testLabel;
                color = '#5191ff';
            }

            if (selectedClient?.currentParticipationStatus == ParticipationStatus.INACTIVE)
            {
                color = 'gray';
            }
        }

        else
        {
            if (emptyClientLiveStatus == LiveStatus.TEST)
            {
                caption = testLabel;
                action = testLabel;
                color = '#5191ff';
            }

            if (emptyClientParticipationStatus == ParticipationStatus.INACTIVE)
            {
                color = 'gray';
            }
        }

        return (
            <div
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}
            >
                <MaterialButton
                    className="statusButton"
                    onClick={() => updateClient(cellInfo, action)}
                    style={{ backgroundColor: `${color}`, color: `${fontColor}` }}
                    variant="text"
                >
                    {caption}
                </MaterialButton>
            </div>
        );
    };

    function addNewRow()
    {
        _dataGrid.current.instance.addRow();
    }

    function onRowUpdating(e)
    {
        let gridClient = _.cloneDeep(e.oldData);
        const updatedProperties = Object.keys(e.newData);
        const updatedValues = Object.values(e.newData);

        updatedProperties.forEach(function (key, index)
        {
            gridClient[key] = updatedValues[index];
        });
        let clientToEdit: ClientDto = gridClient;
        console.log(clientToEdit);
        editClient(clientToEdit);
    }

    function onRowInserting(e: RowInsertingEvent<ClientDto, number>)
    {
        let client: ClientDto =
        {
            ...e.data,
            clientId: 0,
            emails: [],
            currentLiveStatus: emptyClientLiveStatus,
            currentParticipationStatus: emptyClientParticipationStatus,
        };
        console.log(client);
        addClient(client);
    }

    async function editClient(client)
    {
        try
        {
            await ClientService.postApiClientEditClient(client);
            loadClients();
        } catch { }
    }

    async function addClient(client)
    {
        try
        {
            await ClientService.postApiClientAddClient(client);
            loadClients();
        } catch { }
    }

    const onCellPrepared = (e) =>
    {
        if (e.rowType === "header")
        {
            switch (e.column.caption)
            {
                case ("Client Name"):
                    e.cellElement.title = "*Required";
                    break;
                case ("Trayport Name"):
                    e.cellElement.title = "*Required";
                    break;
                case ("Short Name"):
                    e.cellElement.title = "*Required";
                    break;
                case ("Exchange Id"):
                    e.cellElement.title = "Trayport Exchange Instrument Id. *Required for an exchange";
                    break;
                case ("Company Id"):
                    e.cellElement.title = "Trayport Company Id. *Required";
                    break;
                case ("Status"):
                    e.cellElement.title = "If client is active, this sets the client to be live or test status for a run.";
                    break;
                case ("Is Active"):
                    e.cellElement.title = "Sets client's current participation status to active (participating in a run) or inactive (not participating in a run)."
                    break;
            }
        }
    }

    const onInitNewRow = (e: any) =>
    {
        e.data.isExchange = false;
    };

    return (
        <>
            <PageContainerFull>
                <>
                    <div style={{ marginBottom: '10px' }}>
                        <MaterialButton color="secondary" onClick={addNewRow} size="large">
                            {'Add Client'}
                        </MaterialButton>
                    </div>
                    <DataGrid
                        ref={_dataGrid}
                        dataSource={clients}
                        keyExpr="clientId"
                        showBorders={true}
                        onRowUpdating={onRowUpdating}
                        onRowInserting={onRowInserting}
                        onInitNewRow={onInitNewRow}
                        onCellPrepared={(e) => onCellPrepared(e)}
                    >
                        <Selection mode="single" />
                        <HeaderFilter visible={true} />
                        <Paging enabled={false} />
                        <Editing
                            mode="row"
                            useIcons={true}
                            allowUpdating={true}
                            allowAdding={false}
                        />

                        <MasterDetail enabled={true} component={ClientEmails} />
                        <Column dataField="clientName" caption="Client Name" sortOrder={'asc'} />
                        <Column
                            dataField="trayportName"
                            caption="Trayport Name"
                        />
                        <Column
                            dataField="shortName"
                            caption="Short Name"
                            width={150}
                        />
                        <Column
                            dataField="currentLiveStatus"
                            caption="Status"
                            cellRender={(cellInfo) => (
                                <RenderStatusActionButton cellInfo={cellInfo} />
                            )}
                            width={115}
                            visible={true}
                            allowEditing={false}
                            alignment="center"
                            showInColumnChooser={false}
                        />
                        <Column
                            dataField="currentParticipationStatus"
                            width={115}
                            caption="Is Active"
                            allowEditing={false}
                            alignment="center"
                            cellRender={(cellInfo) => (
                                <RenderActionButton cellInfo={cellInfo} />
                            )}
                            visible={true}
                            showInColumnChooser={false}
                        />
                        <Column dataField="isExchange" caption="Exchange" width={120} />
                        <Column
                            dataField="trayportCompanyId"
                            caption="Company Id"
                            width={250}
                        />
                        <Column
                            dataField="trayportExchangeInstrumentId"
                            caption="Exchange Id"
                            width={250}
                        />
                        <Column caption="Actions" type="buttons" width={110}>
                            <Button name="edit" />
                        </Column>
                    </DataGrid>
                </>
            </PageContainerFull>
        </>
    );
};

export default Clients;
