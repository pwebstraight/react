//add node modules
npm install --legacy-peer-deps

//run the library
npm run storybook

//build deployment package in dist folder
npm run rollup-build-lib