
function Get-Version()
{
    #Start-Sleep -Seconds 5
    Write-Host "Hello version"

    npm run rollup-build-lib
}

$functions = {
    function FOO 
    { 
        Write-Host "Start" | out-host
        #npm run rollup-build-lib
        Start-Sleep -Seconds 10
        #Write-Host "Hello version"
    }
}

$timeout = 20

Start-Job -FilePath .\rollup.ps1

#$job = Start-Job -InitializationScript $functions -ScriptBlock ${function:Get-Version}
#$job = Start-Job { Get-Version }
#$done = $job |Wait-Job -TimeOut $timeout
#if($done){
#    Write-Host "Success"
#}
#else {
#    Write-Host "Time out"
#}



#npm run rollup-build-lib

Write-Host "Hello world1"
#Get-Version
Write-Host "Hello world1"