import resolve from "@rollup/plugin-node-resolve";
import commonjs from "@rollup/plugin-commonjs";
import typescript from "@rollup/plugin-typescript";
import image from '@rollup/plugin-image';
import preserveDirectives from "rollup-plugin-preserve-directives";
import PeerDepsExternalPlugin from 'rollup-plugin-peer-deps-external';
import packageJson from "./package.json" assert { type: "json" };

import postcss from "rollup-plugin-postcss"; 

export default [
    {
        input: "src/index.ts",
        output: [                      
            {
                format: 'es',
                dir: 'dist',
                preserveModules: true,
                preserveModulesRoot: 'src',
            },
            {
                file: packageJson.main,
                format: "cjs",
                sourcemap: true             
            },
            {
                file: packageJson.module,
                format: "esm",
                sourcemap: true                
            },                           
        ],        
        external: ['src/api/index', 'src/config'],
        plugins: [     
            typescript(),                     
            PeerDepsExternalPlugin(),            
            commonjs(),            
            image(),
            preserveDirectives.default(),
            resolve({                
                moduleDirectories: ['node_modules']
            }),            
                      
            postcss({
                plugins: []
              })
        ],
    },
    {      
        input: "./dist/index.d.ts",
        output: [{ file: "dist/index.d.ts", format: "esm" }],        
        external: [/\.(css|less|scss)$/, ...Object.keys(packageJson.peerDependencies || {})]        
    },
];

