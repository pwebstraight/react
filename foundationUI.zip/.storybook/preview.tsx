import type { Preview } from "@storybook/react";
import { Provider } from "react-redux"
import { store } from "../src/store/configureStore"
import { UserState } from "../src/api/models/UserState";
import { configureStore, createSlice } from '@reduxjs/toolkit';

// export const MockedState = {
//   tasks: [
//     { id: '1', title: 'Task 1' },
//     { title: 'Task 2' }    
//   ],
//   status: 'idle',
//   error: null,
// };

// const Mockstore = ({ UserState, children }) => (
//   <Provider
//     store={configureStore({
//       reducer: {
//         user: createSlice({
//           name: 'user',
//           initialState: UserState,
//           reducers: {
            
//           },
//         }).reducer,
//       },
//     })}
//   >
//     {children}
//   </Provider>
// );

const preview: Preview = {
  parameters: {
    actions: { argTypesRegex: "^on[A-Z].*" },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
  },  
  //decorators: [
  //  (story) => <Mockstore UserState={MockedState}>{story()}</Mockstore>,
  //],
};

export const decorators = [
  Story => (
    <Provider store={store}>      
      <Story />        
    </Provider>
  )
];

export default preview;
