export interface Oidc {
    clientId: string;
    issuer: string;
    redirectUri: string;
    scopes: string[];
    pkce: boolean;
    disableHttpsCheck: boolean;
}

export interface DynamicConfig {
    apiUrl: string;
    app_issuer: string;
    app_client_id: string;
    oidc: Oidc;
    library: any;
}

export interface LibraryMenuScreen {
    label: string,
    routing: string,
    icon: string,
    access: Array<string>
}

export interface LibraryMenu {
    section : string,
    showSectionTitle : boolean,
    screens: Array<LibraryMenuScreen>
}

export interface LibraryConfig {
    title: string,
    description: string,
    logoTooltip: string,          
    usersUrl: string,
    menu: Array<LibraryMenu>
}

class GlobalConfig {
    config: DynamicConfig;
}

export const globalConfig = new GlobalConfig();

export const globalConfigUrl = "../config.json";