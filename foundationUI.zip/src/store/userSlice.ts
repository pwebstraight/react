import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import { UserService } from 'src/api/services/UserService';
import { UserDto } from "src/api/index";

interface UserState {    
    user: UserDto;
}

const initialState: UserState = {    
    user: null,
}

export const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        saveUser: (state, action) => {
            state.user = action.payload;
        }
    },
    extraReducers: (builder) => {
        // once getCurrentUser method is called for the first time user is saved into a slice
        builder.addCase(getCurrentUser.fulfilled, (state, action) => {
            state.user = action.payload;
        })
    }
})

export const getCurrentUser = createAsyncThunk('getCurrentUser', async () =>
{   
    const response = await UserService.postApiUserGetCurrentUser();
    return response;
})  

export const {saveUser} = userSlice.actions;

export default userSlice;