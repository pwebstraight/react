/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import axios from 'axios';
import type { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios';
import FormData from 'form-data';

import type { ApiRequestOptions } from './ApiRequestOptions';
import type { ApiResult } from './ApiResult';
import { CancelablePromise } from './CancelablePromise';
import type { OnCancel } from './CancelablePromise';
import type { OpenAPIConfig } from './OpenAPI';
import OktaAuth from '@okta/okta-auth-js';
const isDefined = <T>(value: T | null | undefined): value is Exclude<T, null | undefined> => {
    return value !== undefined && value !== null;
};

const isString = (value: any): value is string => {
    return typeof value === 'string';
};

const isStringWithValue = (value: any): value is string => {
    return isString(value) && value !== '';
};

const isBlob = (value: any): value is Blob => {
    return (
        typeof value === 'object' &&
        typeof value.type === 'string' &&
        typeof value.stream === 'function' &&
        typeof value.arrayBuffer === 'function' &&
        typeof value.constructor === 'function' &&
        typeof value.constructor.name === 'string' &&
        /^(Blob|File)$/.test(value.constructor.name) &&
        /^(Blob|File)$/.test(value[Symbol.toStringTag])
    );
};

const isFormData = (value: any): value is FormData => {
    return value instanceof FormData;
};

const isSuccess = (status: number): boolean => {
    return status >= 200 && status < 300;
};

const base64 = (str: string): string => {
    try {
        return btoa(str);
    } catch (err) {
        // @ts-ignore
        return Buffer.from(str).toString('base64');
    }
};

const getQueryString = (params: Record<string, any>): string => {
    const qs: string[] = [];

    const append = (key: string, value: any) => {
        qs.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
    };

    const process = (key: string, value: any) => {
        if (isDefined(value)) {
            if (Array.isArray(value)) {
                value.forEach(v => {
                    process(key, v);
                });
            } else if (typeof value === 'object') {
                Object.entries(value).forEach(([k, v]) => {
                    process(`${key}[${k}]`, v);
                });
            } else {
                append(key, value);
            }
        }
    };

    Object.entries(params).forEach(([key, value]) => {
        process(key, value);
    });

    if (qs.length > 0) {
        return `?${qs.join('&')}`;
    }

    return '';
};

const getFormData = (options: ApiRequestOptions): FormData | undefined => {
    if (options.formData) {
        const formData = new FormData();

        const process = (key: string, value: any) => {
            if (isString(value) || isBlob(value)) {
                formData.append(key, value);
            } else {
                formData.append(key, JSON.stringify(value));
            }
        };

        Object.entries(options.formData)
            .filter(([_, value]) => isDefined(value))
            .forEach(([key, value]) => {
                if (Array.isArray(value)) {
                    value.forEach(v => process(key, v));
                } else {
                    process(key, value);
                }
            });

        return formData;
    }
    return undefined;
};

type Resolver<T> = (options: ApiRequestOptions) => Promise<T>;

const resolve = async <T>(options: ApiRequestOptions, resolver?: T | Resolver<T>): Promise<T | undefined> => {
    if (typeof resolver === 'function') {
        return (resolver as Resolver<T>)(options);
    }
    return resolver;
};

const getHeaders = async (options: ApiRequestOptions, formData?: FormData): Promise<Record<string, string>> => {
        
    //const additionalHeaders = await resolve(options, config.HEADERS);
    const formHeaders = typeof formData?.getHeaders === 'function' && formData?.getHeaders() || {}

    const headers = Object.entries({
        Accept: 'application/json',
        //...additionalHeaders,
        ...options.headers,
        ...formHeaders,
    })
    .filter(([_, value]) => isDefined(value))
    .reduce((headers, [key, value]) => ({
        ...headers,
        [key]: String(value),
    }), {} as Record<string, string>);
        
    if (options.body) {
        if (options.mediaType) {
            headers['Content-Type'] = options.mediaType;
        } else if (isBlob(options.body)) {
            headers['Content-Type'] = options.body.type || 'application/octet-stream';
        } else if (isString(options.body)) {
            headers['Content-Type'] = 'text/plain';
        } else if (!isFormData(options.body)) {
            headers['Content-Type'] = 'application/json';
        }
    }

    return headers;
};

const getRequestBody = (options: ApiRequestOptions): any => {
    if (options.body) {
        return options.body;
    }
    return undefined;
};

//const oidc = '0oaabbehvsezKOUL10i7';
//const apiUrl = 'https://localhost:7132/';
//const token = 'eyJraWQiOiJJZUhzUll0UkxyNWREQVpwZk1LTzlBald2ZVp3SkFWd0U3MkdlOC1GTE5BIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiIwMHU4cXJhb3R3M0duU2FwVzBpNyIsIm5hbWUiOiJUYWJha292LCBQbGFtZW4iLCJlbWFpbCI6IlBsYW1lbi5UYWJha292QHRwaWNhcC5jb20iLCJ2ZXIiOjEsImlzcyI6Imh0dHBzOi8vdHBpY2FwLm9rdGEtZW1lYS5jb20vb2F1dGgyL2RlZmF1bHQiLCJhdWQiOiIwb2FhYmJlaHZzZXpLT1VMMTBpNyIsImlhdCI6MTY5NzA5NDMzMSwiZXhwIjoxNjk3MDk3OTMxLCJqdGkiOiJJRC5kSEtwY1R3SDkyNmo1ejByakxxLXY5S1JHdUlHVlI2TF9CWS1JZ2pIZ0Q4IiwiYW1yIjpbInB3ZCJdLCJpZHAiOiIwb2F0emVpdTZUU3lOMmtoRDBpNiIsIm5vbmNlIjoieDdCTVo1M013WDFoSm5xN2FFZFhNa3M0T25NUGtacjlRQmw4OGVaUzJiV0FYQ2ZyVHM5b3lScEFiUmVzYWNqTSIsInByZWZlcnJlZF91c2VybmFtZSI6IlBsYW1lbi5UYWJha292QHRwaWNhcC5jb20iLCJhdXRoX3RpbWUiOjE2OTY4NTgzNzgsImF0X2hhc2giOiJ1U2Izam0yclhQRXdWeGRwUl9JREd3In0.YjeWd7UpffK6vH5ECGKSAq09GIyvqUvkgGKY3UOsjni-jsqfQ_2NGsq_W0VMdkcTeaTTRAOmm42YLw_QaURyqlixUZnjCxtMeprz5wOI0jT6qLcwjgbjPBzgpWiNNtWR9OFn7wKiPQ-IzoR3VRljrlQZJAvewTUyCqsM5z2qCRcV6Rlzq0tTsZ7PRzUG7qatRCMERKpl7ubeWpOa3H0c1bNpXvXi89Taz87_ixV5SmCwGkpJOuQcMRkvtk9iLluxzT4ga9EUYNiJ7HhJh71O6mMRhVuAtrnqgZ8QbKz1P1U93mlBU87T0akuJDge8ClmgzAgmZoVOBiHvojKsNgvBg';

const sendRequest = async <T>(     
    options: ApiRequestOptions,
    url: string,
    body: any,
    formData: FormData | undefined,
    headers: Record<string, string>,
    onCancel: OnCancel
): Promise<AxiosResponse<T>> => {
    const source = axios.CancelToken.source();
                        
    const requestConfig: AxiosRequestConfig = {
        url,
        headers,
        data: body ?? formData,
        method: options.method,        
        cancelToken: source.token,
    };

    onCancel(() => source.cancel('The user aborted a request.'));

    try {        
        return await axios.request(requestConfig);
    } catch (error) {
        const axiosError = error as AxiosError<T>;
        if (axiosError.response) {
            return axiosError.response;
        }
        throw error;
    }
};

const getResponseHeader = (response: AxiosResponse<any>, responseHeader?: string): string | undefined => {
    if (responseHeader) {
        const content = response.headers[responseHeader];
        if (isString(content)) {
            return content;
        }
    }
    return undefined;
};

const getResponseBody = (response: AxiosResponse<any>): any => {
    if (response.status !== 204) {
        return response.data;
    }
    return undefined;
};

/**
 * Request method
 * @param config The OpenAPI configuration object
 * @param options The request options from the service
 * @returns CancelablePromise<T>
 * @throws ApiError
 */
export const request = <T>(config: OpenAPIConfig, options: ApiRequestOptions): CancelablePromise<T> => {
    return new CancelablePromise(async (resolve, reject, onCancel) => {
        try {                       
            const url = options.url;                 
            const formData = getFormData(options);
            const body = getRequestBody(options);
            const headers = await getHeaders(options, formData);

            if (!onCancel.isCancelled) {
                const response = await sendRequest<T>(options, url, body, formData, headers, onCancel);
                const responseBody = getResponseBody(response);
                const responseHeader = getResponseHeader(response, options.responseHeader);

                const result: ApiResult = {
                    url,
                    ok: isSuccess(response.status),
                    status: response.status,
                    statusText: response.statusText,
                    body: responseHeader ?? responseBody,
                };
                
                resolve(result.body);
            }
        } catch (error) {
            reject(error);
        }
    });
};
