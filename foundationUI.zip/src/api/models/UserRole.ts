
export enum UserRole {
    ADMIN = 'Admin',
    BROKER = 'Broker',
    OPERATIONS = 'Operations',
    SUPPORT = 'Support',
}
