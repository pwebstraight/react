/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserRole } from './UserRole';

export type UserDto = {
    id?: number;
    email?: string | null;
    userName?: string | null;
    role?: UserRole;
    isActive?: boolean;
};
