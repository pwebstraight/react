import { UserDto } from "../models/UserDto";

export interface UserState {    
    user: UserDto;
}