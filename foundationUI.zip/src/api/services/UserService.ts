/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { UserDto } from '../models/UserDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class UserService {

    /**
     * @returns UserDto Success
     * @throws ApiError
     */
    public static postApiUserGetAllUsers(): CancelablePromise<Array<UserDto>> {              
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/User/GetAllUsers',
        });
    }

    /**
     * @returns UserDto Success
     * @throws ApiError
     */
    public static postApiUserGetCurrentUser(): CancelablePromise<UserDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/User/GetCurrentUser',
        });
    }    

    /**
     * @param requestBody 
     * @returns UserDto Success
     * @throws ApiError
     */
    public static postApiUserSaveUser(
requestBody?: UserDto,
): CancelablePromise<UserDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/User/SaveUser',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
