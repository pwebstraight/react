import type { Meta, StoryObj } from '@storybook/react';
import { withRouter } from 'storybook-addon-react-router-v6';
import { Header } from '../components/Header';

const meta = {
  title: 'Example/Header',
  decorators: [withRouter],
  component: Header,  
} satisfies Meta<typeof Header>;

export default meta;
type Story = StoryObj<typeof meta>;

export const MainHeader: Story = {
  args: {
    config: {        
      title: "Interconnector",
      description: "application description",
      logoTooltip: "Inter Connector Lib"
    }
  },
};

