import type { Meta, StoryObj } from '@storybook/react';
import { withRouter } from 'storybook-addon-react-router-v6';
import { SuspenseLoader } from './../components/SuspenseLoader';

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
const meta = {
  title: 'Example/SuspenseLoader',  
  component: SuspenseLoader,  
} satisfies Meta<typeof SuspenseLoader>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Main: Story = {
  args: {
    
  },
};

