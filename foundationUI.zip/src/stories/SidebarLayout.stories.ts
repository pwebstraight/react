import type { Meta, StoryObj } from '@storybook/react';
import { withRouter } from 'storybook-addon-react-router-v6';
import { SidebarLayout } from '../components/SidebarLayout';

const meta = {
  title: 'Example/SidebarLayout',
  decorators: [withRouter],  
  component: SidebarLayout,  
} satisfies Meta<typeof SidebarLayout>;

export default meta;
type Story = StoryObj<typeof meta>;

export const MainLayout: Story = {
  args: {
    config: {        
      title: "Interconnector",
      description: "application description",
      logoTooltip: "Inter Connector Lib",            
      usersUrl: "users",
      menu:
      [ 
        {            
          section : "Main",
          showSectionTitle : false,
          screens :
          [                
            {
              label : "Dashboard",                
              routing : "/",
              icon : "AssignmentTurnedInIcon",
              access : [ "Broker", "Operation", "Support", "Admin" ]
            },
            {
              label : "Capacity",                
              routing : "/capacity",
              icon : "StorageTwoToneIcon",
              access : [ "Broker" ]
            },
            {
              label : "Reserve",                
              routing : "/bookCapacity",
              icon : "EmojiEventsIcon",
              access : [ "Broker", "Operation", "Support", "Admin" ]
            },
            {
              label : "History",                
              routing : "/history",
              icon : "StorageTwoToneIcon",
              access : [ "Broker", "Operation", "Support", "Admin" ]
            }
          ]
        },
        {
          section : "Admin",
          showSectionTitle : true,
          screens :
          [
            {
              label : "Shippers",                
              routing : "/shippers",
              icon : "LocalShippingIcon",
              access : [ "Admin" ]
            },                  
            {
              label : "Imports",                
              routing : "/imports",
              icon : "ImportExportIcon",
              access : [ "Admin" ]
            },  
          ]
        }
      ]        
    }
  },
};

