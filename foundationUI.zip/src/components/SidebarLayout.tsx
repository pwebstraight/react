import { useCallback, useEffect } from 'react';
import { ReactNode } from 'react';
import { Box, alpha, useTheme } from '@mui/material';
import { Outlet } from 'react-router-dom';
import OktaAuth from '@okta/okta-auth-js';
import { globalConfig } from 'src/config';
import { Users } from './Users';
import { getCurrentUser } from "../store/userSlice";
import { useAppDispatch, useAppSelector } from "src/store/configureStore";

import Sidebar from './Sidebar';
import Header from './Header';

interface SidebarLayoutProps {
  children?: ReactNode;  
}

export const SidebarLayout = ({ children }: SidebarLayoutProps) => {
  const theme = useTheme();
  const dispatch = useAppDispatch();
  const { user } = useAppSelector(state => state.user);
   
  let oktaAuth: any = null;
  if (globalConfig.config.oidc)
    oktaAuth = new OktaAuth(globalConfig.config.oidc);

  const initApp = useCallback(async () => {    
    if (oktaAuth) 
    {
      if(!await oktaAuth.isAuthenticated())
      {        
        await oktaAuth.signInWithRedirect( { originalUri: window.location.origin } );
      } 
      else 
      {        
        if (!user) 
        {
          await dispatch(getCurrentUser());
        }                
      }
    }
  }, [getCurrentUser]);

  useEffect(() => {   
    initApp();
  }, [initApp])
    
  function checkUsersUrl() {
    if (globalConfig)
      return window.location.href.indexOf(globalConfig.config.library.usersUrl) > 0;
    
    return false;
  }

  return (
    <>      
      <Box
        sx={{
          flex: 1,
          height: '100%',

          '.MuiPageTitle-wrapper': {
            background: alpha('#ffffff', 0.5),              
            marginBottom: `${theme.spacing(4)}`,
            boxShadow: `0px 2px 4px -3px ${alpha('#223354', 0.1)}, 0px 5px 12px -4px ${alpha('#223354', 0.05)}`              
          }
        }}
      >
        <Header config={globalConfig?.config.library} />
        <Sidebar config={globalConfig?.config.library} />
        <Box
          sx={{
            position: 'relative',
            zIndex: 5,
            display: 'block',
            flex: 1,
            pt: `${'80px'}`,
            [theme.breakpoints.up('lg')]: {
              ml: `${'290px'}`
            }
          }}
        >
          <Box display="block">
            <Outlet />

            { checkUsersUrl() ?(
                <Users config={globalConfig?.config.library} /> 
              ) : ( 
                <div>{children}</div>
            )}
          </Box>
        </Box>
      </Box>      
    </>
  );
};

export default SidebarLayout;
