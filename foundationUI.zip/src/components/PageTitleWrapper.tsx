import { FC, ReactNode } from 'react';
import { Box, styled } from '@mui/material';

const PageTitle = styled(Box)(
  ({ theme }) => `
        padding: ${theme.spacing(2)};        
`
);

interface PageTitleWrapperProps {
  children?: ReactNode;
} 

export const PageTitleWrapper: FC<PageTitleWrapperProps> = ({ children }) => {
  return (
    <PageTitle className="MuiPageTitle-wrapper" style={{marginBottom: '15px'}}>
      <div style={{color: '#9F9F9F'}} variant="h3" component="h4" gutterBottom>
        {children}
      </div>      
    </PageTitle>   
    
  );
};

export default PageTitleWrapper;
