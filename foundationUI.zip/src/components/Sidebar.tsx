import {
  Box,
  Drawer,
  alpha,
  styled,
  Divider,
  useTheme,
  Button,
  lighten,
  darken,
  Tooltip
} from '@mui/material';

import SidebarMenu from './SidebarMenu';

const SidebarWrapper = styled(Box)(
  ({ theme }) => `
        width: ${'290px'};
        min-width: ${'290px'};
        color: ${alpha('#ffffff', 0.7)};
        position: relative;
        z-index: 7;
        height: 100%;
        padding-bottom: 68px;
`
);

interface SidebarProps {  
  config: any;
}

export const Sidebar = ({ config }: SidebarProps) => {
   
  return (
    <>
      <SidebarWrapper
        sx={{
          display: {
            xs: 'none',
            lg: 'inline-block'
          },
          position: 'fixed',
          left: 0,
          top: 0,
          background: alpha(lighten('#ffffff', 0.1), 0.5),            
          boxShadow: 'none',
          borderRight: '2px solid #ddd'          
        }}
      >        
         <SidebarMenu config={config} />        
      </SidebarWrapper>      
    </>
  );
}

export default Sidebar;
