import
    {
        ListSubheader,
        alpha,
        Box,
        List,        
        Button,
        ListItem        
    } from '@mui/material';
import { NavLink as RouterLink } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import { LibraryConfig, LibraryMenuScreen } from 'src/config';

import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import AccountCircleTwoToneIcon from '@mui/icons-material/AccountCircleTwoTone';
import ImportExportIcon from '@mui/icons-material/ImportExport';
import StorageTwoToneIcon from '@mui/icons-material/StorageTwoTone';
import CheckBoxTwoToneIcon from '@mui/icons-material/CheckBoxTwoTone';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';

const MenuWrapper = styled(Box)(

    ({ theme }) => `
  .MuiList-root {
    padding: ${theme.spacing(1)};

    & > .MuiList-root {
      padding: 0 ${theme.spacing(0)} ${theme.spacing(1)};
    }
  }

    .MuiListSubheader-root {
      text-transform: uppercase;
      font-weight: bold;
      font-size: ${theme.typography.pxToRem(12)};
      color: ${alpha('#223354', 0.5)};
      padding: ${theme.spacing(0, 2.5)};
      line-height: 1.4;
    }
`
);

const SubMenuWrapper = styled(Box)(
    ({ theme }) => `
    .MuiList-root {

      .MuiListItem-root {
        padding: 1px 0;

        .MuiBadge-root {
          position: absolute;
          right: ${theme.spacing(3.2)};

          .MuiBadge-standard {
            background: ${theme.palette.primary.main};
            font-size: ${theme.typography.pxToRem(10)};
            font-weight: bold;
            text-transform: uppercase;
            color: ${theme.palette.primary.contrastText};
          }
        }
    
        .MuiButton-root {
          display: flex;
          color: ${alpha('#223354', 0.7)};
          background-color: transparent;
          width: 100%;
          justify-content: flex-start;
          padding: ${theme.spacing(1.2, 3)};

          .MuiButton-startIcon,
          .MuiButton-endIcon {
            transition: ${theme.transitions.create(['color'])};

            .MuiSvgIcon-root {
              font-size: inherit;
              transition: none;
            }
          }

          .MuiButton-startIcon {
            color: ${alpha('#223354', 0.3)};
            font-size: ${theme.typography.pxToRem(20)};
            margin-right: ${theme.spacing(1)};
          }
          
          .MuiButton-endIcon {
            color: ${alpha('#223354', 0.5)};
            margin-left: auto;
            opacity: .8;
            font-size: ${theme.typography.pxToRem(20)};
          }

          &.active,
          &:hover {
            background-color: ${alpha('rgba(236, 238, 242)', 1)};
            color: ${alpha('#223354', 1)};

            .MuiButton-startIcon,
            .MuiButton-endIcon {
              color: ${alpha('#223354', 1)};;
            }
          }
        }

        &.Mui-children {
          flex-direction: column;

          .MuiBadge-root {
            position: absolute;
            right: ${theme.spacing(7)};
          }
        }

        .MuiCollapse-root {
          width: 100%;

          .MuiList-root {
            padding: ${theme.spacing(1, 0)};
          }

          .MuiListItem-root {
            padding: 1px 0;

            .MuiButton-root {
              padding: ${theme.spacing(0.8, 3)};

              .MuiBadge-root {
                right: ${theme.spacing(3.2)};
              }

              &:before {
                content: ' ';
                background: ${alpha('#223354', 1)};
                opacity: 0;
                transition: ${theme.transitions.create([
        'transform',
        'opacity'
    ])};
                width: 6px;
                height: 6px;
                transform: scale(0);
                transform-origin: center;
                border-radius: 20px;
                margin-right: ${theme.spacing(1.8)};
              }

              &.active,
              &:hover {

                &:before {
                  transform: scale(1);
                  opacity: 1;
                }
              }
            }
          }
        }
      }
    }
`
);

interface SidebarMenuProps {  
  config: LibraryConfig;
}

export const SidebarMenu = ({ config }: SidebarMenuProps) => { 
                  
    function RenderMenuIcon(icon: string) {
      switch(icon) {
        case "AssignmentTurnedInIcon":
          return <AssignmentTurnedInIcon />
        case "StorageTwoToneIcon":
          return <StorageTwoToneIcon />
        case "EmojiEventsIcon":
          return <EmojiEventsIcon />
        case "LocalShippingIcon":
          return <LocalShippingIcon />
        case "ImportExportIcon":
          return <ImportExportIcon />
        case "AssignmentTurnedInIcon":
          return <AssignmentTurnedInIcon />
        case "CheckBoxTwoToneIcon":
          return <CheckBoxTwoToneIcon />
        default:
          return <AccountCircleTwoToneIcon />
      }
    }

    return (
        <>
            <MenuWrapper style={{marginTop: '100px'}}>
                <List
                  component="div"
                >
                    <SubMenuWrapper>
                        <List component="div">
                          {config?.menu[0].screens.map((screen: LibraryMenuScreen) => (
                              <ListItem component="div">
                                <Button
                                  disableRipple
                                  component={RouterLink}                                    
                                  to={screen.routing}
                                  startIcon={RenderMenuIcon(screen.icon)}
                                >
                                  {screen.label}
                              </Button>
                          </ListItem>
                          ))}                                                                                        
                        </List>
                    </SubMenuWrapper>
                </List>
                <List
                    component="div"
                    subheader={                        
                        <ListSubheader component="div" disableSticky>
                            {config?.menu[1].showSectionTitle &&
                              config?.menu[1].section
                            }
                        </ListSubheader>
                    }
                >
                    <SubMenuWrapper>
                        <List component="div">
                          {config?.menu[1].screens && config?.menu[1].screens.map((screen: LibraryMenuScreen) => (
                            <ListItem component="div">
                                <Button
                                  disableRipple
                                  component={RouterLink}                                    
                                  to={screen.routing}
                                  startIcon={RenderMenuIcon(screen.icon)}
                                >
                                  {screen.label}
                                </Button>
                            </ListItem>
                          ))}     
                           <ListItem component="div">
                              <Button
                                  disableRipple
                                  component={RouterLink}                                  
                                  to={config?.usersUrl}
                                  startIcon={<AccountCircleTwoToneIcon />}
                              >
                                Users
                              </Button>
                          </ListItem>                         
                        </List>
                    </SubMenuWrapper>
                </List>
            </MenuWrapper>
        </>
    );
}

export default SidebarMenu;
