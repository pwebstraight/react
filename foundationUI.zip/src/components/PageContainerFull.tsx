import { FC, ReactNode } from 'react';
import PageContainer from '../components/PageContainer';

import {  
  Grid,
  CardContent,   
} from "@mui/material";

interface PageContainerFullWrapperProps {
  children?: ReactNode;
}

export const PageContainerFull: FC<PageContainerFullWrapperProps> = ({ children }) => {
  return (
    <PageContainer>
      <CardContent>      
        <Grid style={{marginTop: '0px', marginLeft: '0px'}} container spacing={4}>
          <Grid item xs={12} style={{paddingLeft: '0', paddingRight: '15px', paddingTop: '0'}}>       
            {children}
          </Grid>
        </Grid> 
      </CardContent>
    </PageContainer>
  )
};

export default PageContainerFull;
