import { useState, useContext, useEffect } from 'react';
import {
  Box,
  alpha,
  Stack,
  lighten,
  Divider,
  IconButton,
  Tooltip,
  styled,
  useTheme} from '@mui/material';
import Logo from './Logo';
import HeaderUserbox from './HeaderUserBox';


const HeaderWrapper = styled(Box)(
  ({ theme }) => `
        height: ${'80px'};
        color: ${'#6E759F'};
        padding: ${theme.spacing(0, 2)};
        right: 0;
        z-index: 6;        
        backdrop-filter: blur(3px);
        position: fixed;
        justify-content: space-between;        
        @media (min-width: ${'1840px'}) {
            left: ${'290px'};
            width: auto;
        }
`);

interface HeaderMenuProps {  
  config: any;
}


export const Header = ({ config }: HeaderMenuProps) => {
              
  return (
    <HeaderWrapper
      display="flex"
      alignItems="center"
      style={{ left: '0px', paddingLeft: '20px', zIndex: '1000', boxShadow: 'rgb(0 0 0 / 20%) 0px 2px 4px -1px, rgb(0 0 0 / 14%) 0px 4px 5px 0px, rgb(0 0 0 / 12%) 0px 1px 10px 0px' }}
      sx={{
        backgroundColor: '#5F6EEC',
        boxShadow: `0px 2px 8px -3px ${alpha('#223354', 0.2)}, 0px 5px 22px -4px ${alpha('#223354', 0.1)}`          
      }}
    >
      <Stack
        direction="row"
        divider={<Divider orientation="vertical" flexItem />}
        alignItems="center"
        spacing={2}
      >

        <Box mt={3} style={{ marginTop: '0px' }}>
          <Box
            mx={2}
            sx={{
              width: 52,
              backgroundColor: "#5F6EEC"
            }}
          >
            <Logo tooltip={config?.logoTooltip} />
          </Box>
        </Box>   
        <h2 style={{ color: 'white', marginLeft: '180px' }}>{config?.title}
          <div style={{ fontSize: '14px', fontWeight: 'normal', marginTop: '-3px' }}>
            {config?.description}
          </div>
        </h2>     
      </Stack>
      <Box display="flex" alignItems="center">        
        <div>
          <HeaderUserbox oidc={config.oidc} />
        </div>      
      </Box>
    </HeaderWrapper>
  );
}

export default Header;
