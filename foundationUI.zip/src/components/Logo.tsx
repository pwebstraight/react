import {
    Box,
    Tooltip,
    Badge,
    TooltipProps,
    tooltipClasses,
    styled,
    useTheme
  } from '@mui/material';
  import { Link } from 'react-router-dom';
  
  const LogoWrapper = styled(Link)(
    ({ theme }) => `
          color: ${theme.palette.text.primary};
          display: flex;
          text-decoration: none;
          width: 53px;
          margin: 0 auto;
          font-weight: ${theme.typography.fontWeightBold};
  `
  );
  
    
  const TooltipWrapper = styled(({ className, ...props }: TooltipProps) => (
    <Tooltip {...props} classes={{ popper: className }} />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: '#FFFFFF',
      color: theme.palette.getContrastText('#FFFFFF'),
      fontSize: theme.typography.pxToRem(12),
      fontWeight: 'bold',
      borderRadius: '6px',
      boxShadow:
        '0 .2rem .8rem rgba(7,9,25,.18), 0 .08rem .15rem rgba(7,9,25,.15)'
    },
    [`& .${tooltipClasses.arrow}`]: {
      color: '#FFFFFF'
    }
  }));
  
  export interface LogoProps {
    tooltip: string;    
  }
  
  export const Logo = ({ tooltip }: LogoProps) => {
        
    return (
      <TooltipWrapper
        
        title={tooltip} 
        arrow
      >
        <LogoWrapper to="/" style={{zIndex: '2000'}}>        
          <img src="/TPICAP_SPECIAL_USE_RGB.SVG" height='40px' />
        </LogoWrapper>
      </TooltipWrapper>
    );
  }
  
  export default Logo;
  