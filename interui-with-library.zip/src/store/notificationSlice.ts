import { createSlice } from "@reduxjs/toolkit"
import { UserNotification } from 'src/models/userNotification';

interface NotificationState {
    userNotifications: UserNotification[];
}

const initialState: NotificationState = {
    userNotifications: [],
}

export const notificationSlice = createSlice({
    name: 'notification',
    initialState,
    reducers: {
        addNotification: (state, action) => {
            if (state.userNotifications.length === 5) state.userNotifications.shift();

            state.userNotifications.unshift(action.payload);
            //state.userNotifications.push(action.payload);

        },
        saveNotifications: (state, action) => {
            state.userNotifications = action.payload;
        }
    }
})

export const { addNotification, saveNotifications } = notificationSlice.actions;