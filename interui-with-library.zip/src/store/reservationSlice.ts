import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import { CapacityBookingDto, CapacityBookingService } from "src/api";

interface ReservationState
{
    reservations: CapacityBookingDto[];
}

const initialState: ReservationState = {   
    reservations: null,
}

export const reservationSlice = createSlice({
    name: 'reservation',
    initialState,
    reducers: {
        setReservations: (state, action) => {
            state.reservations = action.payload;
        } 
    },
    extraReducers: (builder) => {
        // once getReservations method is called for the first time user is saved into a slice
        builder.addCase(getReservations.fulfilled, (state, action) => {
            state.reservations = action.payload; 
        })
    }
})

export const getReservations = createAsyncThunk('getReservations', async () => {
    var reservations = await CapacityBookingService.postApiCapacityBookingGetAll()
    return reservations;
})
  
export const { setReservations } = reservationSlice.actions;