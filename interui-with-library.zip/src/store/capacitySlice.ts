import { createSlice } from "@reduxjs/toolkit"

interface CapacityState {    
    capacity: any;
}

const initialState: CapacityState = {    
    capacity: null,
}

export const capacitySlice = createSlice({
    name: 'capacity',
    initialState,
    reducers: {
        bookCapacity: (state, action) => {
            state.capacity = action.payload;
        }  
    }
})
  
export const {bookCapacity} = capacitySlice.actions;