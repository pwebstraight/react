import { createSlice } from "@reduxjs/toolkit"
import { ShipperService } from 'src/api/services/ShipperService';
import { ShipperDto } from "../api/models/ShipperDto";


interface ShipperState {

    shippers: ShipperDto[];

}

const initialState: ShipperState = { shippers: [] };

export const shipperSlice = createSlice({
    name: 'shippers',
    initialState,
    reducers: {
        loadShipperCash: (state, action) => {
            state.shippers = action.payload;
        }
    }
})

export const { loadShipperCash } = shipperSlice.actions;