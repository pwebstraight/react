export interface UserNotification {    
    
    message?: string;
    description?: string;
    user?: string; 
    dateCreated?: Date;
    isNew: boolean;   
  }