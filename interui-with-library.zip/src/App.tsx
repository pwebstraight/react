import { SetStateAction, useCallback, useEffect, useState } from "react";
import { useRoutes, useNavigate } from 'react-router-dom';
import Hub, { SubscribeToNotifications } from "src/api/Hub";
import router from 'src/router';
import 'devextreme/dist/css/dx.light.css';
import { useAppDispatch, useAppSelector } from "src/store/configureStore";
import { getReservations, setReservations } from "src/store/reservationSlice";
import OktaAuth, { toRelativeUrl } from '@okta/okta-auth-js';
import { Security } from '@okta/okta-react';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import { CssBaseline } from '@mui/material';
import ThemeProvider from './theme/ThemeProvider';
import { CapacityBookingDto } from './api';

function App(props: { oktaAuth: OktaAuth }) {

  const content = useRoutes(router);
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { reservations } = useAppSelector(state => state.reservations);
  const [updatedReservation, setUpdatedReservation] = useState<CapacityBookingDto>(null);  

  const initApp = useCallback(async () => {
    
    if(!Hub.SignalRConnection){
      SubscribeToNotifications(props.oktaAuth);
    }

    await dispatch(getReservations());
    
  }, [SubscribeToNotifications, getReservations]);

  useEffect(() => {
    initApp();
  }, [initApp])

  useEffect(() => {
    if (updatedReservation != null) {
      var newState = [];
      if (reservations != null) {
        newState = [...reservations];
        var existedReservationIndex = newState.findIndex(r => r.id == updatedReservation.id);
        if (existedReservationIndex >= 0) {
          newState[existedReservationIndex] = updatedReservation;
        }
        else {
          newState.push(updatedReservation);
        }
      }
      else {

        newState.push(updatedReservation);
      }
      dispatch(setReservations(newState));
    }
  }, [updatedReservation]);

  const restoreOriginalUri = (_oktaAuth, originalUri) => {
    navigate(toRelativeUrl(originalUri || '/', window.location.origin));
  };

  return (
    <Security oktaAuth={props.oktaAuth} restoreOriginalUri={restoreOriginalUri}>      
        <ThemeProvider>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <CssBaseline />
            {content}
          </LocalizationProvider>
        </ThemeProvider>      
    </Security>
  );
}

export default App;
