
export interface Oidc {
    clientId: string;
    issuer: string;
    redirectUri: string;
    scopes: string[];
    pkce: boolean;
    disableHttpsCheck: boolean;
}

export interface DynamicConfig {
    apiUrl: string;
    app_issuer: string;
    app_client_id: string;
    oidc: Oidc;
}

class GlobalConfig {
    config: DynamicConfig;
}

export const globalConfig = new GlobalConfig();

export const globalConfigUrl = "../config.json";