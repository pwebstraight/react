import ReactDOM from 'react-dom';
import { HelmetProvider } from 'react-helmet-async';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store/configureStore';
import 'nprogress/nprogress.css';
import { globalConfig, globalConfigUrl } from "./config";
import axios from "axios";
import App from "src/App";
import OktaAuth from '@okta/okta-auth-js';

axios.get(globalConfigUrl)
    .then((response) => {
        globalConfig.config = response.data;
        const oktaAuth = new OktaAuth(globalConfig.config.oidc);

        ReactDOM.render(
            <BrowserRouter>
                <HelmetProvider>
                    <Provider store={store}>
                        <App oktaAuth={oktaAuth} />
                    </Provider>
                </HelmetProvider>
            </BrowserRouter>,
            document.getElementById('root')
        );
    })
    .catch(e => {
        console.log(e);
        return <p style={{ color: "red", textAlign: "center" }}>Error while fetching global config {e.message} </p>;
    });