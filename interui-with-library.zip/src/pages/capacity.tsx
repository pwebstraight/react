import { useState, useEffect, ReactNode } from 'react';
import Hub from "src/api/Hub";
import { useAppDispatch } from "src/store/configureStore";
import { PricingService } from 'src/api/services/PricingService';
import { bookCapacity } from "src/store/capacitySlice";
import { useNavigate } from 'react-router-dom';
import PageTitleWrapper from 'Foundation.ReactUI/components/PageTitleWrapper';
import PageContainer from 'Foundation.ReactUI/components/PageContainer';

import {
CircularProgress,
CardContent
} from "@mui/material";

import DataGrid, {
    Column,
    Pager,
    Paging,
    Grouping,
    HeaderFilter,
    StateStoring,
    FilterRow,
} from 'devextreme-react/data-grid';
import { Tooltip } from 'devextreme-react/tooltip';
import { CapacityBookingDto, ContractDto, PeriodType, Terminal } from '../api';
import { CellPreparedEvent, ContentReadyEvent, RowPreparedEvent } from 'devextreme/ui/data_grid';

const Capacity = () => {
    const [contracts, setContracts] = useState<ContractDto[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isGridContentReady, setIsGridContentReady] = useState<boolean>(false);

    const navigate = useNavigate();
    const dispatch = useAppDispatch();

    const capacityGridState = 'capacityGridState';

    useEffect(() => {
        loadContracts();
    }, []);

    useEffect(() => {
        if (Hub.SignalRConnection) {
            Hub.SignalRConnection.on(
                'UpdateAllContracts',
                contracts => {
                    setContracts(contracts);
                });
        }
    }, []);

    async function loadContracts() {
        if (!isLoading) {
            setIsLoading(true);

            try {
                const contracts = await PricingService.postApiPricingCollectContracts();                
                setContracts(contracts);
            }
            finally {
                setIsLoading(false);
            }
        }
    }

    function buildFilterArray(sortOrder) {
        let headerFilters = [];
        contracts
            .filter((s) => s.periodType === sortOrder)
            .forEach(function (slot) {
                headerFilters.push({
                    text: slot.periodName,
                    value: ['periodName', '=', slot.periodName]
                });
            });

        return headerFilters;
    }

    function onRowPrepared(e: RowPreparedEvent<ContractDto, number>) {
        if (e.rowType === 'data') {
            if (e.rowIndex % 2 === 1) {
                e.rowElement.style.backgroundColor = "white";
            }
            else {
                e.rowElement.style.backgroundColor = "#e6faff";
            }
        }
    }

    function buildParentFilterArray(sortOrder) {
        let headerFilters = [];
        contracts
            .filter((s) => s.periodType === sortOrder)
            .forEach(function (slot) {
                if (headerFilters.length > 0) {
                    headerFilters.push('or');
                }
                const childArray = ['periodName', '=', slot.periodName];
                headerFilters.push(childArray);
            });
        return headerFilters;
    }

    function onContentReady(e: ContentReadyEvent<ContractDto, number>) {
        if (isGridContentReady) return;

        let currentGridState = localStorage.getItem(capacityGridState);
        if (currentGridState !== null) {
            var allGroups = currentGridState.split('');

            allGroups.forEach((group) => {
                const gridGroup = e.component.getKeyByRowIndex(parseInt(group) - 1);
                if (gridGroup != undefined) {
                    e.component.expandRow(gridGroup);
                }
            });
        }

        setIsGridContentReady(true);

    }

    function onRowExpanded(e) {
        let currentGridState = localStorage.getItem(capacityGridState);
        if (currentGridState === null) currentGridState = '';
        if (currentGridState.indexOf(e.key[0]) < 0) {
            currentGridState += getPeriodTypeIndex(e.key[0]);
            localStorage.setItem(capacityGridState, currentGridState);
        }
    }

    function onRowCollapsed(e) {
        let currentGridState = localStorage.getItem(capacityGridState);
        if (currentGridState === null) currentGridState = '';
        const periodTypeIndex = getPeriodTypeIndex(e.key[0]);
        if (currentGridState.indexOf(periodTypeIndex) >= 0) {
            currentGridState = currentGridState.replaceAll(periodTypeIndex, '');
            localStorage.setItem(capacityGridState, currentGridState);
        }
    }

    function getPeriodTypeIndex(periodType: PeriodType) {
        let periodTypeIndex = '';
        switch (periodType) {
            case "Month":
                periodTypeIndex = '1';
                break;
            case "Quarter":
                periodTypeIndex = '2';
                break;
            case "Season":
                periodTypeIndex = '3';
                break;
            case "Semester":
                periodTypeIndex = '4';
                break;
            case "CalendarYear":
                periodTypeIndex = '5';
                break;
            case "GasYear":
                periodTypeIndex = '6';
                break;
        }

        return periodTypeIndex;
    }
    
    const mainPeriodHeaderFilter = [
        {
            text: 'Balance Of Month',
            value: buildParentFilterArray("BalanceOfMonth"),
            items: buildFilterArray("BalanceOfMonth")
        },
        {
            text: 'Month',
            value: buildParentFilterArray("Month"),
            items: buildFilterArray("Month")
        },
        {
            text: 'Quarter',
            value: buildParentFilterArray("Quarter"),
            items: buildFilterArray("Quarter")
        },
        {
            text: 'Season',
            value: buildParentFilterArray("Season"),
            items: buildFilterArray("Season")
        },        
        {
            text: 'Gas Year',
            value: buildParentFilterArray("GasYear"),
            items: buildFilterArray("GasYear")
        },
        {
            text: 'Calendar Year',
            value: buildParentFilterArray("CalendarYear"),
            items: buildFilterArray("CalendarYear")
        },
        {
            text: 'Semester',
            value: buildParentFilterArray("Semester"),
            items: buildFilterArray("Semester")
        },
        {
            text: 'Half Month',
            value: buildParentFilterArray("HalfMonth"),
            items: buildFilterArray("HalfMonth")
        },
        {
            text: 'Bank Holiday',
            value: buildParentFilterArray("BankHoliday"),
            items: buildFilterArray("BankHoliday")
        },
        {
            text: 'Weekday',
            value: buildParentFilterArray("Weekday"),
            items: buildFilterArray("Weekday")
        },
        {
            text: 'Weekend',
            value: buildParentFilterArray("Weekend"),
            items: buildFilterArray("Weekend")
        },        
    ];
    
    function renderCustomGrouptext(e) {
        let periodType = '';
        switch (e.value) {
            case 1:
                periodType = 'Balance Of Month';
                break;
            case 2:
                periodType = 'Month';
                break;
            case 3:
                periodType = 'Quarter';
                break;
            case 4:
                periodType = 'Season';
                break;
            case 5:
                periodType = 'Gas Year';
                break;
            case 6:
                periodType = 'Calendar Year';
                break;
            case 7:
                periodType = 'Semester';
                break;            
            case 8:
                periodType = 'Half Month';
                break;
            case 9:
                periodType = 'Bank Holiday';
                break;
            case 10:
                periodType = 'Weekday';
                break;
            case 11:
                periodType = 'Weekend';
                break;
        }
        return periodType;
    }

    function sendCapacity(contract: ContractDto, action): void {
        var entryTerminal: Terminal;
        var exitTerminal: Terminal;

        switch (action) {
            case "ReserveBaToZe":
                entryTerminal = Terminal.BACTON;
                exitTerminal = Terminal.ZEEBRUGGE;
                break;
            case "ReserveZeToBa":
                entryTerminal = Terminal.ZEEBRUGGE;
                exitTerminal = Terminal.BACTON;
                break;
            case "ReserveBidirectional":
                entryTerminal = Terminal.BIDIRECTIONAL;
                exitTerminal = Terminal.BIDIRECTIONAL;
                break;
        }

        const capacityRequest: CapacityBookingDto =
        {
            startDate: contract.startDate,
            endDate: contract.endDate,
            entryTerminal: entryTerminal,
            exitTerminal: exitTerminal,
            flowCapacity: 0
        }

        dispatch(bookCapacity(capacityRequest));
        navigate('/bookCapacity');
    }

    function RenderActionButtonZeToBa(cellData: { data: ContractDto }): ReactNode {
        let action = "ReserveZeToBa";

        return (
            <a style={{
                cursor: 'pointer',
                color: '#959595',
                height: '25px',
                fontWeight: 'bold',
                backgroundColor: '#ffece8',
                paddingLeft: '10px',
                paddingRight: '10px',
                borderRadius: '5px',
                paddingTop: '4px',
                paddingBottom: '4px',
                marginLeft: '8px'
            }}
                onClick={() => sendCapacity(cellData.data, action)}>
                Reserve
            </a>
        );
    };

    function RenderActionButtonBidirectional(cellData: { data: ContractDto }): ReactNode {
        let action = "ReserveBidirectional";

        return (
            <a style={{
                cursor: 'pointer',
                color: '#959595',
                height: '25px',
                fontWeight: 'bold',
                backgroundColor: '#f0f0f0',
                paddingLeft: '10px',
                paddingRight: '10px',
                borderRadius: '5px',
                paddingTop: '4px',
                paddingBottom: '4px',
                marginLeft: '8px'
            }}
                onClick={() => sendCapacity(cellData.data, action)}>
                Reserve
            </a>
        );
    };

    function RenderActionButtonBaToZe(cellData: { data: ContractDto }): ReactNode {
        let action = "ReserveBaToZe";

        return (
            <a style={{
                cursor: 'pointer',
                color: '#959595',
                height: '25px',
                fontWeight: 'bold',
                backgroundColor: '#ebfaed',
                paddingLeft: '10px',
                paddingRight: '10px',
                borderRadius: '5px',
                paddingTop: '4px',
                paddingBottom: '4px',
                marginLeft: '8px'
            }}
                onClick={() => sendCapacity(cellData.data, action)}>
                Reserve
            </a>
        );
    };

    function onCellPrepared(e: CellPreparedEvent<ContractDto, number>) {
        if (e.rowType === "header") {
            if (e.column.caption == "UK to Belgium") {
                e.cellElement.style.backgroundColor = "#ebfaed";
            }

            if (e.column.caption == "Belgium to UK") {
                e.cellElement.style.backgroundColor = "#ffece8";
            }

            if (e.column.caption == "Bidirectional") {
                e.cellElement.style.backgroundColor = "#f0f0f0";
            }
        }
    }

    return (
        <>
            <PageTitleWrapper>
                Available Capacity
            </PageTitleWrapper>
            <PageContainer>
                <CardContent style={{ paddingTop: '20px' }}>
                    {
                        !isLoading ? (
                            <DataGrid
                                className={'dx-card wide-card'}
                                keyExpr="gridId"
                                dataSource={contracts}
                                showBorders={false}
                                focusedRowEnabled={false}
                                defaultFocusedRowIndex={0}
                                columnAutoWidth={true}
                                columnHidingEnabled={false}
                                onCellPrepared={onCellPrepared}
                                onContentReady={onContentReady}
                                onRowExpanded={onRowExpanded}
                                onRowCollapsed={onRowCollapsed}
                                onRowPrepared={onRowPrepared}>

                                <Paging enabled={false} />
                               {/* <Paging defaultPageSize={100} />*/}
                                <HeaderFilter visible={true} />
                                <Grouping autoExpandAll={false} />
                               {/* <Pager showPageSizeSelector={false} showInfo={true} />*/}
                                <FilterRow visible={false} />
                                <StateStoring enabled={true} />

                                <Column
                                    dataField={'periodTypeSortIndex'}
                                    width={0}
                                    dataType={'number'}
                                    caption={'Type'}
                                    allowSorting="false"
                                    groupIndex={0}
                                    visible="false"
                                    calculateGroupValue={'periodTypeSortIndex'}
                                    customizeText={renderCustomGrouptext}                                    
                                />

                                <Column caption="Contract">
                                    <Column
                                        dataField={'periodName'}                                        
                                        width={100}
                                        allowSorting="false"
                                        alignment="right"
                                        caption={'Period'}>
                                        <HeaderFilter
                                            groupInterval={[
                                                'Balance Of Month',
                                                'Month',
                                                'Quarter',
                                                'Season',
                                                'Gas Year',
                                                'Calendar Year',
                                                'Semester',
                                                'Half Month',
                                                'Bank Holiday',
                                                'Weekday',
                                                'Weekend'                                                
                                            ]}
                                            allowSearch={true}
                                            height={500}
                                            dataSource={mainPeriodHeaderFilter}
                                        />
                                    </Column>
                                    <Column
                                        dataField={'startDate'}
                                        width={100}
                                        dataType={'date'}
                                        alignment="right"
                                        allowSorting="false"
                                        format="d MMM yyyy"
                                        caption={'Start Date'}
                                        allowHeaderFiltering={false}
                                    />
                                    <Column
                                        dataField={'endDate'}
                                        width={100}
                                        dataType={'date'}
                                        format="d MMM yyyy"
                                        alignment="right"
                                        allowSorting="false"
                                        caption={'End Date'}
                                        allowHeaderFiltering={false}
                                    />
                                </Column>

                                <Column width={4} />

                                <Column caption="UK to Belgium">
                                    <Column
                                        dataField={'baEntryUnitPrice'}
                                        width={120}
                                        dataType={'number'}
                                        alignment="right"
                                        format="0.000000"
                                        caption={'Unit Price (Entry)'}
                                        allowSorting="false"
                                        cssClass="baEntryUnitPrice"
                                        allowHeaderFiltering={false}
                                    />
                                    <Column
                                        dataField={'zeExitUnitPrice'}
                                        width={120}
                                        dataType={'number'}
                                        alignment="right"
                                        format="0.000000"
                                        caption={'Unit Price (Exit)'}
                                        allowSorting="false"
                                        cssClass="zeExitUnitPrice"
                                        allowHeaderFiltering={false}
                                    />
                                    <Column
                                        dataField={'baToZeAvailableCapacity'}
                                        width={150}
                                        alignment="right"
                                        caption={'Available Capacity'}
                                        cssClass="baToZeAvailableCapacity"
                                        allowSorting="false"
                                        allowHeaderFiltering={false}
                                    />
                                    <Column
                                        width={100}
                                        cellRender={RenderActionButtonBaToZe}
                                        visible={true}
                                        allowSorting="false"
                                        showInColumnChooser={false}
                                    />
                                </Column>

                                <Column width={4} />

                                <Column caption="Belgium to UK">
                                    <Column
                                        dataField={'zeEntryUnitPrice'}
                                        width={120}
                                        dataType={'number'}
                                        alignment="right"
                                        format="0.000000"
                                        caption={'Unit Price (Entry)'}
                                        cssClass="zeEntryUnitPrice"
                                        allowSorting="false"
                                        allowHeaderFiltering={false}>
                                    </Column>
                                    <Column
                                        dataField={'baExitUnitPrice'}
                                        width={120}
                                        dataType={'number'}
                                        alignment="right"
                                        format="0.000000"
                                        caption={'Unit Price (Exit)'}
                                        cssClass="baExitUnitPrice"
                                        allowSorting="false"
                                        allowHeaderFiltering={false}
                                    />
                                    <Column
                                        dataField={'zeToBaAvailableCapacity'}
                                        width={150}
                                        alignment="right"
                                        dataType={'number'}
                                        caption={'Available Capacity'}
                                        cssClass="zeToBaAvailableCapacity"
                                        allowSorting="false"
                                        allowHeaderFiltering={false}
                                    />
                                    <Column
                                        width={100}
                                        cellRender={RenderActionButtonZeToBa}
                                        visible={true}
                                        allowSorting="false"
                                        showInColumnChooser={false}
                                    />
                                </Column>

                                <Column width={4} />

                                <Column caption="Bidirectional">
                                    <Column
                                        width={150}
                                        alignment="right"
                                        caption={'Available Capacity'}
                                        dataType={'number'}
                                        allowSorting="false"
                                        allowHeaderFiltering={false}
                                        calculateCellValue={(c: ContractDto) => Math.min(c.baToZeAvailableCapacity, c.zeToBaAvailableCapacity)}
                                    />
                                    <Column
                                        width={100}
                                        cellRender={RenderActionButtonBidirectional}
                                        visible={true}
                                        allowSorting="false"
                                        showInColumnChooser={false}
                                    />
                                </Column>
                            </DataGrid>


                        ) : (
                            <CircularProgress size={26} />
                        )}
                    <Tooltip
                        target=".baEntryUnitPrice"
                        position="top"
                        showEvent="mouseenter"
                        hideEvent="mouseleave"
                        hideOnOutsideClick={false}
                    >
                        <div>pence per KWh</div>
                    </Tooltip>
                    <Tooltip
                        target=".zeExitUnitPrice"
                        position="top"
                        showEvent="mouseenter"
                        hideEvent="mouseleave"
                        hideOnOutsideClick={false}
                    >
                        <div>pence per KWh</div>
                    </Tooltip>
                    <Tooltip
                        target=".baToZeAvailableCapacity"
                        position="top"
                        showEvent="mouseenter"
                        hideEvent="mouseleave"
                        hideOnOutsideClick={false}
                    >
                        <div>KWh per hour</div>
                    </Tooltip>
                    <Tooltip
                        target=".zeEntryUnitPrice"
                        position="top"
                        showEvent="mouseenter"
                        hideEvent="mouseleave"
                        hideOnOutsideClick={false}
                    >
                        <div>pence per KWh</div>
                    </Tooltip>
                    <Tooltip
                        target=".baExitUnitPrice"
                        position="top"
                        showEvent="mouseenter"
                        hideEvent="mouseleave"
                        hideOnOutsideClick={false}
                    >
                        <div>pence per KWh</div>
                    </Tooltip>
                    <Tooltip
                        target=".zeToBaAvailableCapacity"
                        position="top"
                        showEvent="mouseenter"
                        hideEvent="mouseleave"
                        hideOnOutsideClick={false}
                    >
                        <div>KWh per hour</div>
                    </Tooltip>
                </CardContent>
            </PageContainer>
        </>);
};

export default Capacity;
