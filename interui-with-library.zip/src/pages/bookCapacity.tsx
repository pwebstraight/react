import { useState, useEffect } from 'react';
import PageTitleWrapper from 'Foundation.ReactUI/components/PageTitleWrapper';
import { useAppDispatch } from 'src/store/configureStore';
import { bookCapacity } from 'src/store/capacitySlice';
import SelectBox from 'devextreme-react/select-box';
import { useNavigate } from 'react-router-dom';
import { useAppSelector } from 'src/store/configureStore';
import PageContainer from 'Foundation.ReactUI/components/PageContainer';
import { CapacityBookingService } from 'src/api/services/CapacityBookingService';
import { ShipperService } from 'src/api/services/ShipperService';
import { loadShipperCash } from 'src/store/shipperSlice';
import { Tooltip } from 'devextreme-react/tooltip';

import moment from 'moment';

import _ from 'lodash';

import
    {
        Button,
        CircularProgress,
        TextField,
        Snackbar,
        CardContent,
        Alert as MuiAlert,
        Box
    } from '@mui/material';

import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import DataGrid, {
    Column,
    HeaderFilter,
    FilterRow,
    Summary,
    TotalItem
} from 'devextreme-react/data-grid';
import
{
    CapacityBookingDetailsDto,
    CapacityBookingDto,
    ShipperDto,
    Terminal,
    TraderDto
} from '../api';
import { RowPreparedEvent } from 'devextreme/ui/data_grid';
import { ValueChangedEvent } from 'devextreme/ui/select_box';
import ConfirmationModal from 'src/components/ConfirmationModal';

const BookCapacity = () =>
{
    const [capacityBooking, setCapacityBooking] = useState<CapacityBookingDto>(null);
    const [capacityBookingDetails, setCapacityBookingDetails] = useState([]);

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isGridVisible, setIsGridVisible] = useState<boolean>(true);
    const [confirmReservation, setConfirmReservation] = useState<boolean>(false);
    const [reservationIsSaved, setReservationIsSaved] = useState<boolean>(false);
    const [selectedShipper, setSelectedShipper] = useState<ShipperDto>(null);
    const [selectedTrader, setSelectedTrader] = useState<TraderDto>(null);

    const navigate = useNavigate();
    const { capacity } = useAppSelector((state) => state.capacity);

    const dispatch = useAppDispatch();

    const { shippers } = useAppSelector((state) => state.shippers);

    async function loadShippers()
    {
        const shippersData = await ShipperService.postApiShipperGetAll();
        dispatch(loadShipperCash(shippersData));
    }

    useEffect(() =>
    {
        if (shippers.length == 0)
        {
            loadShippers();
        }

        if (capacity == null)
        {
            const defaultCapacityRequest: CapacityBookingDto = {
                startDate: moment(new Date()).format('YYYY-MM-DD'),
                endDate: moment(new Date()).format('YYYY-MM-DD')
            };

            loadCapacityDetails(defaultCapacityRequest);
        }
        else
        {
            loadCapacityDetails(capacity);
        }
    }, []);

    async function loadCapacityDetails(capacity)
    {
        if (!isLoading)
        {
            setIsLoading(true);

            try
            {
                const capacitiesBookingData =
                {
                    ...await CapacityBookingService.postApiCapacityBookingSolveCapacity(capacity),
                    flowCapacity: capacityBooking.flowCapacity,
                    startDate: capacityBooking.startDate,
                    endDate: capacityBooking.endDate
                }

                setCapacityBooking(capacitiesBookingData);
                setCapacityBookingDetails(capacitiesBookingData.capacityBookingDetails);
                dispatch(bookCapacity(null));
            } finally
            {
                setIsLoading(false);
            }
        }
    }

    function onRowPrepared(
        e: RowPreparedEvent<CapacityBookingDetailsDto, number>
    )
    {
        if (e.rowType === 'data')
        {
            if (!e.data.isValid)
            {
                e.rowElement.style.backgroundColor = '#F4B9C0';
            } else
            {
                if (e.rowIndex % 2 === 1)
                {
                    e.rowElement.style.backgroundColor = 'white';
                } else
                {
                    e.rowElement.style.backgroundColor = '#e6faff';
                }
            }
        }
    }

    function closeConfirmation()
    {
        setConfirmReservation(false);
    }

    async function submitReservation()
    {
        setConfirmReservation(false);

        try
        {
            await CapacityBookingService.postApiCapacityBookingBookCapacities(capacityBooking);
        } finally
        {
            setReservationIsSaved(true); // todo could show a warning if failed
        }
    }

    function calculateSelectedRow(options)
    {
        if (capacityBooking != null)
        {
            switch (options.name)
            {
                case 'periodTypeSummary':
                    options.totalValue = 'Total:';
                    break;
                case 'startDateSummary':
                    options.totalValue = moment(capacityBooking.startDate).format(
                        'D MMM YYYY'
                    );
                    break;
                case 'endDateSummary':
                    options.totalValue = moment(capacityBooking.endDate).format(
                        'D MMM YYYY'
                    );
                    break;
                case 'entryUnitPriceSummary':
                    options.totalValue = capacityBooking.entryUnitPrice;
                    break;
                case 'exitUnitPriceSummary':
                    options.totalValue = capacityBooking.exitUnitPrice;
                    break;
                case 'availableCapacitySummary':
                    options.totalValue = capacityBooking.availableCapacity;
                    break;
                case 'hoursSummary':
                    options.totalValue = capacityBooking.hours;
                    break;
                case 'directionSummary':
                    options.totalValue = getDirectionByEntryTerminal(capacityBooking.exitTerminal);
                    break;
                case 'flowCapacitySummary':
                    options.totalValue = capacityBooking.flowCapacity;
                    break;
                case 'reasonSummary':
                    options.totalValue = capacityBooking.errorMessage;
                    break;
                case 'totalCapacitySummary':
                    options.totalValue = capacityBooking.totalCapacity;
                    break;
            }
        }
    }

    function onShipperValueChanged(e: ValueChangedEvent)
    {
        var shipper = shippers?.filter((s) => s.id == e.value)[0];

        setSelectedShipper(shipper);

        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.shipperId = e.value;
        currentCapacitiesBookingData.shipper = shipper;
        loadCapacityDetails(currentCapacitiesBookingData);
    }

    function onEntryTerminalValueChanged(e: ValueChangedEvent)
    {
        let currentCapacitiesBookingData = { ...capacityBooking };

        currentCapacitiesBookingData.entryTerminal = e.value;

        switch (e.value)
        {
            case Terminal.BACTON:
                currentCapacitiesBookingData.exitTerminal = Terminal.ZEEBRUGGE;
                break;
            case Terminal.ZEEBRUGGE:
                currentCapacitiesBookingData.exitTerminal = Terminal.BACTON;
                break;
            case Terminal.BIDIRECTIONAL:
                currentCapacitiesBookingData.exitTerminal = Terminal.BIDIRECTIONAL;
                break;
        }

        loadCapacityDetails(currentCapacitiesBookingData);
    }

    function onExitTerminalValueChanged(e: ValueChangedEvent)
    {
        let currentCapacitiesBookingData = { ...capacityBooking };

        currentCapacitiesBookingData.exitTerminal = e.value;

        switch (e.value)
        {
            case Terminal.BACTON:
                currentCapacitiesBookingData.entryTerminal = Terminal.ZEEBRUGGE;
                break;
            case Terminal.ZEEBRUGGE:
                currentCapacitiesBookingData.entryTerminal = Terminal.BACTON;
                break;
            case Terminal.BIDIRECTIONAL:
                currentCapacitiesBookingData.entryTerminal = Terminal.BIDIRECTIONAL;
                break;
        }

        loadCapacityDetails(currentCapacitiesBookingData);
    }

    function onFlowCapacityChanged(newValue)
    {
        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.flowCapacity =
            newValue == '' ? null : newValue;
        if (currentCapacitiesBookingData.flowCapacity != null)
        {
            loadCapacityDetails(currentCapacitiesBookingData);
        } else
        {
            setCapacityBooking(currentCapacitiesBookingData);
            setCapacityBookingDetails(null);
        }
    }

    function redirectAfterSave(navigate)
    {
        navigate('/history');
    }

    function onTraderValueChanged(e: ValueChangedEvent)
    {
        var trader = selectedShipper?.traders.filter((t) => t.id === e.value)[0];

        setSelectedTrader(e.value);

        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.traderId = e.value;
        currentCapacitiesBookingData.trader = trader;
        loadCapacityDetails(currentCapacitiesBookingData);
    }

    function updateEndDate(newValue: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>)
    {
        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.endDate = newValue.target.value;
        var checkDate = Date.parse(newValue.target.value);
        if (
            checkDate > -Number.MAX_VALUE &&
            currentCapacitiesBookingData.endDate.length == 10
        )
        {
            setCapacityBooking(currentCapacitiesBookingData);
            if (checkDate > 0)
            {
                loadCapacityDetails(currentCapacitiesBookingData);
            }
        }
    }

    function updateStartDate(newValue: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>)
    {
        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.startDate = newValue.target.value;
        var checkDate = Date.parse(newValue.target.value);
        if (
            checkDate > -Number.MAX_VALUE &&
            currentCapacitiesBookingData.startDate.length == 10
        )
        {
            setCapacityBooking(currentCapacitiesBookingData);
            if (checkDate > 0)
            {
                loadCapacityDetails(currentCapacitiesBookingData);
            }
        }
    }

    function getDirectionByEntryTerminal(entryTerminal: Terminal): string
    {
        return entryTerminal === Terminal.BACTON ? 'BCT to ZEE' :
            entryTerminal === Terminal.ZEEBRUGGE ? 'ZEE to BCT' :
                "Bidirectional"
    }

    return (
        <>
            <PageTitleWrapper>Reserve Capacity</PageTitleWrapper>
            <PageContainer>
                <CardContent style={{ paddingTop: '5px' }}>
                    {isGridVisible && (
                        <>
                            <Snackbar
                                open={reservationIsSaved}
                                autoHideDuration={3000}
                                onClose={() => redirectAfterSave(navigate)}
                                anchorOrigin={{
                                    vertical: 'bottom',
                                    horizontal: 'right'
                                }}
                            >
                                <MuiAlert
                                    elevation={6}
                                    variant="filled"
                                    severity="success"
                                    style={{ fontSize: '16px' }}
                                >
                                    Booking has been submitted
                                </MuiAlert>
                            </Snackbar>

                            <div>
                                <div>
                                    <Box
                                        sx={{
                                            display: 'grid',
                                            columnGap: 3,
                                            rowGap: 1,
                                            gridTemplateColumns: 'repeat(4, 1fr)',
                                            gridTemplateRows: 'repeat(2, 1fr)'
                                        }}
                                        style={{ marginTop: '16px' }}
                                    >
                                        <div style={{ marginTop: '8px' }}>
                                            <LocalizationProvider
                                                dateAdapter={AdapterDateFns}
                                                localeText={{
                                                    clearButtonLabel: 'Empty',
                                                    todayButtonLabel: 'Now'
                                                }}
                                            >
                                                <TextField
                                                    name="StartDate"
                                                    label="Start Date"
                                                    type="date"
                                                    value={moment(capacityBooking?.startDate).format(
                                                        'YYYY-MM-DD'
                                                    )}
                                                    fullWidth={true}
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    onChange={(date) => updateStartDate(date)}
                                                />
                                            </LocalizationProvider>
                                        </div>

                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Entry Terminal"
                                            dataSource={terminalsData}
                                            displayExpr="name"
                                            valueExpr="id"
                                            value={capacityBooking?.entryTerminal}
                                            onValueChanged={onEntryTerminalValueChanged}
                                        />
                                        <div style={{ marginTop: '8px' }}>
                                            <TextField
                                                InputLabelProps={{ shrink: true }}
                                                type="number"
                                                fullWidth
                                                className="flowCapacityField"
                                                label="Flow Capacity"
                                                value={capacityBooking?.flowCapacity}
                                                onChange={(e) => onFlowCapacityChanged(e.target.value)} />
                                        </div>

                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Shipper"
                                            dataSource={shippers}
                                            displayExpr="organisationName"
                                            valueExpr="id"
                                            onValueChanged={onShipperValueChanged}
                                        />

                                        <div style={{ marginTop: '8px' }}>
                                            <LocalizationProvider
                                                dateAdapter={AdapterDateFns}
                                                localeText={{
                                                    clearButtonLabel: 'Empty',
                                                    todayButtonLabel: 'Now'
                                                }}
                                            >
                                                <TextField
                                                    label="End Date"
                                                    name="EndDate"
                                                    type="date"
                                                    value={moment(capacityBooking?.endDate).format(
                                                        'YYYY-MM-DD'
                                                    )}
                                                    fullWidth={true}
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    onChange={(date) => updateEndDate(date)}
                                                />
                                            </LocalizationProvider>
                                        </div>

                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Exit Terminal"
                                            dataSource={terminalsData}
                                            displayExpr="name"
                                            valueExpr="id"
                                            value={capacityBooking?.exitTerminal}
                                            onValueChanged={onExitTerminalValueChanged}
                                        />

                                        <div />
                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Trader"
                                            dataSource={selectedShipper?.traders}
                                            displayExpr="displayName"
                                            valueExpr="id"
                                            onValueChanged={onTraderValueChanged}
                                        />
                                    </Box>
                                </div>
                                <div style={{ paddingTop: '40px' }}>
                                    <>
                                        {!isLoading ? (
                                            <DataGrid
                                                width="100%"
                                                className={'dx-card wide-card'}
                                                keyExpr="id"
                                                dataSource={capacityBookingDetails}
                                                showBorders={true}
                                                columnAutoWidth={false}
                                                columnHidingEnabled={false}
                                                onRowPrepared={onRowPrepared}
                                            >
                                                <HeaderFilter visible={false} />
                                                <FilterRow visible={false} />
                                                <Column
                                                    dataField={'direction'}
                                                    minWidth={100}
                                                    width="7%"
                                                    caption={'Direction'}
                                                    allowEditing={false}
                                                    cellRender={(cellProps: { data: CapacityBookingDetailsDto }) =>
                                                        getDirectionByEntryTerminal(cellProps.data.entryTerminal)
                                                    }
                                                />
                                                <Column
                                                    dataField={'periodType'}
                                                    minWidth={120}
                                                    width="7%"
                                                    caption={'Period Type'}
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'startDate'}
                                                    minWidth={100}
                                                    width="7%"
                                                    dataType={'date'}
                                                    format="d MMM yyyy"
                                                    alignment="right"
                                                    caption={'Start Date'}
                                                    hidingPriority={8}
                                                />
                                                <Column
                                                    dataField={'endDate'}
                                                    minWidth={100}
                                                    width="7%"
                                                    dataType={'date'}
                                                    format="d MMM yyyy"
                                                    alignment="right"
                                                    caption={'End Date'}
                                                    hidingPriority={8}
                                                />
                                                <Column
                                                    dataField={'entryUnitPrice'}
                                                    minWidth={150}
                                                    width="9%"
                                                    caption={'Unit Price (Entry)'}
                                                    cssClass="unitPriceEntry"
                                                    format="0.000000"
                                                    dataType={'number'}
                                                    alignment="right"
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'exitUnitPrice'}
                                                    minWidth={150}
                                                    width="9%"
                                                    caption={'Unit Price (Exit)'}
                                                    format="0.000000"
                                                    dataType={'number'}
                                                    alignment="right"
                                                    cssClass="unitPriceExit"
                                                    hidingPriority={3}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'availableCapacity'}
                                                    minWidth={150}
                                                    width="9%"
                                                    caption={'Available Capacity'}
                                                    cssClass="availableCapacity"
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'hours'}
                                                    minWidth={100}
                                                    width="7%"
                                                    caption={'Hours'}
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'flowCapacity'}
                                                    minWidth={150}
                                                    width="10%"
                                                    caption={'Flow Capacity'}
                                                    cssClass="flowCapacityCol"
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'totalCapacity'}
                                                    minWidth={210}
                                                    width="12%"
                                                    caption={'Total Capacity'}
                                                    cssClass="totalCapacity"
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />

                                                <Column
                                                    dataField={'reason'}
                                                    minWidth={270}
                                                    width="16%"
                                                    caption={'Reason'}
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Summary calculateCustomSummary={calculateSelectedRow}>
                                                    <TotalItem
                                                        name="periodTypeSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="periodType"
                                                    />
                                                    <TotalItem
                                                        name="startDateSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        valueFormat="date"
                                                        showInColumn="startDate"
                                                    />
                                                    <TotalItem
                                                        name="endDateSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="endDate"
                                                    />
                                                    <TotalItem
                                                        name="entryUnitPriceSummary"
                                                        summaryType="custom"
                                                        valueFormat="0.0000000"
                                                        displayFormat="{0}"
                                                        showInColumn="entryUnitPrice"
                                                    />
                                                    <TotalItem
                                                        name="exitUnitPriceSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        valueFormat="0.0000000"
                                                        showInColumn="exitUnitPrice"
                                                    />
                                                    <TotalItem
                                                        name="flowCapacitySummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="flowCapacity"
                                                    />
                                                    <TotalItem
                                                        name="availableCapacitySummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="availableCapacity"
                                                    />
                                                    <TotalItem
                                                        name="hoursSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="hours"
                                                    />
                                                    <TotalItem
                                                        name="directionSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="direction"
                                                    />
                                                    <TotalItem
                                                        name="reasonSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="reason"
                                                    />
                                                    <TotalItem
                                                        name="totalCapacitySummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="totalCapacity"
                                                    />
                                                </Summary>
                                            </DataGrid>
                                        ) : (
                                            <CircularProgress size={26} />
                                        )}
                                    </>
                                </div>

                                <Button
                                    variant="contained"
                                    style={{
                                        float: 'right',
                                        marginTop: '20px',
                                        marginRight: '-30px'
                                    }}
                                    disabled={!capacityBooking?.isValid}
                                    id="reserveButton"
                                    color="primary"
                                    onClick={() => setConfirmReservation(true)}
                                >
                                    Send Request
                                </Button>
                            </div>

                            <Tooltip
                                target=".unitPriceEntry"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>pence per KWh</div>
                            </Tooltip>
                            <Tooltip
                                target=".unitPriceExit"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>pence per KWh</div>
                            </Tooltip>
                            <Tooltip
                                target=".totalCapacity"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh</div>
                            </Tooltip>
                            <Tooltip
                                target=".availableCapacity"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh per hour</div>
                            </Tooltip>
                            <Tooltip
                                target=".flowCapacityCol"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh per hour</div>
                            </Tooltip>
                            <Tooltip
                                target=".flowCapacityField"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh per hour</div>
                            </Tooltip>
                        </>
                    )}
                </CardContent>
            </PageContainer >
            <ConfirmationModal
                bookingModel={capacityBooking}
                onClose={closeConfirmation}
                onSubmit={submitReservation}
                open={confirmReservation} />
        </>
    );
};

const terminalsData = [
    { id: Terminal.BACTON, name: 'Bacton' },
    { id: Terminal.ZEEBRUGGE, name: 'Zeebrugge' },
    { id: Terminal.BIDIRECTIONAL, name: 'Bidirectional' }
];

export default BookCapacity;
