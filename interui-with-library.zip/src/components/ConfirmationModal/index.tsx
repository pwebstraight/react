import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Table, TableCell, TableRow, Typography } from "@mui/material";
import CloseIcon from '@mui/icons-material/CloseTwoTone';
import { CapacityBookingDto, Terminal } from "src/api";
import moment from "moment";

interface Props {
    open: boolean;
    bookingModel: CapacityBookingDto;
    onClose: () => void;
    onSubmit: () => void;
}

function getDirectionByExitTerminal(exitTerminal: Terminal): string {
    return exitTerminal === Terminal.BACTON ? 'BCT to ZEE' :
        exitTerminal === Terminal.ZEEBRUGGE ? 'ZEE to BCT' :
            "Bidirectional"
}

export default function ConfirmationModal({ open, bookingModel: bookingDetails, onClose, onSubmit }: Props) {
    return (
        <Dialog
            onClose={onClose}
            open={open}
            fullWidth={true}
            maxWidth="md"
        >
            <DialogTitle style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginTop: '20px' }}>
                    <Typography variant="h4" gutterBottom>
                        Please review the booking details before submitting the request
                    </Typography>
                    <CloseIcon style={{ cursor: 'pointer' }} onClick={onClose} />
            </DialogTitle>
            <DialogContent>
                <Table>
                    <TableRow>
                        <TableCell variant="head">Direction</TableCell>
                        <TableCell>{getDirectionByExitTerminal(bookingDetails?.exitTerminal)}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell variant="head">Start Date</TableCell>
                        <TableCell>{moment(bookingDetails?.startDate).format("D MMM yyyy")}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell variant="head">End Date</TableCell>
                        <TableCell>{moment(bookingDetails?.endDate).format("D MMM yyyy")}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell variant="head">Flow capacity</TableCell>
                        <TableCell>{bookingDetails?.flowCapacity}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell variant="head">Shipper</TableCell>
                        <TableCell>{bookingDetails?.shipper?.organisationName}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell variant="head">Trader</TableCell>
                        <TableCell>{bookingDetails?.trader?.displayName}</TableCell>
                    </TableRow>
                </Table>
            </DialogContent>
            <DialogActions style={{ margin: '0px 20px 20px' }}>
                <Button size="large" color="secondary" onClick={onClose}>Cancel</Button>
                <Button size="large" color="primary" onClick={onSubmit} variant="contained">Book Capacity</Button>
            </DialogActions>
        </Dialog>
    )
}