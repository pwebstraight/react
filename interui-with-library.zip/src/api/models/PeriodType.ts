/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum PeriodType {
    VOID = 'Void',
    CALENDAR_YEAR = 'CalendarYear',
    SEMESTER = 'Semester',
    SEASON = 'Season',
    QUARTER = 'Quarter',
    MONTH = 'Month',
    HALF_MONTH = 'HalfMonth',
    BALANCE_OF_MONTH = 'BalanceOfMonth',
    BANK_HOLIDAY = 'BankHoliday',
    WEEKDAY = 'Weekday',
    WEEKEND = 'Weekend',
    GAS_YEAR = 'GasYear',
}
