/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum ImportType {
    TARIFF = 'Tariff',
    VOLUME_CURVE = 'VolumeCurve',
    USER_ROLES = 'UserRoles',
    SHIPPERS_CONFIGURATION = 'ShippersConfiguration',
}
