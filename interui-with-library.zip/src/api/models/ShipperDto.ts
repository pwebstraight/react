/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { TraderDto } from './TraderDto';

export type ShipperDto = {
    id?: number;
    isActive?: boolean;
    organisationName?: string | null;
    shipperEic?: string | null;
    legalEntityIdentifier?: string | null;
    postBrexitAcer?: string | null;
    providerCode?: string | null;
    traders?: Array<TraderDto> | null;
};
