/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { BookingState } from './BookingState';
import type { CapacityBookingDetailsDto } from './CapacityBookingDetailsDto';
import type { ShipperDto } from './ShipperDto';
import type { Terminal } from './Terminal';
import type { TraderDto } from './TraderDto';
import type { UserDto } from './UserDto';

export type CapacityBookingDto = {
    id?: number;
    entryTerminal?: Terminal;
    exitTerminal?: Terminal;
    flowCapacity?: number | null;
    startDate?: string;
    endDate?: string;
    messageId?: string | null;
    bookingState?: BookingState;
    broker?: UserDto;
    capacityBookingDetails?: Array<CapacityBookingDetailsDto> | null;
    shipper?: ShipperDto;
    shipperId?: number | null;
    trader?: TraderDto;
    traderId?: number | null;
    dateCreated?: string;
    availableCapacity?: number | null;
    entryUnitPrice?: number | null;
    exitUnitPrice?: number | null;
    entryNotional?: number | null;
    exitNotional?: number | null;
    totalCapacity?: number | null;
    hours?: number | null;
    sellGasTradeId?: string | null;
    buyGasTradeId?: string | null;
    entryUti?: string | null;
    exitUti?: string | null;
    entryCapacityTradeId?: string | null;
    exitCapacityTradeId?: string | null;
    volumeCurveId?: number;
    isValid?: boolean;
    errorMessage?: string | null;
};
