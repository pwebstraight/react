/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ImportType } from './ImportType';
import type { UserDto } from './UserDto';

export type ImportDto = {
    id?: number;
    importedBy?: UserDto;
    receivedDate?: string;
    importType?: ImportType;
    fileName?: string | null;
    isExportable?: boolean;
    status?: string | null;
    failureReason?: string | null;
};
