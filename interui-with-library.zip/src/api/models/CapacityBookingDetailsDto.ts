/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PeriodType } from './PeriodType';
import type { Terminal } from './Terminal';

export type CapacityBookingDetailsDto = {
    id?: number;
    contractName?: string | null;
    periodName?: string | null;
    dealId?: string | null;
    entryTerminal?: Terminal;
    exitTerminal?: Terminal;
    startDate?: string;
    endDate?: string;
    flowCapacity?: number | null;
    totalCapacity?: number | null;
    availableCapacity?: number;
    entryUnitPrice?: number | null;
    exitUnitPrice?: number | null;
    entryNotional?: number | null;
    exitNotional?: number | null;
    hours?: number;
    unit?: string | null;
    isValid?: boolean;
    hasPrice?: boolean;
    hasEnoughCapacity?: boolean;
    reason?: string | null;
    periodType?: PeriodType;
    capacityBookingId?: number | null;
    entryPriceId?: number | null;
    exitPriceId?: number | null;
};
