/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TraderDto = {
    id?: number;
    firstName?: string | null;
    lastName?: string | null;
    postingId?: number | null;
    email?: string | null;
    shipperId?: number;
    readonly displayName?: string | null;
};
