/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ShipperDto } from '../models/ShipperDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ShipperService {

    /**
     * @param requestBody 
     * @returns ShipperDto Success
     * @throws ApiError
     */
    public static postApiShipperSave(
requestBody?: ShipperDto,
): CancelablePromise<ShipperDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Shipper/Save',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiShipperDelete(
id?: number,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Shipper/Delete',
            query: {
                'id': id,
            },
        });
    }

    /**
     * @returns ShipperDto Success
     * @throws ApiError
     */
    public static postApiShipperGetAll(): CancelablePromise<Array<ShipperDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Shipper/GetAll',
        });
    }

}
