/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CapacityBookingDto } from '../models/CapacityBookingDto';
import type { CapacityBookingsStatisticDto } from '../models/CapacityBookingsStatisticDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class CapacityBookingService {

    /**
     * @param requestBody 
     * @returns CapacityBookingDto Success
     * @throws ApiError
     */
    public static postApiCapacityBookingBookCapacities(
requestBody?: CapacityBookingDto,
): CancelablePromise<CapacityBookingDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/BookCapacities',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns CapacityBookingDto Success
     * @throws ApiError
     */
    public static postApiCapacityBookingUpdateGasTradeIds(
requestBody?: CapacityBookingDto,
): CancelablePromise<CapacityBookingDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/UpdateGasTradeIds',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns CapacityBookingDto Success
     * @throws ApiError
     */
    public static postApiCapacityBookingUpdateCapacityTradeIds(
requestBody?: CapacityBookingDto,
): CancelablePromise<CapacityBookingDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/UpdateCapacityTradeIds',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns CapacityBookingDto Success
     * @throws ApiError
     */
    public static postApiCapacityBookingSolveCapacity(
requestBody?: CapacityBookingDto,
): CancelablePromise<CapacityBookingDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/SolveCapacity',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @returns CapacityBookingDto Success
     * @throws ApiError
     */
    public static postApiCapacityBookingGetAll(): CancelablePromise<Array<CapacityBookingDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/GetAll',
        });
    }

    /**
     * @returns CapacityBookingsStatisticDto Success
     * @throws ApiError
     */
    public static postApiCapacityBookingGetDashboardData(): CancelablePromise<CapacityBookingsStatisticDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/GetDashboardData',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiCapacityBookingWorkaroundAccept(
requestBody?: number,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/WorkaroundAccept',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiCapacityBookingWorkaroundReject(
requestBody?: number,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/CapacityBooking/WorkaroundReject',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
