import { DealRequestDto } from 'src/models/DealRequestDto';
import { createPropertyContext, usePropertyState } from '../components/Property';

export const DealsContext = createPropertyContext<DealRequestDto>({firstCounterparty: {}, secondCounterparty : [], instruments: []});