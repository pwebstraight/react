import { useState, useEffect, useRef } from 'react';
import TreeView from 'devextreme-react/tree-view';

import {
    CardHeader,
    Card    
    } from "@mui/material";
import { usePropertyContext } from '../Property';
import { DealsContext } from 'src/contexts/DealsContext';

function ClientSelector(props)
{ 
    const [clients, setClients] = useState([]);
    const [currentDealRequest, setCurrentDealRequest] = usePropertyContext(DealsContext);
    const treeViewRef = useRef(null);
                
    useEffect(() =>
    {      
      setClients(props.data);
    }, [props.data]);
                                                               
    function renderViewItem(item) {
      return `${item.companyName}`;
    }
          
    const handleTreeSelection = (e) =>
    {                  
      let currentDeal = { ...currentDealRequest };      
      var selected = treeViewRef.current.instance.getSelectedNodes();
      var filtered = selected.filter(n => n.itemData.gridId > 0 && n.itemData.items.length == 0).map(i => i.itemData);
      if (props.multipleSelection)
        currentDeal.secondCounterparty = filtered;
      else
        currentDeal.firstCounterparty = filtered[0];
      setCurrentDealRequest(currentDeal);  
    };

    return (
        <>         
            <Card variant="outlined">
                <CardHeader style={{backgroundColor: 'rgba(236, 238, 242, 1)'}} title={props.title} />
                
                <TreeView
                    id="clientsTreeview"
                    ref={treeViewRef}                 
                    width={'100%'}
                    height={620}
                    items={clients}                  
                    selectByClick={true}
                    showCheckBoxesMode={props.multipleSelection ? 'selectAll' : 'normal'}
                    selectionMode={props.multipleSelection ? 'multiple' : 'single'}                  
                    itemRender={renderViewItem}
                    searchMode={'contains'}
                    searchEnabled={true}
                    searchExpr={'companyName'}
                />  
            </Card>              
        </>           
    )
};

export default ClientSelector;
