import { useState, useEffect, useRef } from 'react';
import TreeView from 'devextreme-react/tree-view';
import { DealsContext } from 'src/contexts/DealsContext';

import {
    CardHeader,
    Card
    } from "@mui/material";
import { usePropertyContext } from '../Property';

function InstrumentSelector(props)
{
 
    const [instruments, setInstruments] = useState([]);
    const [currentDealRequest, setCurrentDealRequest] = usePropertyContext(DealsContext);
    const treeViewRef = useRef(null);
                
    useEffect(() =>
    {
        setInstruments(props.data);
    }, [props.data]);
                                                               
    function renderViewItem(item) {
      return `${item.name}`;
    }
          
    const handleTreeSelection = (e) =>
    {                  
      let currentDeal = { ...currentDealRequest };      
      var selected = treeViewRef.current.instance.getSelectedNodes();
      var filtered = selected.filter(n => n.itemData.gridId > 0 && n.itemData.items.length == 0).map(i => i.itemData);
      currentDeal.instruments = filtered;
      setCurrentDealRequest(currentDeal);  
    };

    return (
        <>         
            <Card variant="outlined">
                <CardHeader style={{backgroundColor: 'rgba(236, 238, 242, 1)'}} title={props.title} />
                <TreeView
                    id="instrumentsTreeview"                    
                    ref={treeViewRef}             
                    width={'100%'}
                    height={620}
                    items={instruments}                  
                    selectByClick={true}
                    showCheckBoxesMode={'selectAll'}
                    onSelectionChanged={(e) => handleTreeSelection(e)}
                    selectionMode='multiple'                  
                    itemRender={renderViewItem}
                    searchMode={'contains'}
                    searchEnabled={true}
                    searchExpr={'name'}
                /> 
            </Card>       
        </>           
    )
};

export default InstrumentSelector;
