import { useEffect } from 'react';

import {
    Box,
    Button,
    CardHeader,
    Card,    
    Grid,
    useTheme,
    Checkbox,
    RadioGroup,
    Select,
    MenuItem,
    FormControlLabel,
    Radio
  } from '@mui/material';
import { usePropertyContext } from '../Property';
import { DealsContext } from 'src/contexts/DealsContext';

function DealingControls(props)
{ 
    const theme = useTheme();
    const [currentDealRequest, setCurrentDealRequest] = usePropertyContext(DealsContext);
    
    useEffect(() =>
    {            
    }, [props.data]);
                         
    return (
        <>         
            <Card variant="outlined">
                <CardHeader style={{backgroundColor: 'rgba(236, 238, 242, 1)'}} title="Date/Tenor" />
                <Grid container direction="row" sx={{pl: '15px'}}>
                <Grid item xs={12} sm={5} justifyContent="flex-end">
                    <Box
                        pr={3}
                        sx={{
                            pt: `${theme.spacing(1)}`,
                            pb: { xs: 1, md: 0 }
                        }}
                        alignSelf="center"
                    >
                        Delete Existing:
                    </Box>
                </Grid>
                <Grid                                
                    item
                    xs={12}
                    sm={7}
                    md={6}
                >
                    <Checkbox
                        sx={{pl: 0}}
                        name="maxOrderSize"
                        size="small"
                    />
                </Grid>
                </Grid>
                <Grid container direction="row" sx={{pl: '15px'}}>
                <Grid item xs={12} sm={5} justifyContent="flex-end">
                    <Box
                        pr={3}
                        sx={{
                            pt: `${theme.spacing(1)}`,
                            pb: { xs: 1, md: 0 }
                        }}
                        alignSelf="center"
                    >
                        Rolling:
                    </Box>
                </Grid>
                <Grid                                
                    item
                    xs={12}
                    sm={7}
                    md={6}
                >
                    <Checkbox
                        sx={{pl: 0}}
                        name="maxOrderSize"
                        size="small"
                    />
                </Grid>
                </Grid>
                <Grid container direction="row" sx={{pl: '15px'}}>
                <Grid item xs={12} sm={5} justifyContent="flex-end">
                    <Box
                        pr={3}
                        sx={{
                            pt: `${theme.spacing(1)}`,
                            pb: { xs: 1, md: 0 }
                        }}
                        alignSelf="center"
                    >
                        View:
                    </Box>
                </Grid>
                <Grid                                
                    item
                    xs={12}
                    sm={7}
                    md={6}
                >
                    <RadioGroup
                        row
                        aria-labelledby="demo-radio-buttons-group-label"
                        defaultValue="female"
                        name="radio-buttons-group"
                    >
                        <FormControlLabel value="female" control={<Radio />} label="Add Period" />
                        <FormControlLabel value="male" control={<Radio />} label="Add" />                                  
                    </RadioGroup>
                </Grid>
                </Grid>
                <Grid container direction="row" sx={{pl: '15px', pt: '10px'}}>
                <Grid item xs={12} sm={5} justifyContent="flex-end">
                    <Box
                        pr={3}
                        sx={{
                            pt: `${theme.spacing(1)}`,
                            pb: { xs: 1, md: 0 }
                        }}
                        alignSelf="center"
                    >
                        Sequences:
                    </Box>
                </Grid>
                <Grid                                
                    item
                    xs={12}
                    sm={7}
                    md={6}
                >
                    <Select style={{width: '200px', height: '30px'}}>
                        {props.sequences.map(sequence => (
                            <MenuItem key={sequence.id} value={sequence.id}>
                                {sequence.name}
                            </MenuItem>
                        )) }
                    </Select>
                </Grid>
                </Grid>
                <Grid container direction="row" sx={{pl: '15px', pt: '10px'}}>
                <Grid item xs={12} sm={5} justifyContent="flex-end">
                    <Box
                        pr={3}
                        sx={{
                            pt: `${theme.spacing(1)}`,
                            pb: { xs: 1, md: 0 }
                        }}
                        alignSelf="center"
                    >
                        Window Period:
                    </Box>
                </Grid>
                <Grid                                
                    item
                    xs={12}
                    sm={7}
                    md={6}
                >
                    <Select style={{width: '200px', height: '30px'}}></Select>
                </Grid>
                </Grid>
                <Grid container direction="row" sx={{pl: '15px', pt: '10px', pb: '10px'}}>
                <Grid item xs={12} sm={5} justifyContent="flex-end">
                    <Box
                        pr={3}
                        sx={{
                            pt: `${theme.spacing(1)}`,
                            pb: { xs: 1, md: 0 }
                        }}
                        alignSelf="center"
                    >
                        Sequence Items:
                    </Box>
                </Grid>
                <Grid                                
                    item
                    xs={12}
                    sm={7}
                    md={6}
                >
                    <Select style={{width: '200px', height: '30px'}}></Select>
                </Grid>
                </Grid>

                <Card variant="outlined" sx={{mt: "15px"}}>
                <CardHeader style={{backgroundColor: 'rgba(236, 238, 242, 1)'}} title="Dealing Controls" />
                <Grid container direction="row" sx={{pl: '15px'}}>

                <Grid                                
                    item
                    xs={6}
                    sm={3}
                    md={3}
                >
                    <Checkbox
                        sx={{pl: 0}}
                        name="maxOrderSize"
                        size="small"
                    /> Buy
                </Grid>

                <Grid                                
                    item
                    xs={6}
                    sm={4}
                    md={4}
                >
                    <Checkbox
                        sx={{pl: 0}}
                        name="maxOrderSize"
                        size="small"
                    /> Never Buy
                </Grid>

                <Grid                                
                    item
                    xs={6}
                    sm={5}
                    md={5}
                >
                    <Checkbox
                        sx={{pl: 0}}
                        name="maxOrderSize"
                        size="small"
                    /> Imply Negative
                </Grid>

                </Grid>
                <Grid container direction="row" sx={{pl: '15px'}}>

                <Grid                                
                    item
                    xs={6}
                    sm={3}
                    md={3}
                >
                    <Checkbox
                        sx={{pl: 0}}
                        name="maxOrderSize"
                        size="small"
                    /> Sell
                </Grid>

                <Grid                                
                    item
                    xs={6}
                    sm={4}
                    md={4}
                >
                    <Checkbox
                        sx={{pl: 0}}
                        name="maxOrderSize"
                        size="small"
                    /> Never Sell
                </Grid>
                </Grid>
                
                <Grid container direction="row" sx={{p: '15px'}}>
                    <Button size="large" color="primary" variant="contained">OK</Button>
                </Grid>

                </Card>
            </Card>              
        </>           
    )
};

export default DealingControls;
