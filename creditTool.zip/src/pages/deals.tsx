import { useState, useEffect, Fragment } from 'react';
import { Helmet } from 'react-helmet-async';
import PageTitleWrapper from 'Foundation.ReactUI/components/PageTitleWrapper';
import { DataService } from 'src/api/services/DataService';
import ClientSelector from 'src/components/ClientSelector';
import InstrumentSelector from 'src/components/InstrumentSelector';
import DealingControls from 'src/components/DealingControls';
import { createPropertyContext, usePropertyState } from '../components/Property';
import PageContainer from 'Foundation.ReactUI/components/PageContainer';

import {  
  CardContent,
  Grid  
} from '@mui/material';
import { DealRequestDto } from 'src/models/DealRequestDto';
import { DealsContext } from 'src/contexts/DealsContext';

function Deals()
{
    const [isLoading, setIsLoading] = useState(false);  
    const [instruments, setInstruments] = useState([]);
    const [sequences, setSequences] = useState([]);
    const [clients1, setClients1] = useState([]);
    const [clients2, setClients2] = useState([]);
    const [currentDealRequestProperty, currentDealRequestPropertyContext, currentDealRequest, setCurrentDealRequest ] = usePropertyState<DealRequestDto>(DealsContext);
                        
    useEffect(() =>
    {
      loadClients();
      loadInstruments();
    }, []);    

    useEffect(() =>
    {       
      loadGenericSequences();
    }, [currentDealRequest]);

    async function loadInstruments()
    {
       if (!isLoading) {
            setIsLoading(true);

            try {
                const allInstruments = await DataService.postApiDataGetGenericInstruments();                
                setInstruments(allInstruments);
            }
            finally {
                setIsLoading(false);
            }
        }
    }

    async function loadClients()
    {
       if (!isLoading) {
            setIsLoading(true);

            try {
                const allClients = await DataService.postApiDataGetCompanies();                     
                setClients1(allClients);
                setClients2(allClients);
            }
            finally {
                setIsLoading(false);
            }
        }
    }

    async function loadGenericSequences()
    {
       if (!isLoading) {
            setIsLoading(true);

            try {
                var instruments = currentDealRequest.instruments.map(i => i.gridId) as number[];                
                if (instruments.length > 0) {
                  const allSequences = await DataService.postApiDataGetSequences(instruments);                          
                  setSequences(allSequences);
                }
            }
            finally {
                setIsLoading(false);
            }
        }
    }
                                                                  
    return (
        <currentDealRequestPropertyContext.Provider value={currentDealRequestProperty}>
          <Helmet>
              <title>Client Credit Tool</title>
          </Helmet>
          <PageTitleWrapper>
              Deals
          </PageTitleWrapper>           
          <PageContainer>
              {clients1 && clients2 && instruments &&
                <CardContent style={{ paddingTop: '20px' }}>
                  <Grid container direction="row">
                    <Grid item xs style={{padding: '5px'}}>
                      <ClientSelector multipleSelection={false} data={clients1} title={
                        <Fragment><b>First Counterparty (<span style={{color: 'blue'}}>Blue - TP</span>, <span style={{color: 'red'}}>Red - ICAP</span>)</b></Fragment>}                        
                      />                        
                    </Grid>
                    <Grid item xs style={{padding: '5px'}}>
                      <ClientSelector multipleSelection={true} data={clients2} title={
                        <Fragment><b>Second Counterparty (<span style={{color: 'blue'}}>Blue - TP</span>, <span style={{color: 'red'}}>Red - ICAP</span>)</b></Fragment>}                        
                      />
                    </Grid>
                    <Grid item xs style={{padding: '5px'}} >
                      <InstrumentSelector data={instruments} title={
                        <Fragment><b>Instruments (<span style={{color: 'blue'}}>Blue - TP</span>, <span style={{color: 'red'}}>Red - ICAP</span>)</b></Fragment>}                        
                      />
                    </Grid>  
                    <Grid item xs style={{padding: '5px'}}>
                      <DealingControls sequences={sequences} />
                    </Grid>
                  </Grid>
                </CardContent>
              }
          </PageContainer>
        </currentDealRequestPropertyContext.Provider>           
    )
};

export default Deals;
