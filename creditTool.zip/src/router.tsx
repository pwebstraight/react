import { Suspense, lazy } from 'react';
import { Navigate } from 'react-router-dom';
import { RouteObject } from 'react-router';
import { LoginCallback } from '@okta/okta-react';
import { SidebarLayout } from 'Foundation.ReactUI/components/SidebarLayout';
import { RequiredAuth } from 'Foundation.ReactUI/components/RequiredAuth';

import SuspenseLoader from 'Foundation.ReactUI/components/SuspenseLoader';

const Loader = (Component) => (props) =>
  (
    <Suspense fallback={<SuspenseLoader />}>
      <Component {...props} />
    </Suspense>
  );

// Pages
const Home = Loader(lazy(() => import('src/pages/deals')));

const Status404 = Loader(
  lazy(() => import('src/pages/status404'))
);

const routes: RouteObject[] = [
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/',
        element: <RequiredAuth />,
        children: [
          {
            path: '/',
            element: <Home />
          },
          {
            path: 'home',
            element: <Navigate to="/" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  },   
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/users',
        element: <RequiredAuth />,       
      },
    ]    
  },  
  {
    path: '',
    element: <SidebarLayout />,
    children: [
      {
        path: 'login/callback',
        element: <LoginCallback />
      },
      {
        path: 'loginCallback',
        element: <Navigate to="/" />
      }      
    ]
  }
];

export default routes;
