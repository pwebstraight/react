import { SetStateAction, useCallback, useEffect, useState } from "react";
import { useRoutes, useNavigate } from 'react-router-dom';
import Hub, { SubscribeToNotifications } from "src/api/Hub";
import router from 'src/router';
import 'devextreme/dist/css/dx.light.css';
import { useAppDispatch, useAppSelector } from "src/store/configureStore";
import OktaAuth, { toRelativeUrl } from '@okta/okta-auth-js';
import { Security } from '@okta/okta-react';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import { CssBaseline } from '@mui/material';
import ThemeProvider from './theme/ThemeProvider';


function App(props: { oktaAuth: OktaAuth }) {

  const content = useRoutes(router);
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
    
  const initApp = useCallback(async () => {
    
    if(!Hub.SignalRConnection){
      SubscribeToNotifications(props.oktaAuth);
    }
      
  }, [SubscribeToNotifications]);

  useEffect(() => {
    initApp();
  }, [initApp])
  
  const restoreOriginalUri = (_oktaAuth, originalUri) => {
    navigate(toRelativeUrl(originalUri || '/', window.location.origin));
  };

  return (
    <Security oktaAuth={props.oktaAuth} restoreOriginalUri={restoreOriginalUri}>      
        <ThemeProvider>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <CssBaseline />
            {content}
          </LocalizationProvider>
        </ThemeProvider>      
    </Security> 
  );
}

export default App;
