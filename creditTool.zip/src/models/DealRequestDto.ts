
import { CompanyDto, InstrumentDto } from "src/api";

export type DealRequestDto = {    
    firstCounterparty: CompanyDto;
    secondCounterparty: CompanyDto[];
    instruments: InstrumentDto[];
};
