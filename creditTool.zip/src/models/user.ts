import { UserRole } from "../api/models/UserRole";

export interface User {    
    id?: string;
    userName?: string;    
    role?: UserRole;
    isActive?: boolean; 
    token?: string;   
  }