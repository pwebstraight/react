/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuditLogDto } from '../models/AuditLogDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class AuditService {

    /**
     * @param startDate 
     * @param endDate 
     * @returns AuditLogDto Success
     * @throws ApiError
     */
    public static postApiAuditGetAuditLogs(
startDate?: string,
endDate?: string,
): CancelablePromise<Array<AuditLogDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Audit/GetAuditLogs',
            query: {
                'startDate': startDate,
                'endDate': endDate,
            },
        });
    }

}
