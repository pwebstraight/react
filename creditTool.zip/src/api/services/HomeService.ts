/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CreditLimitationEntryDto } from '../models/CreditLimitationEntryDto';
import type { CreditLimitationSetupDto } from '../models/CreditLimitationSetupDto';
import type { SentStatusDto } from '../models/SentStatusDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class HomeService {

    /**
     * @param requestBody 
     * @returns CreditLimitationEntryDto Success
     * @throws ApiError
     */
    public static postApiHomeGetCreditLimitationEntries(
requestBody?: CreditLimitationSetupDto,
): CancelablePromise<Array<CreditLimitationEntryDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Home/GetCreditLimitationEntries',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody 
     * @returns SentStatusDto Success
     * @throws ApiError
     */
    public static postApiHomeSendCreditLimitationEntries(
requestBody?: Array<CreditLimitationEntryDto>,
): CancelablePromise<SentStatusDto> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Home/SendCreditLimitationEntries',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
