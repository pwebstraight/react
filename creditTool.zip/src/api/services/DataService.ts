/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompanyDto } from '../models/CompanyDto';
import type { InstrumentDto } from '../models/InstrumentDto';
import type { SequenceDto } from '../models/SequenceDto';
import type { SequenceItemDto } from '../models/SequenceItemDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class DataService {

    /**
     * @returns CompanyDto Success
     * @throws ApiError
     */
    public static postApiDataGetCompanies(): CancelablePromise<Array<CompanyDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Data/GetCompanies',
        });
    }

    /**
     * @returns InstrumentDto Success
     * @throws ApiError
     */
    public static postApiDataGetGenericInstruments(): CancelablePromise<Array<InstrumentDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Data/GetGenericInstruments',
        });
    }

    /**
     * @param requestBody 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiDataAddInstrument(
requestBody?: InstrumentDto,
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Data/AddInstrument',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @returns SequenceDto Success
     * @throws ApiError
     */
    public static postApiDataGetSequences(requestBody?: Array<number>): CancelablePromise<Array<number>> {
        return __request(OpenAPI, {
            method: 'POST',
            body: requestBody,
            url: '/api/Data/GetGenericSequences',
        });
    }
    
    /**
     * @returns SequenceItemDto Success
     * @throws ApiError
     */
    public static postApiDataGetSequenceItems(): CancelablePromise<Array<SequenceItemDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Data/GetSequenceItems',
        });
    }

}
