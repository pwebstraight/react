/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreditLimitationSetupDto = Record<string, any>;
