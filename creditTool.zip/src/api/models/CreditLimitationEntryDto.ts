/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreditLimitationEntryDto = Record<string, any>;
