/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type AuditLogDto = Record<string, any>;
