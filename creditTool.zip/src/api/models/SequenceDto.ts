/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type SequenceDto = Record<string, any>;
