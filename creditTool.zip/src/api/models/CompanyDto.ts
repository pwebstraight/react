/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CompanyDto = Record<string, any>;
