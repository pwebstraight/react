import { HubConnectionBuilder, HttpTransportType } from '@microsoft/signalr';
import { globalConfig } from '../config';
import OktaAuth from '@okta/okta-auth-js';

let SignalRConnection = null;
const Hub = { SignalRConnection }

export const SubscribeToNotifications = (oktaAuth: OktaAuth) =>
{
    if (Hub.SignalRConnection != null) return;
    
    const token = oktaAuth.getIdToken();
    if (token != null)
    {
        const webUrl = `${globalConfig?.config?.apiUrl}NotificationHub`;

        Hub.SignalRConnection = new HubConnectionBuilder()
            .withUrl(
                webUrl,
                {
                    skipNegotiation: true,
                    transport: HttpTransportType.WebSockets,
                    accessTokenFactory: () => token
                })        
                .withAutomaticReconnect()
                .build();
    
        Hub.SignalRConnection.start().catch(err => console.log("connection: " + err));

        Hub.SignalRConnection.onclose(() =>
        {
            Hub.SignalRConnection.start().catch(err => console.log("connection: " + err));  
        });
    }
}

export default Hub