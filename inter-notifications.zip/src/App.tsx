import { useCallback, useEffect, useState } from "react";
import { useRoutes, useNavigate } from 'react-router-dom';
import Hub from "src/api/Hub";
import router from 'src/router';
import 'devextreme/dist/css/dx.light.css';
import { useAppDispatch, useAppSelector } from "src/store/configureStore";
import { setReservations } from "src/store/reservationSlice";
import { toRelativeUrl } from '@okta/okta-auth-js';
import { Security } from '@okta/okta-react';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import { CssBaseline } from '@mui/material';
import ThemeProvider from './theme/ThemeProvider';
import { getCurrentUser, saveUser } from "src/store/userSlice";
import type { UserNotificationDto } from 'src/api/models/UserNotificationDto';
import { addNotification, loadNotificationsCash, setUnreadNotificationsCount } from "src/store/notificationSlice";

import { CapacityBookingDto, CapacityBookingService, UserNotificationService } from './api';

function App(props) {
  const content = useRoutes(router);
  const dispatch = useAppDispatch();

    const { reservations } = useAppSelector(state => state.reservations);
    const { userNotifications } = useAppSelector(state => state.userNotifications);
    const [updatedReservation, setUpdatedReservation] = useState<CapacityBookingDto>(null);
    const [newNotification, setNewNotification] = useState<UserNotificationDto>(null);
  
  const initApp = useCallback(async () => { 
      const storageUser = localStorage.getItem("currentUser");                 
      if (storageUser !== null) {            
        const currentUser = JSON.parse(storageUser);
        const dbUser: any = await dispatch(getCurrentUser(currentUser.userName));        
        dispatch(saveUser(dbUser.payload.data));
      }
    
  }, [dispatch]);

  useEffect(() => {
    initApp().then();
  }, [initApp])

  useEffect(() => {        
    if (updatedReservation != null)
    {            
        var newState = [];
        if (reservations != null)
        {
            newState = [...reservations];
            var existedReservationIndex = newState.findIndex(r => r.id == updatedReservation.id);
            if (existedReservationIndex >= 0)
            {
                newState[existedReservationIndex] = updatedReservation;
            }
            else
            {
                newState.push(updatedReservation);
            }
        }
        else
        {

            newState.push(updatedReservation);
        }
        dispatch(setReservations(newState));
    }
    
  }, [updatedReservation]);

  useEffect(() =>
  {    
    if (newNotification != null)
    {
      dispatch(addNotification(newNotification));
    }

  }, [newNotification]);

  useEffect(() =>
  {
      loadReservationsFromServer();
      if (!userNotifications)
        loadUserNotifications();

      if (Hub.SignalRConnection)
      {
          Hub.SignalRConnection.on(
              'UpdateCapacityBooking',
              (capacityBooking) =>
              {
                  setUpdatedReservation(capacityBooking);
              });

          Hub.SignalRConnection.on(
            'SendUserNotification',
            (notification) =>
            {
                setNewNotification(notification);
            });
      }

  }, []);


  async function loadUserNotifications()
  {
      const notificationsUpUntil = localStorage.getItem("notificationsUpUntil");
      const upUntilParameter = {        
        dateCreated : notificationsUpUntil        
      }        
      const notificationsData = await UserNotificationService.postApiUserNotificationGetLatestNotifications(upUntilParameter);
      dispatch(loadNotificationsCash(notificationsData));
      dispatch(setUnreadNotificationsCount(notificationsData.length));
  }

  async function loadReservationsFromServer()
  {
      var currentReservations = await CapacityBookingService.postApiCapacityBookingGetAll()
      dispatch(setReservations(currentReservations));
  }
  
  const navigate = useNavigate();
  const restoreOriginalUri = (_oktaAuth,  originalUri) => {
    navigate(toRelativeUrl(originalUri || '/', window.location.origin));
  };
  
  return (
      <Security oktaAuth={props.oktaAuth} restoreOriginalUri={restoreOriginalUri}>
      <ThemeProvider>
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <CssBaseline />
          {content}
        </LocalizationProvider>
      </ThemeProvider>
    </Security>
  );
}

export default App;
