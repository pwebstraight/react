/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { UserNotificationDto } from '../models/UserNotificationDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class UserNotificationService {

    /**
     * @param requestBody 
     * @returns UserNotificationDto Success
     * @throws ApiError
     */
    public static postApiUserNotificationGetLatestNotifications(
requestBody?: UserNotificationDto,
): CancelablePromise<Array<UserNotificationDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/UserNotification/GetLatestNotifications',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

}
