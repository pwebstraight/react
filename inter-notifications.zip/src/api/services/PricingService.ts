/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ContractDto } from '../models/ContractDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PricingService {

    /**
     * @returns ContractDto Success
     * @throws ApiError
     */
    public static postApiPricingCollectContracts(): CancelablePromise<Array<ContractDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Pricing/CollectContracts',
        });
    }

}
