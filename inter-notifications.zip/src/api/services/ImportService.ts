/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ImportDto } from '../models/ImportDto';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ImportService {

    /**
     * @param formData 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiImportImportVolumeCsv(
formData?: {
capiaFile?: Blob;
},
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Import/ImportVolumeCsv',
            formData: formData,
            mediaType: 'multipart/form-data',
        });
    }

    /**
     * @param formData 
     * @returns any Success
     * @throws ApiError
     */
    public static postApiImportImportPriceCsv(
formData?: {
tariffFile?: Blob;
},
): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Import/ImportPriceCsv',
            formData: formData,
            mediaType: 'multipart/form-data',
        });
    }

    /**
     * @returns ImportDto Success
     * @throws ApiError
     */
    public static postApiImportGetAllImports(): CancelablePromise<Array<ImportDto>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Import/GetAllImports',
        });
    }

    /**
     * @returns string Success
     * @throws ApiError
     */
    public static postApiImportGetLastCapacityImportDate(): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/Import/GetLastCapacityImportDate',
        });
    }

}
