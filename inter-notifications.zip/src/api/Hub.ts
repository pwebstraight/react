import { HubConnectionBuilder, HttpTransportType } from '@microsoft/signalr';
import { globalConfig } from '../config';


let SignalRConnection = null;


const Hub =
{    
    SignalRConnection
}

export const SubscribeToNotifications = () =>
{
    if (Hub.SignalRConnection != null) return;

    const tokenUser = localStorage.getItem("currentUser");

    if (tokenUser != null)
    {
        const currentUser = JSON.parse(tokenUser);
        const webUrl = `${globalConfig?.config?.apiUrl}NotificationHub`;

        Hub.SignalRConnection = new HubConnectionBuilder()
            .withUrl(
                webUrl,
                {
                    skipNegotiation: true,
                    transport: HttpTransportType.WebSockets,
                    accessTokenFactory: () => currentUser.token
                })        
                .withAutomaticReconnect()
                .build();
    
        Hub.SignalRConnection.start().catch(err => console.log("connection: " + err));

        Hub.SignalRConnection.onclose(function ()
        {
            Hub.SignalRConnection.start().catch(err => console.log("connection: " + err));  
        });
    }
}

export default Hub