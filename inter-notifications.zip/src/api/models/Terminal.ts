/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum Terminal {
    BACTON = 'Bacton',
    ZEEBRUGGE = 'Zeebrugge',
    BIDIRECTIONAL = 'Bidirectional',
}
