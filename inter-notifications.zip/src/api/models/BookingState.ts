/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum BookingState {
    INITIAL = 'Initial',
    PENDING = 'Pending',
    ACCEPTED = 'Accepted',
    REJECTED = 'Rejected',
    IN_ERROR = 'InError',
    READY = 'Ready',
    CONFIRMED = 'Confirmed',
    AMENDED = 'Amended',
    CANCELLED = 'Cancelled',
}
