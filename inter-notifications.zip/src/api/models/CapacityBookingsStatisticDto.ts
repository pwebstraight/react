/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CapacityBookingsStatisticDto = {
    initialsCount?: number;
    inErrorCount?: number;
    pendingsCount?: number;
    acceptedCount?: number;
    rejectedCount?: number;
    readyCount?: number;
    confirmedCount?: number;
    amendedCount?: number;
};
