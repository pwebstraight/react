/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserDto } from './UserDto';
import type { UserNotificationType } from './UserNotificationType';

export type UserNotificationDto = {
    id?: number;
    message?: string | null;
    notificationType?: UserNotificationType;
    user?: UserDto;
    userId?: number | null;
    dateCreated?: string | null;
};
