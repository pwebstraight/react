/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum UserNotificationType {
    CREATE_CAPACITY_BOOKING = 'CreateCapacityBooking',
    UPDATE_CAPACITY_BOOKING = 'UpdateCapacityBooking',
    LOAD_CAPACITY_DATA = 'LoadCapacityData',
    CREATE_SHIPPER = 'CreateShipper',
    UPDATE_SHIPPER = 'UpdateShipper',
    UPDATE_USER = 'UpdateUser',
}
