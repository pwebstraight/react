/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum UserRole {
    ADMIN = 'Admin',
    BROKER = 'Broker',
    OPERATIONS = 'Operations',
    SUPPORT = 'Support',
}
