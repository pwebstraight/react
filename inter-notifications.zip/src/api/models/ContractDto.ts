/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PeriodType } from './PeriodType';

export type ContractDto = {
    id?: number;
    readonly gridId?: string;
    periodType?: PeriodType;
    periodName?: string | null;
    startDate?: string;
    endDate?: string;
    zeEntryUnitPrice?: number;
    baExitUnitPrice?: number;
    zeExitUnitPrice?: number;
    baEntryUnitPrice?: number;
    unit?: string | null;
    zeEntryAvailableCapacity?: number;
    baExitAvailableCapacity?: number;
    zeExitAvailableCapacity?: number;
    baEntryAvailableCapacity?: number;
    zeToBaAvailableCapacity?: number;
    baToZeAvailableCapacity?: number;
};
