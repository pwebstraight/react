import { Suspense, lazy } from 'react';
import { Navigate } from 'react-router-dom';
import { RouteObject } from 'react-router';
import { LoginCallback } from '@okta/okta-react';
import SidebarLayout from 'src/layouts/SidebarLayout';
import { RequiredAuth } from 'src/components/SecureRoute';

import SuspenseLoader from 'src/components/SuspenseLoader';

const Loader = (Component) => (props) =>
  (
    <Suspense fallback={<SuspenseLoader />}>
      <Component {...props} />
    </Suspense>
  );

// Pages
const Home = Loader(lazy(() => import('src/pages/dashboard')));
const Capacity = Loader(lazy(() => import('src/pages/capacity')));
const BookCapacity = Loader(lazy(() => import('src/pages/bookCapacity')));
const History = Loader(lazy(() => import('src/pages/history')));
const Shippers = Loader(lazy(() => import('src/pages/shippers')));
const Users = Loader(lazy(() => import('src/pages/users')));
const Imports = Loader(lazy(() => import('src/pages/imports')));

const Status404 = Loader(
  lazy(() => import('src/pages/status404'))
);

const routes: RouteObject[] = [
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/',
        element: <RequiredAuth />,
        children: [
          {
            path: '/',
            element: <Home />
          },
          {
            path: 'home',
            element: <Navigate to="/" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  }, 
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/capacity',
        element: <RequiredAuth />,
        children: [
          {
            path: '/capacity',
            element: <Capacity />
          },
          {
            path: 'capacity',
            element: <Navigate to="/capacity" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
    },        
    {
      path: '',
      element: <SidebarLayout />,
      children: [
          {
              path: '/bookCapacity',
              element: <RequiredAuth />,
              children: [
                  {
                      path: '/bookCapacity',
                      element: <BookCapacity />
                  },
                  {
                      path: 'reserve',
                      element: <Navigate to="/bookCapacity" replace />
                  },
                  {
                      path: '*',
                      element: <Status404 />
                  }
              ]
          },
      ]
  }, 
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/history',
        element: <RequiredAuth />,
        children: [
          {
            path: '/history',
            element: <History />
          },
          {
            path: 'history',
            element: <Navigate to="/history" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  }, 
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/shippers',
        element: <RequiredAuth />,
        children: [
          {
            path: '/shippers',
            element: <Shippers />
          },  
          {
            path: 'shippers',
            element: <Navigate to="/shippers" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]
  },
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/users',
        element: <RequiredAuth />,
        children: [
          {
            path: '/users',
            element: <Users />
          },
          {
            path: 'users',
            element: <Navigate to="/users" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      },
    ]    
  },
  {
    path: '',
    element: <SidebarLayout />,
    children:[
      {
        path: '/imports',
        element: <RequiredAuth />,
        children: [
          {
            path: '/imports',
            element: <Imports />
          },
          {
            path: 'imports',
            element: <Navigate to="/imports" replace />
          },      
          {
            path: '*',
            element: <Status404 />
          }
        ]
      }
    ]
  },
  {
    path: '',
    element: <SidebarLayout />,
    children: [
      {
        path: 'login/callback',
        element: <LoginCallback />
      },
      {
        path: 'loginCallback',
        element: <Navigate to="/" />
      }      
    ]
  }
];

export default routes;
