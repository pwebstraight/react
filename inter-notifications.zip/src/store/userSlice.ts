import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import { User } from 'src/models/user';
import { UserService } from 'src/api/services/UserService';

interface UserState {    
    user: User;
}

const initialState: UserState = {    
    user: null,
}

export const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        saveUser: (state, action) => {
            state.user = action.payload;
            let storageUser = localStorage.getItem("currentUser"); 
            if (storageUser != null) {
                const currentUser = JSON.parse(storageUser);
                state.user.token = currentUser.token;
                localStorage.setItem("currentUser", JSON.stringify(state.user));
            }           
            
        }  
    }
})

export const getCurrentUser = createAsyncThunk('', async (userName: string) =>
{
        
    const response = await UserService.postApiUserGetCurrentUser();    
    return response;
})  

export const {saveUser} = userSlice.actions;