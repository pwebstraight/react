import { createSlice } from "@reduxjs/toolkit"
import { UserNotificationDto } from 'src/api/models/UserNotificationDto';

interface NotificationState {    
    userNotifications: UserNotificationDto[];  
    unreadNotificationsCount: number;  
}

const initialState: NotificationState = {        
    userNotifications: null,
    unreadNotificationsCount: 0,
}

export const notificationSlice = createSlice({
    name: 'notification',
    initialState,
    reducers: {
        addNotification: (state, action) => {            
            const currentUser = JSON.parse(localStorage.getItem("currentUser"));
            
            if (state.userNotifications.length === 10)
                state.userNotifications.shift();

            state.userNotifications.unshift(action.payload); 
                          
            //if (currentUser.userName !== action.payload.user.userName) {
                state.unreadNotificationsCount++;
            //}
        },
        loadNotificationsCash: (state, action) => {            
            state.userNotifications = action.payload.slice(0, 10);
        },
        setUnreadNotificationsCount: (state, action) => {            
            state.unreadNotificationsCount = action.payload > 10 ? 10 : action.payload;
        }  
    }
})

export const {addNotification, loadNotificationsCash, setUnreadNotificationsCount} = notificationSlice.actions;