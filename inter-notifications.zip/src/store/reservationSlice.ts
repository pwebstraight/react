import { createSlice } from "@reduxjs/toolkit"
import { CapacityBookingDto } from "src/api";

interface ReservationState
{
    reservations: CapacityBookingDto[];
}

const initialState: ReservationState = {   
    reservations: null,
}

export const reservationSlice = createSlice({
    name: 'reservation',
    initialState,
    reducers: {
        setReservations: (state, action) => {
            state.reservations = action.payload;
        } 
    }
})
  
export const { setReservations } = reservationSlice.actions;