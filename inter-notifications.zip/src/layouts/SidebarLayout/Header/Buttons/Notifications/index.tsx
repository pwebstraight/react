import { useState, useEffect, useRef, ReactNode } from 'react';
import { useAppDispatch, useAppSelector } from "src/store/configureStore";
import { UserNotificationDto } from 'src/api/models/UserNotificationDto';
import { UserNotificationType } from 'src/api/models/UserNotificationType';
import { setUnreadNotificationsCount} from "src/store/notificationSlice";
import StorageTwoToneIcon from '@mui/icons-material/StorageTwoTone';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import AccountCircleTwoToneIcon from '@mui/icons-material/AccountCircleTwoTone';
import ImportExportIcon from '@mui/icons-material/ImportExport';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import Hub from "src/api/Hub";
import moment from 'moment';

import {
  alpha,
  Badge,
  Box,
  Divider,
  IconButton,
  List,
  ListItem,
  Popover,
  Tooltip,
  Typography
} from '@mui/material';
import NotificationsActiveTwoToneIcon from '@mui/icons-material/NotificationsActiveTwoTone';
import { styled } from '@mui/material/styles';

import { formatDistance, subDays, subMinutes } from 'date-fns';

const NotificationsBadge = styled(Badge)(
  ({ theme }) => `
    
    .MuiBadge-badge {
        background-color: ${alpha(theme.palette.error.main, 0.1)};
        color: white;
        min-width: 16px; 
        height: 16px;
        padding: 0;

        &::after {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            box-shadow: white;
            content: "";
        }
    }
`
);

function HeaderNotifications() {
  const ref = useRef<any>(null);
  const [isOpen, setOpen] = useState<boolean>(false);

  const dispatch = useAppDispatch();
  const { userNotifications } = useAppSelector(state => state.userNotifications);
  const { unreadNotificationsCount } = useAppSelector(state => state.unreadNotificationsCount);
  
  const handleOpen = (): void => {
       
    setOpen(true);
    dispatch(setUnreadNotificationsCount(0));   
    localStorage.setItem("notificationsUpUntil", moment(new Date()).toISOString());    
  };

  const handleClose = (): void => {
    setOpen(false);
  };

  function renderNotificationIcon(notification: UserNotificationDto): ReactNode 
  {        
    switch(notification.notificationType) {
      case UserNotificationType.CREATE_CAPACITY_BOOKING:
        return <EmojiEventsIcon />;
      case UserNotificationType.UPDATE_CAPACITY_BOOKING:
        return <StorageTwoToneIcon />;
      case UserNotificationType.CREATE_SHIPPER:
        return <LocalShippingIcon />;
      case UserNotificationType.UPDATE_SHIPPER:
        return <LocalShippingIcon />;
      case UserNotificationType.LOAD_CAPACITY_DATA:
        return <AssignmentTurnedInIcon />;   
      case UserNotificationType.UPDATE_USER:
        return <AccountCircleTwoToneIcon />;
    }
  }
  
  return (
    <>
      <Tooltip arrow title="Notifications">
        <IconButton ref={ref} onClick={handleOpen}>
          <NotificationsBadge
            style={{color: 'white'}}
            badgeContent={unreadNotificationsCount}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right'
            }}
          >
            <NotificationsActiveTwoToneIcon style={{color: 'white'}} />
          </NotificationsBadge>
        </IconButton>
      </Tooltip>
      <Popover
        anchorEl={ref.current}
        onClose={handleClose}
        open={isOpen}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right'
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right'
        }}
      >
        <Box
          style={{minWidth: '430px'}}
          sx={{ p: 2 }}
          display="flex"
          alignItems="center"
          justifyContent="space-between"
        >
          <Typography variant="h5">Notifications</Typography>
        </Box>        
        {(userNotifications && userNotifications.length > 0) &&
          <>
            <Divider />
            <List sx={{ p: 0 }} style={{paddingBottom: '20px'}}>

              {userNotifications.map((notification, index) => (
              <ListItem style={{paddingBottom: '0'}} key={index}
                sx={{ p: 2, minWidth: 350, display: { xs: 'block', sm: 'flex' } }}
              >
                <Box flex="1">
                  <Box display="flex" justifyContent="space-between">
                    <div style={{width: '100%'}}>
                      <div style={{float: 'left'}}>
                        {renderNotificationIcon(notification)} 
                      </div>                 
                      <Typography style={{float: 'left', marginLeft: '5px'}} sx={{ fontWeight: 'bold' }}>
                        {notification.message}
                      </Typography>
                      <Typography style={{float: 'right'}} variant="caption" sx={{ textTransform: 'none' }}>
                        {formatDistance(subMinutes(new Date(notification.dateCreated), 0), new Date(), {
                          addSuffix: true
                        })}
                      </Typography>
                    </div>
                  </Box>
                  {notification.user &&
                    <Typography
                      component="span"
                      variant="body2"
                      color="text.secondary"
                    >
                      {' '}         
                      { notification.user.userName &&       
                        <span style={{marginLeft: '30px'}}>created by { notification.user.userName } </span>
                      }
                    </Typography>
                  }                
                </Box>
              </ListItem>
              ))}
            </List>
          </>
        }
      </Popover>
    </>
  );
}

export default HeaderNotifications;
