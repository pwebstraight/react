export enum PeriodTypes {
    Months = 1,
    Quarters = 2,
    Seasons = 3,
    GasYears = 4,
    CalendarYears = 5,
    HalfYears = 6,
  }