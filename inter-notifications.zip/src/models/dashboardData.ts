export interface DashboardData {    
    totalReservations?: number;
    pendingReservations?: number;
    confirmedReservations?: number;
    lastCapacityLoadDate?: Date;    
    totalReservationsQty?: number;
    pendingReservationsQty?: number;
    confirmedReservationsQty?: number;
  }