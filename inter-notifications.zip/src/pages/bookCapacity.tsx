import { useState, useRef, useEffect } from 'react';
import PageTitleWrapper from 'src/components/PageTitleWrapper';
import { useAppDispatch } from "src/store/configureStore";
import { bookCapacity } from "src/store/capacitySlice";
import Hub from 'src/api/Hub';
import SelectBox from 'devextreme-react/select-box';
import { useNavigate } from 'react-router-dom';
import { useAppSelector } from 'src/store/configureStore';
import PageContainer from 'src/components/PageContainer';
import { CapacityBookingService } from 'src/api/services/CapacityBookingService';
import { ShipperService } from 'src/api/services/ShipperService';
import { loadShipperCash } from "src/store/shipperSlice";
import { Tooltip } from 'devextreme-react/tooltip';
import { convertToLocalTime } from 'date-fns-timezone';
import { parseISO } from 'date-fns';

import moment from 'moment';

import _ from 'lodash';

import
    {
        Button,
        CircularProgress,
        TextField,
        Dialog,
        DialogContent,
        DialogTitle,
        DialogActions,
        Typography,
        Snackbar,
        CardContent,
        Alert as MuiAlert,
        Box
    } from '@mui/material';

import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers';

import CloseIcon from '@mui/icons-material/CloseTwoTone';

import DataGrid, {
    Column,
    HeaderFilter,
    FilterRow,
    Summary,
    TotalItem
} from 'devextreme-react/data-grid';
import { CapacityBookingDetailsDto, CapacityBookingDto, ShipperDto, Terminal, TraderDto } from '../api';
import { RowPreparedEvent } from 'devextreme/ui/data_grid';
import { ValueChangedInfo } from 'devextreme/ui/editor/editor';
import { NativeEventInfo } from 'devextreme/events';
import { SelectBoxInstance, ValueChangedEvent } from 'devextreme/ui/select_box';

const BookCapacity = () =>
{
    const [capacityBooking, setCapacityBooking] = useState<CapacityBookingDto>(null);
    const [capacityBookingDetails, setCapacityBookingDetails] = useState([]);

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isGridVisible, setIsGridVisible] = useState<boolean>(true);
    const [confirmReservation, setConfirmReservation] = useState<boolean>(false);
    const [reservationIsSaved, setReservationIsSaved] = useState<boolean>(false);
    const [selectedShipper, setSelectedShipper] = useState<ShipperDto>(null);
    const [selectedTrader, setSelectedTrader] = useState<TraderDto>(null);
    const navigate = useNavigate();

    const DEFAULT_DATE_FORMAT = 'dd/MM/yyyy';

    const { capacity } = useAppSelector(state => state.capacity);

    const dispatch = useAppDispatch();

    const { shippers } = useAppSelector(state => state.shippers);

    async function loadShippers()
    {
        const shippersData = await ShipperService.postApiShipperGetAll();
        dispatch(loadShipperCash(shippersData));
    }

    useEffect(() =>
    {
        if (shippers.length == 0)
        {            
            loadShippers();
        }

        if (capacity == null)
        {
            const defaultCapacityRequest: CapacityBookingDto =
            {
                startDate: moment(new Date()).format('YYYY-MM-DD'),
                endDate: moment(new Date()).format('YYYY-MM-DD'),
                entryTerminal: Terminal.ZEEBRUGGE,
                exitTerminal: Terminal.BACTON,
                flowCapacity: 100
            }

            loadCapacityDetails(defaultCapacityRequest);
        }
        else
        {
            loadCapacityDetails(capacity);
        }

        if (Hub.SignalRConnection)
        {
            Hub.SignalRConnection.on(
                'CapacityDetailsUpdate',
                (notificationMessage) =>
                {
                    loadCapacityDetails(capacity);
                });
        }

    }, []);


    async function loadCapacityDetails(capacity)
    {
        if (!isLoading)
        {
            setIsLoading(true);

            try
            {
                const capacitiesBookingData = await CapacityBookingService.postApiCapacityBookingSolveCapacity(capacity);                   
                setCapacityBooking(capacitiesBookingData);
                setCapacityBookingDetails(capacitiesBookingData.capacityBookingDetails);
                dispatch(bookCapacity(null));
            }
            finally
            {
                setIsLoading(false);
            }
        }
    }

    function onRowPrepared(e: RowPreparedEvent<CapacityBookingDetailsDto, number>)
    {
        if (e.rowType === 'data')
        {
            if (!e.data.isValid)
            {
                e.rowElement.style.backgroundColor = '#F4B9C0';
            }
            else
            {
                if (e.rowIndex % 2 === 1)
                {
                    e.rowElement.style.backgroundColor = "white";
                }
                else
                {
                    e.rowElement.style.backgroundColor = "#e6faff";
                }
            }
        }
    }

    function closeConfirmation()
    {
        setConfirmReservation(false);
    }

    async function submitReservation()
    {
        setConfirmReservation(false);

        try
        {
            await CapacityBookingService.postApiCapacityBookingBookCapacities(capacityBooking);
        }
        finally
        {
            setReservationIsSaved(true);        // todo could show a warning if failed
        }
    }

    function calculateSelectedRow(options)
    {
        if (capacityBooking != null)
        {
            switch (options.name)
            {
                case "periodTypeSummary":
                    options.totalValue = "Total:";
                    break;
                case "startDateSummary":
                    options.totalValue = moment(capacityBooking.startDate).format('D MMM YYYY');
                    break;
                case "endDateSummary":
                    options.totalValue = moment(capacityBooking.endDate).format('D MMM YYYY');
                    break;
                case "entryUnitPriceSummary":
                    options.totalValue = capacityBooking.entryUnitPrice;
                    break;
                case "exitUnitPriceSummary":
                    options.totalValue = capacityBooking.exitUnitPrice;
                    break;
                case "availableCapacitySummary":
                    options.totalValue = capacityBooking.availableCapacity;
                    break;
                case "hoursSummary":
                    options.totalValue = capacityBooking.hours;
                    break;
                case "flowCapacitySummary":
                    options.totalValue = capacityBooking.flowCapacity;
                    break;
                case "reasonSummary":
                    options.totalValue = capacityBooking.errorMessage;
                    break;
                case "totalCapacitySummary":
                    options.totalValue = capacityBooking.totalCapacity;
                    break;
            }
        }
    }

    function onShipperValueChanged(e: ValueChangedInfo)
    {
        var shipper = shippers?.filter(s => s.id == e.value)[0];

        setSelectedShipper(shipper);

        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.shipperId = e.value;
        currentCapacitiesBookingData.shipper = shipper;
        loadCapacityDetails(currentCapacitiesBookingData);
    }

    function onEntryTerminalValueChanged(e : ValueChangedInfo)
    {
        let currentCapacitiesBookingData = { ...capacityBooking };

        currentCapacitiesBookingData.entryTerminal = e.value;

        switch (e.value)
        {
            case Terminal.BACTON:
                currentCapacitiesBookingData.exitTerminal = Terminal.ZEEBRUGGE;
                break;
            case Terminal.ZEEBRUGGE:
                currentCapacitiesBookingData.exitTerminal = Terminal.BACTON;
                break;
            case Terminal.BIDIRECTIONAL:
                currentCapacitiesBookingData.exitTerminal = Terminal.BIDIRECTIONAL;
                break;
        }

        loadCapacityDetails(currentCapacitiesBookingData);
    }

    function onExitTerminalValueChanged(e: ValueChangedInfo)
    {
        let currentCapacitiesBookingData = { ...capacityBooking };

        currentCapacitiesBookingData.exitTerminal = e.value;

        switch (e.value)
        {
            case Terminal.BACTON:
                currentCapacitiesBookingData.entryTerminal = Terminal.ZEEBRUGGE;
                break;
            case Terminal.ZEEBRUGGE:
                currentCapacitiesBookingData.entryTerminal = Terminal.BACTON;
                break;
            case Terminal.BIDIRECTIONAL:
                currentCapacitiesBookingData.entryTerminal = Terminal.BIDIRECTIONAL;
                break;
        }

        loadCapacityDetails(currentCapacitiesBookingData);
    }

    const formatDate = (date) => {      
        if (!date) return new Date().toISOString();
        return moment(date).toISOString();
      };

    function updateStartDate(newValue: Date)
    {                                  
        if (newValue != null && newValue.toString() != "Invalid Date")
        {
            let currentCapacitiesBookingData = { ...capacityBooking };
            currentCapacitiesBookingData.startDate = formatDate(newValue);  
            loadCapacityDetails(currentCapacitiesBookingData);
        }
    }

    function updateEndDate(newValue: Date)
    {
        if (newValue != null && newValue.toString() != "Invalid Date") 
        {
            let currentCapacitiesBookingData = { ...capacityBooking };
            currentCapacitiesBookingData.endDate = formatDate(newValue);
            loadCapacityDetails(currentCapacitiesBookingData);
        }
    }

    function onFlowCapacityChanged(newValue)
    {        
        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.flowCapacity = newValue == "" ? null : newValue;
        if (currentCapacitiesBookingData.flowCapacity != null)
        {
            loadCapacityDetails(currentCapacitiesBookingData);
        }
        else
        {
            setCapacityBooking(currentCapacitiesBookingData);
            setCapacityBookingDetails(null);
        }
    }

    function redirectAfterSave(navigate)
    {
        navigate('/capacity');
    }

    function onTraderValueChanged(e: ValueChangedEvent)
    {
        var trader = selectedShipper?.traders.filter(t => t.id === e.value)[0];

        setSelectedTrader(e.value);

        let currentCapacitiesBookingData = { ...capacityBooking };
        currentCapacitiesBookingData.traderId = e.value;
        currentCapacitiesBookingData.trader = trader;
        loadCapacityDetails(currentCapacitiesBookingData);
    }

    const onAnyTextFieldChanged = (e: any) => {        
        e?.preventDefault();
        e?.stopPropagation();        
    }

    return (
        <>
            <PageTitleWrapper>Reserve Capacity</PageTitleWrapper>
            <PageContainer>
                <CardContent style={{ paddingTop: '5px' }}>
                    {isGridVisible && (
                        <>
                            <Snackbar
                                open={reservationIsSaved}
                                autoHideDuration={3000}
                                onClose={() => redirectAfterSave(navigate)}
                                anchorOrigin={{
                                    vertical: 'bottom',
                                    horizontal: 'right'
                                }}
                            >
                                <MuiAlert
                                    elevation={6}
                                    variant="filled"
                                    severity="success"
                                    style={{ fontSize: '16px' }}
                                >
                                    Booking has been submitted
                                </MuiAlert>
                            </Snackbar>

                            <div>
                                <div>

                                    <Box sx={{
                                        display: 'grid',
                                        columnGap: 3,
                                        rowGap: 1,
                                        gridTemplateColumns: 'repeat(4, 1fr)',
                                        gridTemplateRows: 'repeat(2, 1fr)'
                                    }} style={{ marginTop: '16px' }}>

                                        <div style={{ marginTop: '8px' }} >                                        
                                            <LocalizationProvider dateAdapter={AdapterDateFns}
                                                localeText={{ clearButtonLabel: 'Empty', todayButtonLabel: 'Now' }}
                                            >
                                                <DatePicker                                                
                                                    label="Start Date"
                                                    format={DEFAULT_DATE_FORMAT}
                                                    onChange={(newValue: Date) => updateStartDate(newValue)}
                                                    value={parseISO(capacityBooking?.startDate)}
                                                    slotProps={{ textField: { fullWidth: true, onKeyDown: onAnyTextFieldChanged } }}                                                
                                                />
                                            </LocalizationProvider>
                                        </div>

                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Entry Terminal"
                                            dataSource={terminalsData}
                                            displayExpr="name"
                                            valueExpr="id"
                                            value={capacityBooking?.entryTerminal}
                                            onValueChanged={onEntryTerminalValueChanged} />

                                        <div style={{ marginTop: '8px' }} >

                                            <TextField
                                                InputLabelProps={{ shrink: true }}
                                                type="number"
                                                fullWidth
                                                className="flowCapacityField"
                                                label="Flow Capacity"
                                                value={capacityBooking?.flowCapacity}
                                                onChange={(e) => onFlowCapacityChanged(e.target.value)}></TextField>

                                        </div>

                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Shipper"
                                            dataSource={shippers}
                                            displayExpr="organisationName"
                                            valueExpr="id"
                                            onValueChanged={onShipperValueChanged} />

                                        <div style={{ marginTop: '8px' }} >                                        
                                            <LocalizationProvider dateAdapter={AdapterDateFns}
                                            localeText={{ clearButtonLabel: 'Empty', todayButtonLabel: 'Now' }}
                                            >
                                                <DatePicker 
                                                    label="End Date"                                                                                                  
                                                    format={DEFAULT_DATE_FORMAT}
                                                    onChange={(newValue: Date) => { updateEndDate(newValue) }}                                                    
                                                    value={parseISO(capacityBooking?.endDate)}
                                                    slotProps={{ textField: { fullWidth: true, onKeyDown: onAnyTextFieldChanged } }}
                                                />
                                            </LocalizationProvider>
                                        </div>

                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Exit Terminal"
                                            dataSource={terminalsData}
                                            displayExpr="name"
                                            valueExpr="id"
                                            value={capacityBooking?.exitTerminal}
                                            onValueChanged={onExitTerminalValueChanged}
                                        />

                                        <div/>
                                        <SelectBox
                                            style={{ paddingLeft: '4px' }}
                                            label="Trader"
                                            dataSource={selectedShipper?.traders}
                                            displayExpr="displayName"
                                            valueExpr="id"
                                            onValueChanged={onTraderValueChanged} 
                                            />
                                    </Box>


                                </div>
                                <div style={{ paddingTop: '40px' }} >
                                    <>

                                        {
                                            !isLoading ? (
                                            <DataGrid
                                                className={'dx-card wide-card'}
                                                keyExpr="id"
                                                dataSource={capacityBookingDetails}
                                                showBorders={true}
                                                columnAutoWidth={false}
                                                columnHidingEnabled={false}
                                                onRowPrepared={onRowPrepared}
                                            >
                                                <HeaderFilter visible={false} />
                                                <FilterRow visible={false} />

                                                <Column
                                                    dataField={'periodType'}
                                                    width={100}
                                                    caption={'Period Type'}
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'startDate'}
                                                    width={120}
                                                    dataType={'date'}
                                                    format="d MMM yyyy"
                                                    alignment="right"
                                                    caption={'Start Date'}
                                                    hidingPriority={8}
                                                />
                                                <Column
                                                    dataField={'endDate'}
                                                    width={120}
                                                    dataType={'date'}
                                                    format="d MMM yyyy"
                                                    alignment="right"
                                                    caption={'End Date'}
                                                    hidingPriority={8}
                                                />
                                                <Column
                                                    dataField={'entryUnitPrice'}
                                                    width={150}
                                                    caption={'Unit Price (Entry)'}
                                                    cssClass="unitPriceEntry"
                                                    format="0.000000"
                                                    dataType={'number'}
                                                    alignment="right"
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'exitUnitPrice'}
                                                    width={150}
                                                    caption={'Unit Price (Exit)'}
                                                    format="0.000000"
                                                    dataType={'number'}
                                                    alignment="right"
                                                    cssClass="unitPriceExit"
                                                    hidingPriority={3}
                                                    allowEditing={false}
                                                />                                                
                                                <Column
                                                    dataField={'availableCapacity'}
                                                    width={150}
                                                    caption={'Available Capacity'}
                                                    cssClass="availableCapacity"
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'hours'}
                                                    width={150}
                                                    caption={'Hours'}
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'reason'}
                                                    width={270}
                                                    caption={'Reason'}
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'totalCapacity'}
                                                    width={210}
                                                    caption={'Total Capacity'}
                                                    cssClass="totalCapacity"
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Column
                                                    dataField={'flowCapacity'}
                                                    width={150}
                                                    caption={'Flow Capacity'}
                                                    cssClass="flowCapacityCol"
                                                    hidingPriority={4}
                                                    allowEditing={false}
                                                />
                                                <Summary calculateCustomSummary={calculateSelectedRow}>
                                                    <TotalItem
                                                        name="periodTypeSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="periodType" />
                                                    <TotalItem
                                                        name="startDateSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        valueFormat="date"
                                                        showInColumn="startDate" />
                                                    <TotalItem
                                                        name="endDateSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="endDate" />
                                                    <TotalItem
                                                        name="entryUnitPriceSummary"
                                                        summaryType="custom"
                                                        valueFormat="0.0000000"
                                                        displayFormat="{0}"
                                                        showInColumn="entryUnitPrice" />
                                                    <TotalItem
                                                        name="exitUnitPriceSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        valueFormat="0.0000000"
                                                        showInColumn="exitUnitPrice" />
                                                    <TotalItem
                                                        name="flowCapacitySummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="flowCapacity" />
                                                    <TotalItem
                                                        name="availableCapacitySummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="availableCapacity" />
                                                    <TotalItem
                                                        name="hoursSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="hours" />
                                                    <TotalItem
                                                        name="reasonSummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="reason" />
                                                    <TotalItem
                                                        name="totalCapacitySummary"
                                                        summaryType="custom"
                                                        displayFormat="{0}"
                                                        showInColumn="totalCapacity" />
                                                </Summary>


                                            </DataGrid>

                                        ) : (
                                            <CircularProgress size={26} />
                                        )}
                                    </>
                                </div>

                                <Button
                                    variant="contained"
                                    style={{
                                        float: 'right',
                                        marginTop: '20px',
                                        marginRight: '-30px'
                                    }}
                                    disabled={!capacityBooking?.isValid} 
                                    id="reserveButton"
                                    color="primary"
                                    onClick={() => setConfirmReservation(true)}>
                                    Send Request
                                </Button>
                            </div>


                            <Tooltip
                                target=".unitPriceEntry"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>pence per KWh</div>
                            </Tooltip>
                            <Tooltip
                                target=".unitPriceExit"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>pence per KWh</div>
                            </Tooltip>
                            <Tooltip
                                target=".totalCapacity"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh</div>
                            </Tooltip>
                            <Tooltip
                                target=".availableCapacity"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh per hour</div>
                            </Tooltip>
                            <Tooltip
                                target=".flowCapacityCol"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh per hour</div>
                            </Tooltip>
                            <Tooltip
                                target=".flowCapacityField"
                                position="top"
                                showEvent="mouseenter"
                                hideEvent="mouseleave"
                                hideOnOutsideClick={false}
                            >
                                <div>KWh per hour</div>
                            </Tooltip>

                        </>
                    )}
                </CardContent>
            </PageContainer>

            <Dialog
                onClose={() => closeConfirmation()}
                open={confirmReservation}
                fullWidth={true}
                maxWidth="md"
            >
                <DialogTitle
                    sx={{
                        p: 3
                    }}
                >
                    <Typography variant="h4" gutterBottom>
                        {'Book Confirmation'}
                    </Typography>
                    <Typography variant="subtitle2">
                        {`Are you sure you want to book Flow Capacity ${capacityBooking?.flowCapacity} kWh/h - (${capacityBooking?.entryTerminal == Terminal.BIDIRECTIONAL ? 'Bidirectional' : (capacityBooking?.entryTerminal == Terminal.BACTON ? 'BCT to ZEE' : 'ZEE to BCT' )})?`}
                    </Typography>
                    <CloseIcon
                        style={{
                            float: 'right',
                            marginTop: '-50px',
                            cursor: 'pointer'
                        }}
                        onClick={() => closeConfirmation()}
                    />
                </DialogTitle>
                <DialogContent>

                </DialogContent>
                <DialogActions>
                    <Button color="secondary" onClick={() => closeConfirmation()}>
                        Cancel
                    </Button>
                    <Button
                        color="primary"
                        onClick={() => submitReservation()}
                        variant="contained">
                        Book Capacity
                    </Button>
                </DialogActions>
            </Dialog>

        </>
    );
};


const terminalsData = [
    { id: Terminal.BACTON, name: 'Bacton' },
    { id: Terminal.ZEEBRUGGE, name: 'Zeebrugge' },
    { id: Terminal.BIDIRECTIONAL, name: 'Bidirectional' }
];

export default BookCapacity;
