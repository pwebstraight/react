import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import PageTitleWrapper from 'src/components/PageTitleWrapper';
import { DashboardDiagram } from 'src/components/DashboardDiagram';
import { CapacityBookingService } from 'src/api/services/CapacityBookingService';

function Dashboard()
{
    const [isLoading, setIsLoading] = useState(false);
    const [dashboardData, setDashboardData] = useState(null);


    useEffect(() =>
    {
        loadDashboard();
    }, []);

    async function loadDashboard()
    {
        if (!isLoading)
        {
            setIsLoading(true);

            try
            {
                const data = await CapacityBookingService.postApiCapacityBookingGetDashboardData();
                setDashboardData(data);
            }
            finally
            {
                setIsLoading(false);
            }
        }
    }

    return (
        <>
            <Helmet>
                <title>Interconnector</title>
            </Helmet>
            <PageTitleWrapper>
                Dashboard
            </PageTitleWrapper>
            {
                dashboardData &&
                <DashboardDiagram data={dashboardData} />
            }

        </>
    );
}

export default Dashboard;
