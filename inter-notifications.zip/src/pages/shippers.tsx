import React, { useState, useEffect, ReactNode } from 'react';
import 'devextreme/data/odata/store';
import PageTitleWrapper from 'src/components/PageTitleWrapper';
import { useAppDispatch } from "src/store/configureStore";
import PageContainerFull from 'src/components/PageContainerFull';
import { ShipperService } from 'src/api/services/ShipperService';
import { loadShipperCash } from "src/store/shipperSlice";
import Traders from 'src/components/Traders';

import DataGrid, {
    Column,
    Pager,
    Editing,
    Paging,
    Selection,
    HeaderFilter,
    MasterDetail,
    Form,
    Popup,
    FilterRow,
    RequiredRule
} from 'devextreme-react/data-grid';

import { Item } from 'devextreme-react/form';
import { ShipperDto } from '../api';
import { RowInsertingEvent, RowPreparedEvent, RowRemovedEvent, RowUpdatedEvent } from 'devextreme/ui/data_grid';

function Shippers()
{
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [shippers, setShippers] = useState<ShipperDto[]>([]);
    const dispatch = useAppDispatch();

    useEffect(() =>
    {
        loadShippers()
    }, []);

    async function loadShippers()
    {
        if (!isLoading)
        {
            setIsLoading(true);

            try
            {
                let shippersData = await ShipperService.postApiShipperGetAll();
                setShippers(shippersData);
            }
            finally
            {
                setIsLoading(false);
            }
        }
    }

    function onRowUpdated(e: RowUpdatedEvent<ShipperDto, number>)
    {
        saveShipper(e.data);
    }

    function onRowInserting(e: RowInsertingEvent<ShipperDto, number>)
    {
        let shipper: ShipperDto =
        {
            ...e.data, 
            isActive: true,
            providerCode: "IUK",
        };

        saveShipper(shipper);
    }

    function onRowRemoved(e: RowRemovedEvent<ShipperDto, number>)
    {
        let shipper: ShipperDto =
        {
            ...e.data,
            isActive: false
        };

        saveShipper(shipper);
    }

    function onRowPrepared(e: RowPreparedEvent<ShipperDto, number>)
    {
        if (e.rowType === "data")
        {
            if (e.rowIndex % 2 === 1)
            {
                e.rowElement.style.backgroundColor = "white";
            }
            else
            {
                e.rowElement.style.backgroundColor = "#e6faff";
            }
        }
    }

    async function saveShipper(shipper : ShipperDto)
    {
        await ShipperService.postApiShipperSave(shipper);        
        dispatch(loadShipperCash([])); //clean the cache which will trigger a new load on the other pages
    }

    return (
        <>
            <PageTitleWrapper>
                Shippers Administration
            </PageTitleWrapper>
            <PageContainerFull>
                <DataGrid
                    className={'dx-card wide-card'}
                    dataSource={shippers}
                    showBorders={false}
                    focusedRowEnabled={true}
                    keyExpr='id'
                    defaultFocusedRowIndex={0}
                    columnAutoWidth={true}
                    columnHidingEnabled={true}
                    onRowUpdated={onRowUpdated}
                    onRowInserting={onRowInserting}
                    onRowPrepared={onRowPrepared}
                    onRowRemoved={onRowRemoved}
                >
                    <Selection mode="single" />
                    <HeaderFilter visible={true} />
                    <Paging defaultPageSize={20} />
                    <Pager showPageSizeSelector={true} showInfo={true} />
                    <FilterRow visible={true} />
                    <Editing
                        mode="popup"
                        allowUpdating={true}
                        allowAdding={true}
                        allowDeleting={true}
                        useIcons={true}
                    >
                        <Popup title="Shipper Info" showTitle={true} width={700} height={525} />
                        <Form>
                            <Item itemType="group" colCount={1} colSpan={2}>
                                <Item dataField="shipperEic" ><RequiredRule /></Item>
                                <Item dataField="organisationName" ><RequiredRule /></Item>
                                <Item dataField="legalEntityIdentifier"><RequiredRule /></Item>
                                <Item dataField="postBrexitAcer"><RequiredRule /></Item>
                            </Item>
                        </Form>
                    </Editing>
                    <MasterDetail
                        enabled={true}
                        component={Traders}
                    />
                    <Column
                        dataField={'shipperEic'}
                        width={290}
                        caption={'Shipper Eic'}
                    />
                    <Column
                        dataField={'organisationName'}
                        width={190}
                        caption={'Org Name'}
                    />
                    <Column
                        dataField={'legalEntityIdentifier'}
                        width={290}
                        caption={'Legal Entity Identifier'}
                    />
                    <Column
                        dataField={'postBrexitAcer'}
                        caption={'Post Brexit Acer'}
                        width={150}
                    />
                    <Column
                        dataField={'providerCode'}
                        caption={'Provider Code'}
                        width={150}
                    />
                </DataGrid>
            </PageContainerFull>
        </>
    )
}

export default Shippers;
