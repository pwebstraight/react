import { useState, useEffect, ReactNode } from 'react';
import PageTitleWrapper from 'src/components/PageTitleWrapper';
import { useAppDispatch, useAppSelector } from "src/store/configureStore";
import SelectBox from 'devextreme-react/select-box';
import CloseIcon from "@mui/icons-material/CloseTwoTone";
import HeaderSearch from 'src/layouts/SidebarLayout/Header/Buttons/Search';
import { CapacityBookingService } from 'src/api/services/CapacityBookingService';
import PageContainerFull from 'src/components/PageContainerFull';
import { Terminal } from 'src/api/models/Terminal';
import moment from 'moment';
import _ from "lodash"

import
{
    Button,
    Grid,
    CircularProgress,
    Card,
    Dialog,
    DialogContent,
    DialogTitle,
    DialogActions,
    Box,
    TextField,
    Typography,
    CardHeader,
    Divider,
    Alert as MuiAlert
} from "@mui/material";

import DataGrid, {
    Column,
    HeaderFilter,
    FilterPanel,
    FilterRow,
} from 'devextreme-react/data-grid';
import { BookingState, CapacityBookingDto, UserRole } from '../api';
import { ContextMenuPreparingEvent, RowPreparedEvent } from 'devextreme/ui/data_grid';


const History = () =>
{
    const { reservations } = useAppSelector(state => state.reservations);
    const { shippers } = useAppSelector(state => state.shippers);
    const { user } = useAppSelector(state => state.user);

    const gasIdLabel = "Gas Trade ID";
    const iCapacityLabel = "Capacity Trade ID";
    const utiLabel = "UTI";

    const [isLoading, setIsLoading] = useState(false);
    const [selectedReservation, setSelectedReservation] = useState<CapacityBookingDto>(null);
    const [filteredReservations, setFilteredReservations] = useState<CapacityBookingDto[]>(null);       // todo make that a map    
    const [gasIdPopup, setGasIdPopup] = useState(false);
    const [reservationPopup, setReservationPopup] = useState(false);
    const [searchValue, setSearchValue] = useState(null);

    useEffect(() => {
        if (reservations != null)
            setFilteredReservations(reservations);
    }, []);
    
    useEffect(() =>
    { 
        filterReservations();
    }, [reservations, searchValue]);

    function filterReservations()
    {
        let newState = [];

        if (reservations == null)
        {
            setFilteredReservations(null);
            return; 
        }

        if (searchValue == null || searchValue === "")
        {
            if (location.search && location.search !== "" && location.search.indexOf("q=") >= 0)
            {
                const query = location.search.split('q=')[1];

                if (query !== '')
                {
                    setSearchValue(query);
                    return;
                }
            }

            setFilteredReservations(reservations);
            return;
        }

        reservations.forEach(reservation =>
        {
            if (reservation.sellGasTradeId?.indexOf(searchValue) >= 0 ||
                reservation.buyGasTradeId?.indexOf(searchValue) >= 0 ||
                reservation.entryCapacityTradeId?.indexOf(searchValue) >= 0 ||
                reservation.exitCapacityTradeId?.indexOf(searchValue) >= 0 ||
                reservation.entryUti?.indexOf(searchValue) >= 0 ||
                reservation.exitUti?.indexOf(searchValue) >= 0 ||
                reservation.broker?.userName?.toLowerCase().indexOf(searchValue.toLowerCase()) >= 0 ||
                reservation.flowCapacity?.toString() == searchValue.toLowerCase() ||
                reservation.shipper?.organisationName?.indexOf(searchValue) >= 0 ||
                reservation.bookingState?.toLowerCase() === searchValue.toLowerCase() ||
                reservation.messageId?.toLowerCase() === searchValue.toLowerCase() ||
                reservation.trader?.displayName?.toLowerCase() === searchValue.toLowerCase()
            )
            {
                const exists = newState.filter(r => r.id === reservation.id);
                if (exists.length === 0) newState.push(reservation);
            }
        });
            
        setFilteredReservations(newState);
    }

    function clearFilter()
    {
        window.history.replaceState({}, 'Interconnector', "/history");
        setSearchValue(null);
        setFilteredReservations(reservations);
    }

    function onRowPrepared(e: RowPreparedEvent<CapacityBookingDto, number>)
    {
        if (e.rowType === "data")
        {
            if (e.rowIndex % 2 === 1)
            {
                e.rowElement.style.backgroundColor = "white";
            }
            else
            {
                e.rowElement.style.backgroundColor = "#e6faff";
            }
        }
    }

    const openEditPopup = (data: CapacityBookingDto, action: string) =>
    {
        setSelectedReservation(data);

        switch (action)
        {
            case "GasID": {
                setGasIdPopup(true);
                break;
            }
            case "CapacityID":
            case "Amend": {
                setReservationPopup(true);
                break;
            }
        }
    };
   
    function closeReservationPopup()
    {
        setGasIdPopup(false);
        setReservationPopup(false);
    };

    async function updateGasTradeReservation()
    {
        setGasIdPopup(false);
        setReservationPopup(false);
        await CapacityBookingService.postApiCapacityBookingUpdateGasTradeIds(selectedReservation);        
    }

    async function updateCapacityTradeReservation()
    {        
        setGasIdPopup(false);
        setReservationPopup(false);
        await CapacityBookingService.postApiCapacityBookingUpdateCapacityTradeIds(selectedReservation);        
    }

    function onReservationPropertyChange (event: React.ChangeEvent<HTMLInputElement>)
    {
        let currentReservation = { ...selectedReservation };
        currentReservation[event.target.name] = event.target.value;
        setSelectedReservation(currentReservation);
    }

    const onSearchHandle = (searchText) =>
    {
        if (searchText !== "")
        {
            window.history.replaceState({}, 'Interconnector', "/history?q=" + searchText);
            setSearchValue(searchText);
        }
        else
        {
            clearFilter();
        }
    }

    const StatusColor = (status: BookingState) =>
    {
        switch (status)
        {
            case BookingState.ACCEPTED: return "#baffc9";
            case BookingState.REJECTED: return "#ffb3ba";
            case BookingState.CANCELLED: return "lightGray";
            case BookingState.CONFIRMED: return "#bae1ff";
            case BookingState.INITIAL: return "#bae1ff";
            case BookingState.AMENDED: return "#bae1ff";
            case BookingState.PENDING: return "#ffffba";
            case BookingState.READY: return "#baffc9";
            case BookingState.IN_ERROR: return "#ffb3ba";
        }
    }

    function RenderGasTradeIdCell(cellData: { data: CapacityBookingDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title="Buy Gas Trade Id (Trayport)">
                    {cellData.data.buyGasTradeId}
                </div>
                <div style={{ margin: "-7px", padding: "7px" }} title="Sell Gas Trade Id (Trayport)">
                    {cellData.data.sellGasTradeId}
                </div>
            </div>
        );
    }

    function RenderUnitPriceCell(cellData: { data: CapacityBookingDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title="Entry unit price (pence per kWh)">
                    {cellData.data.entryUnitPrice.toFixed(6)}
                </div>
                <div style={{ margin: "-7px", padding: "7px" }} title="Exit unit price (pence per kWh)">
                    {cellData.data.exitUnitPrice.toFixed(6)}
                </div>
            </div>
        );
    }

    function RenderCapacityTradeIdCell(cellData: { data: CapacityBookingDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title="Entry Capacity Trade Id (ICapture)">
                    {cellData.data.entryCapacityTradeId}
                </div>
                <div style={{ margin: "-7px", padding: "7px" }} title="Exit Capacity Trade Id (ICapture)">
                    {cellData.data.exitCapacityTradeId}
                </div>
            </div>
        );
    }

    function RenderUtiCell(cellData: { data: CapacityBookingDto }): ReactNode
    {
        return (
            <div style={{ margin: "0", padding: "0" }}>
                <div style={{ margin: "-7px", padding: "7px" }} title="Entry UTI (ICapture)">
                    {cellData.data.entryUti}
                </div>
                <div style={{ margin: "-7px", padding: "7px" }} title="Exit UTI (ICapture)">
                    {cellData.data.exitUti}
                </div>
            </div>
        );
    }

    function RenderActionButton(cellData: { data: CapacityBookingDto }): ReactNode
    {        
        let title = "None";
        let caption = "Book";
        let action = "None";

        if (cellData.data.bookingState == BookingState.READY && user && (user.role == UserRole.OPERATIONS || user.role == UserRole.ADMIN))
        {
            title = "Enter Capacity Trade Id";
            action = "CapacityID";
        }
        else if (cellData.data.bookingState == BookingState.ACCEPTED && user && (user.role == UserRole.BROKER || user.role == UserRole.ADMIN))
        {
            title = "Enter Gas Trade Id";
            action = "GasID";
        }
        else
        {
            return (<> </>);
        }

        return (
            <>
                {
                    action != "None" &&
                    <div style={{ marginTop: "14px" }}>
                        <a title={title} style={{
                            cursor: 'pointer',
                            backgroundColor: "green",
                            borderRadius: "6px",
                            paddingTop: "10px",
                            paddingBottom: "10px",
                            width: "100px",
                            textAlign: "center",
                            fontWeight: "bold",
                            color: "white",
                            paddingLeft: "30px",
                            paddingRight: "30px"
                        }}
                            className="custom-button"
                            onClick={() => openEditPopup(cellData.data, action)}
                            color="secondary">
                            {caption}
                        </a>
                    </div>
                }
            </>
        );
    };

    const ContextMenuPreparing = (e: ContextMenuPreparingEvent) =>
    {
        if (e.row.data.bookingState != BookingState.PENDING) return;

        if (!e.items) e.items = [];

        e.items.push(
            {
                text: "Accept (Workaround)",
                onItemClick: () =>
                {
                    CapacityBookingService.postApiCapacityBookingWorkaroundAccept(e.row.data.id);
                }
            });

        e.items.push(
            {
                text: "Reject (Workaround)",
                onItemClick: () =>
                {
                    CapacityBookingService.postApiCapacityBookingWorkaroundReject(e.row.data.id);
                }
            });
    }

    return (
        <>
            <PageTitleWrapper>
                Reservation History <HeaderSearch onSearchHandle={onSearchHandle} />
                {
                    searchValue &&
                    <div style={{ fontSize: '18px', color: 'rgb(110, 117, 159)', fontWeight: 'bold' }}>
                        <Button variant="contained" id="clearButton" color="primary" onClick={() => clearFilter()}>
                            Clear current filter
                        </Button> - {searchValue}
                    </div>
                }
            </PageTitleWrapper>
            <PageContainerFull>
                {
                    !isLoading ? (
                        <>
                            <DataGrid
                                keyExpr="id"
                                dataSource={filteredReservations}
                                focusedRowEnabled={true}
                                showBorders={true}
                                columnAutoWidth={true}                                
                                onRowPrepared={onRowPrepared}
                                columnResizingMode={'widget'}
                                allowColumnResizing={true}
                                onContextMenuPreparing={ContextMenuPreparing}
                            >
                                <HeaderFilter visible={true} />
                                <FilterRow visible={false} />
                                <FilterPanel visible={false} />

                                <Column
                                    dataField="bookingState"
                                    width={100}
                                    caption="Status"
                                    visible={true}
                                    showInColumnChooser={true}
                                    allowResizing={false}
                                    cellRender={
                                        cellInfo =>
                                        (<div style={{
                                            paddingTop: '21px',
                                            paddingBottom: '21px',
                                            backgroundColor: StatusColor(cellInfo.value),
                                            textAlign: "center",
                                            fontWeight: "bold",
                                            color: "DimGray",
                                            margin: '-7px'

                                        }}>{cellInfo.text}</div>)} />

                                <Column
                                    sortOrder="desc"
                                    dataField="dateCreated" format="d MMM yyyy HH:mm" dataType="date" caption={'Created'} width={130} allowFiltering={false}
                                    cellRender={cellInfo => (<div style={{ paddingTop: '14px' }} title="Start Date">{cellInfo.text}</div>)} />

                                <Column dataField="startDate" format="d MMM yyyy" dataType="date" caption={'Start Date'} width={90} allowFiltering={false}
                                    cellRender={cellInfo => (<div style={{ paddingTop: '14px' }} title="Start Date">{cellInfo.text}</div>)} />

                                <Column dataField="endDate" format="d MMM yyyy" dataType="date" caption={'End Date'} width={90} allowFiltering={false}
                                    cellRender={cellInfo => (<div style={{ paddingTop: '14px' }} title="End Date">{cellInfo.text}</div>)} />

                                <Column dataField="broker.userName" caption={'Broker'} width={110}
                                    cellRender={cellInfo => (<div style={{ paddingTop: '14px' }} title="Broker">{cellInfo.text}</div>)} />

                                <Column
                                    caption={'Shipper/Trader'} width={150}
                                    allowFiltering={false}
                                    cellRender={(cellData: { data: CapacityBookingDto }) => (
                                        <div style={{ margin: "0", padding: "0" }}>
                                            <div style={{ margin: "-7px", padding: "7px" }} title="Shipper">
                                                {cellData.data.shipper?.organisationName}
                                            </div>
                                            <div style={{ margin: "-7px", padding: "7px" }} title="Trader">
                                                {cellData.data.trader?.displayName}
                                            </div>
                                        </div>
                                    )}
                                    visible={true}
                                    showInColumnChooser={true} />

                                <Column
                                    caption="Terminals"
                                    width={100}
                                    dataField="entryTerminal"
                                    allowFiltering={false}
                                    cellRender={(cellData: { data: CapacityBookingDto }) => (
                                        <div style={{ margin: "0", padding: "0" }}>
                                            <div style={{ margin: "-7px", padding: "7px" }} title="Entry Terminal">
                                                {cellData.data.entryTerminal}
                                            </div>
                                            <div style={{ margin: "-7px", padding: "7px" }} title="Exit Terminal">
                                                {cellData.data.exitTerminal}
                                            </div>
                                        </div>
                                    )}
                                    visible={true}
                                    showInColumnChooser={true}
                                />

                                <Column
                                    caption="Unit Price"
                                    width={80}
                                    cellRender={RenderUnitPriceCell}
                                    visible={true}
                                    dataType="number"
                                    showInColumnChooser={true}
                                    hidingPriority={3}
                                />

                                <Column dataField={'flowCapacity'} width={80} caption={'Flow Capacity'} allowFiltering={false}
                                    cellRender={cellInfo => (<div title="Flow Capacity (kWh/h)" style={{ paddingTop: '14px' }}>{cellInfo.text}</div>)} />

                                {/*<Column dataField={'totalCapacity'} width={90} caption={'Total Capacity'} allowFiltering={false}*/}
                                {/*    cellRender={cellInfo => (<div style={{ paddingTop: '14px' }} title="Total Capacity (kWh/h)">{cellInfo.text}</div>)} />*/}

                                {/*<Column dataField={'hours'} width={90} caption={'Hours'} allowFiltering={false} allowResizing={false}*/}
                                {/*    cellRender={cellInfo => (<div style={{ paddingTop: '14px' }} title="Hours">{cellInfo.text}</div>)} />*/}

                                <Column
                                    caption="Gas Trade Id"
                                    width={150}
                                    cellRender={RenderGasTradeIdCell}
                                    visible={true}
                                    showInColumnChooser={true}
                                    hidingPriority={3}
                                />

                                <Column
                                    caption="Capacity Trade Id"
                                    width={150}
                                    cellRender={RenderCapacityTradeIdCell}
                                    visible={true}
                                    showInColumnChooser={true}
                                    hidingPriority={3}
                                />

                                <Column
                                    caption="Capacity UTI"
                                    width={150}
                                    cellRender={RenderUtiCell}
                                    visible={true}
                                    showInColumnChooser={true}
                                    hidingPriority={3}
                                />

                                <Column
                                    caption="Action"
                                    width={110}
                                    allowResizing={false}
                                    cellRender={RenderActionButton}
                                    visible={true}
                                    showInColumnChooser={false}
                                />

                            </DataGrid>
                        </>
                    ) : (
                        <CircularProgress size={26} />
                    )}
            </PageContainerFull>

            {gasIdPopup &&
                <Dialog
                    onClose={closeReservationPopup}
                    open={gasIdPopup}
                    fullWidth={true}
                    maxWidth="md"
                >
                    <DialogTitle sx={{ p: 3 }} >
                        <Typography variant="h4" gutterBottom>
                            Book Gas Trades
                        </Typography>
                        <Typography variant="subtitle2">
                            From <b>{selectedReservation.entryTerminal}</b> to <b>{selectedReservation.exitTerminal}</b> with shipper <b>{selectedReservation.shipper.organisationName}</b>
                        </Typography>
                        <CloseIcon style={{ float: 'right', marginTop: '-50px', cursor: 'pointer' }} onClick={closeReservationPopup} />
                    </DialogTitle>
                    <DialogContent>
                        <table style={{ fontSize: '14px', width: '650px' }}>
                            <tr style={{ height: '30px' }}>
                                <td style={{ width: '150px' }}>Buy Gas Trade ID</td>
                                <td style={{ fontWeight: 'bold', padding: '5px' }}>
                                    <TextField id="outlined-basic" label="Trayport Trade ID"
                                        name='buyGasTradeId'
                                        fullWidth={true}
                                        value={selectedReservation.buyGasTradeId}
                                        onChange={onReservationPropertyChange}
                                    />
                                </td>
                            </tr>
                            <tr style={{ height: '30px' }}>
                                <td style={{ width: '150px', color: '#5569ff' }}>Sell Gas Trade ID</td>
                                <td style={{ fontWeight: 'bold', padding: '5px' }}>
                                    <TextField id="outlined-basic" label="Trayport Trade ID"
                                        name='sellGasTradeId'
                                        fullWidth={true}
                                        value={selectedReservation.sellGasTradeId}
                                        onChange={onReservationPropertyChange}
                                    />
                                </td>
                            </tr>
                        </table>

                    </DialogContent>
                    <DialogActions>
                        <Button color="secondary" onClick={closeReservationPopup}>
                            Cancel
                        </Button>
                        <Button color="primary" onClick={updateGasTradeReservation} variant="contained">
                            Update
                        </Button>
                    </DialogActions>
                </Dialog>
            }

            {reservationPopup &&
                <Dialog
                    onClose={() => closeReservationPopup()}
                    open={reservationPopup}
                    fullWidth={true}
                    maxWidth="md"
                >
                    <DialogTitle
                        sx={{ p: 3, backgroundColor: "#f2f5f9", }} >
                        <Typography variant="h4" gutterBottom>
                            {
                                selectedReservation.bookingState == BookingState.CONFIRMED &&
                                <span>{('Amend Reservation')}</span>
                            }
                            {
                                selectedReservation.bookingState != BookingState.CONFIRMED &&
                                <span>{('Book Capacity Trades')}</span>
                            }
                        </Typography>
                        <Typography variant="subtitle2">
                            From <b>{selectedReservation.entryTerminal}</b> to <b>{selectedReservation.exitTerminal}</b> with shipper <b>{selectedReservation.shipper.organisationName}</b>
                        </Typography>
                        <CloseIcon style={{ float: 'right', marginTop: '-50px', cursor: 'pointer' }} onClick={() => closeReservationPopup()} />
                    </DialogTitle>
                    <DialogContent style={{ backgroundColor: "#f2f5f9" }}>
                        <Grid container spacing={3}>
                            <Grid item xs={12} sm={6}>
                                <Card>
                                    <CardHeader
                                        title={"Entry Terminal : " + selectedReservation.entryTerminal}
                                    />
                                    <Divider />
                                    <Box p={2}>
                                        {
                                            selectedReservation.bookingState == BookingState.CONFIRMED &&
                                            <TextField style={{ marginBottom: '15px' }} id="outlined-basic"
                                                label={gasIdLabel}
                                                name='sellGasTradeId'
                                                fullWidth={true}
                                                value={selectedReservation.sellGasTradeId}
                                                onChange={onReservationPropertyChange}
                                            />
                                        }
                                        <TextField id="outlined-basic" label={iCapacityLabel}
                                            name="entryCapacityTradeId"
                                            fullWidth={true}
                                            value={selectedReservation.entryCapacityTradeId}
                                            onChange={onReservationPropertyChange}
                                        />
                                        <TextField style={{ marginTop: '15px' }} id="outlined-basic"
                                            label={utiLabel}
                                            name="entryUti"
                                            fullWidth={true}
                                            value={selectedReservation.entryUti}
                                            onChange={onReservationPropertyChange}
                                        />
                                        {
                                            selectedReservation.bookingState == BookingState.CONFIRMED &&
                                            <TextField style={{ marginTop: '15px' }} id="outlined-basic"
                                                name="flowCapacity"
                                                label='Quanity'
                                                type='number'
                                                fullWidth={true}
                                                value={selectedReservation.flowCapacity}
                                                onChange={onReservationPropertyChange}
                                            />
                                        }
                                        {
                                            selectedReservation.bookingState == BookingState.CONFIRMED &&
                                            <TextField style={{ marginTop: '15px' }} id="outlined-basic"
                                                label='Price'
                                                type='number'
                                                name='entryUnitPrice'
                                                fullWidth={true}
                                                value={selectedReservation.entryUnitPrice}
                                                onChange={onReservationPropertyChange}
                                            />
                                        }
                                    </Box>
                                </Card>
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <Card>
                                    <CardHeader
                                        title={"Exit Terminal : " + selectedReservation.exitTerminal}
                                    />
                                    <Divider />
                                    <Box p={2}>
                                        {
                                            selectedReservation.bookingState == BookingState.CONFIRMED &&
                                            <TextField style={{ marginBottom: '15px' }} id="outlined-basic"
                                                label={gasIdLabel}
                                                name='sellGasTradeId'
                                                fullWidth={true}
                                                value={selectedReservation.sellGasTradeId}
                                                onChange={onReservationPropertyChange}
                                            />
                                        }
                                        <TextField id="outlined-basic" label={iCapacityLabel}
                                            name='exitCapacityTradeId'
                                            fullWidth={true}
                                            value={selectedReservation.exitCapacityTradeId}
                                            onChange={onReservationPropertyChange}
                                        />
                                        <TextField style={{ marginTop: '15px' }} id="outlined-basic"
                                            label={utiLabel}
                                            name="exitUti"
                                            fullWidth={true}
                                            value={selectedReservation.exitUti}
                                            onChange={onReservationPropertyChange}
                                        />
                                        {
                                            selectedReservation.bookingState == BookingState.CONFIRMED &&
                                            <TextField style={{ marginTop: '15px' }} id="outlined-basic"
                                                label='Quanity'
                                                type='number'
                                                name='flowCapacity'
                                                fullWidth={true}
                                                value={selectedReservation.flowCapacity}
                                                onChange={onReservationPropertyChange}
                                            />
                                        }
                                        {
                                            selectedReservation.bookingState == BookingState.CONFIRMED &&
                                            <TextField style={{ marginTop: '15px' }} id="outlined-basic"
                                                label='Price'
                                                type='number'
                                                name='exitUnitPrice'
                                                fullWidth={true}
                                                value={selectedReservation.exitUnitPrice}
                                                onChange={onReservationPropertyChange}
                                            />
                                        }
                                    </Box>
                                </Card>
                            </Grid>
                            {
                                selectedReservation.bookingState == BookingState.CONFIRMED &&
                                <Grid item xs={12} sm={12}>
                                    <Card>
                                        <Box p={2}>
                                            <SelectBox style={{ marginBottom: '5px' }} dataSource={shippers}
                                                label={'Shipper'}
                                                displayExpr="organisationName"
                                                valueExpr="id"
                                                defaultValue={selectedReservation.shipper}
                                            />
                                        </Box>

                                    </Card>
                                    <MuiAlert elevation={6} variant="filled" severity="warning" style={{ fontSize: "16px", marginTop: "10px" }}>
                                        Trade amendments/cancellations will not be automatically notified to Interconnector via the application.
                                        Please ensure you have agreed any amendment/cancellation with Interconnector prior to saving (+44 20 3621 7800 / <a style={{ color: 'white' }} href="mailto:operations@interconnector.com">operations@interconnector.com</a>)
                                    </MuiAlert>
                                </Grid>
                            }
                        </Grid>
                    </DialogContent>
                    <DialogActions>
                        <Button color="secondary" onClick={closeReservationPopup}>
                            Cancel
                        </Button>
                        <Button color="primary" onClick={updateCapacityTradeReservation} variant="contained">
                            Update
                        </Button>
                    </DialogActions>
                </Dialog>
            }
        </>
    );
};

export default History;
