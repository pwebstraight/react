import { useState, useEffect } from 'react';
import 'devextreme/data/odata/store';
import PageTitleWrapper from 'src/components/PageTitleWrapper';
import PageContainerFull from 'src/components/PageContainerFull';
import { UserService } from 'src/api/services/UserService';

import DataGrid, {
    Column,
    Pager,
    Editing,
    Paging,
    Lookup,
    Form,
    Popup,
    FilterRow,
    RequiredRule
} from 'devextreme-react/data-grid';

import { Item } from 'devextreme-react/form';
import { UserDto, UserRole } from '../api';
import { InitNewRowEvent, RowInsertingEvent, RowPreparedEvent, RowRemovedEvent, RowUpdatedEvent, RowUpdatingEvent } from 'devextreme/ui/data_grid';

const Users = () =>
{
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [users, setUsers] = useState <UserDto[]>([]);

    useEffect(() =>
    {
        loadUsers()
    }, []);

    async function loadUsers()
    {
        if (!isLoading)
        {
            setIsLoading(true);

            try
            {
                const usersData = await UserService.postApiUserGetAllUsers();
                setUsers(usersData);
                setIsLoading(false);
            }
            catch
            {

            }
            finally
            {
                setIsLoading(false);
            }
        }
    }

    function onRowPrepared(e: RowPreparedEvent<UserDto, number>)
    {
        if (e.rowType === "data")
        {
            if (e.rowIndex % 2 === 1)
            {
                e.rowElement.style.backgroundColor = "#e6faff";
            }
        }
    }

    function onRowUpdated(e: RowUpdatedEvent<UserDto, number>)
    {
        saveUser(e.data);
    }

    function onRowRemoved(e: RowRemovedEvent<UserDto, number>)
    {
        saveUser({ ...e.data, isActive : false});
    }

    function onInitNewRow(e: InitNewRowEvent<UserDto, number>)
    {
        e.data.isActive = true;
    }

    function onRowInserting(e: RowInsertingEvent<UserDto, number>)
    {
        saveUser({ ...e.data, isActive: true, id: 0 });
    }

    async function saveUser(user: UserDto)
    {
        await UserService.postApiUserSaveUser(user);
        loadUsers();
    }

    return (
        <>
            <PageTitleWrapper>
                Users Administration
            </PageTitleWrapper>
            <PageContainerFull>
                <DataGrid
                    className={'dx-card wide-card'}
                    dataSource={users}
                    showBorders={false}
                    focusedRowEnabled={true}
                    keyExpr='id'
                    defaultFocusedRowIndex={0}
                    columnAutoWidth={true}
                    columnHidingEnabled={true}
                    onInitNewRow={onInitNewRow}
                    onRowUpdated={onRowUpdated}
                    onRowInserting={onRowInserting}
                    onRowPrepared={onRowPrepared}
                    onRowRemoved={onRowRemoved}
                >
                    <Paging defaultPageSize={20} />
                    <Pager showPageSizeSelector={true} showInfo={true} />
                    <FilterRow visible={true} />
                    <Editing
                        mode="popup"
                        useIcons={true}
                        allowUpdating={true}
                        allowAdding={true}
                        allowDeleting={true}
                    >
                        <Popup title="User Info" showTitle={true} width={700} height={525} />
                        <Form>
                            <Item itemType="group" colCount={1} colSpan={2}>
                                <Item dataField="email" ><RequiredRule /></Item>
                                <Item dataField="userName" ><RequiredRule /></Item>
                                <Item dataField="role"><RequiredRule /></Item>
                            </Item>
                        </Form>
                    </Editing>
                    <Column
                        dataField={'email'}
                        width={290}
                        caption={'Email'}
                    />
                    <Column
                        dataField={'userName'}
                        width={290}
                        caption={'User Name'}
                    />
                    <Column
                        dataField={'role'}
                        caption={'Role'}
                        width={150}
                    >
                        <Lookup dataSource={roles} valueExpr="id" displayExpr="name" />
                    </Column>
                </DataGrid>
            </PageContainerFull>
        </>
    )
}

const roles = {
    store: {
        type: 'array',
        key: 'id',
        data: [
            { id: UserRole.ADMIN, name: 'Admin' },
            { id: UserRole.BROKER, name: 'Broker' },
            { id: UserRole.OPERATIONS, name: 'Operations' },
            { id: UserRole.SUPPORT, name: 'Support' },
        ]
    }
}

export default Users;
