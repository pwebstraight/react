import { Accordion, AccordionDetails, AccordionSummary, Tooltip, Typography } from "@mui/material";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import PageContainerFull from "src/components/PageContainerFull";
import PageTitleWrapper from "src/components/PageTitleWrapper";
import FileUploader from "devextreme-react/file-uploader";
import { CSSProperties, ReactNode, SetStateAction, useEffect, useState } from "react";
import
{
    Column,
    DataGrid,
    FilterRow,
    HeaderFilter,
    Editing,
    Pager,
    Paging,
    Button
} from "devextreme-react/data-grid";
import { ImportDto } from "src/api";
import Hub from "src/api/Hub";
import { UploadErrorEvent } from "devextreme/ui/file_uploader";
import InfoIcon from '@mui/icons-material/InfoOutlined'
import { ImportService } from "../api/services/ImportService";
import { RowPreparedEvent } from "devextreme/ui/data_grid";

export default function Prices()
{

    const [imports, setImports] = useState<ImportDto[]>([])

    const flexBoxStyle: CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center'
    }
    useEffect(() =>
    {
        try
        {
            loadImports();
        } catch (error)
        {
            console.log(error)
        }

    }, [])

    useEffect(() =>
    {
        if (Hub.SignalRConnection)
        {
            Hub.SignalRConnection.on(
                'UpdateAllImports',
                (imports: SetStateAction<ImportDto[]>) =>
                {
                    setImports(imports);
                });
        }
    }, []);

    async function loadImports()
    {
        let imports = await ImportService.postApiImportGetAllImports();
        setImports(imports)
    }

    function customizeUploadError(e: UploadErrorEvent): void
    {
        e.message = 'File upload failed: ' + `\'${e.error}\'`
    }

    async function uploadPriceFile(file: File, _)
    {
        try
        {
            await ImportService.postApiImportImportPriceCsv({ tariffFile: file })
        } catch (error)
        {
            console.log(error)
        }
    }

    async function uploadCapacityFile(file: File, _)
    {
        try
        {
            await ImportService.postApiImportImportVolumeCsv({ capiaFile: file })
        } catch (error)
        {
            console.log(error)
        }
    }

    function renderStatusColumn(cellData: { data: ImportDto }): ReactNode
    {
        if (cellData.data.status.toLowerCase() === "failure")
        {
            return (
                <Tooltip title={cellData.data.failureReason}>
                    <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                        {cellData.data.status}
                        <InfoIcon fontSize="small" style={{ verticalAlign: 'center' }} />
                    </div>
                </Tooltip>)
        }
        else return <div>{cellData.data.status}</div>
    }

    function onRowPrepared(e: RowPreparedEvent<ImportDto, any>): void
    {
        if (e.rowType === 'data')
        {
            if (e.data.status.toLowerCase() === 'failure')
            {
                e.rowElement.style.backgroundColor = '#F4B9C0';
            }
            else
            {
                if (e.rowIndex % 2 === 1)
                {
                    e.rowElement.style.backgroundColor = "white";
                }
                else
                {
                    e.rowElement.style.backgroundColor = "#e6faff";
                }
            }
        }
    }

    return (
        <>
            <PageTitleWrapper>
                File Upload
            </PageTitleWrapper>
            <PageContainerFull>
                <Accordion variant="outlined" style={{ marginBottom: '10px' }}>
                    <AccordionSummary
                        style={{ backgroundColor: "#eeeeee" }}
                        id="pricing-panel-header"
                        aria-controls="pricing-panel-content"
                        expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="h4">Upload Price File</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FileUploader
                            id="file-uploader"
                            allowedFileExtensions={['.csv']}
                            uploadMode="useButtons"
                            visible={true}
                            uploadFile={uploadPriceFile}
                            onUploadError={customizeUploadError}
                        />
                    </AccordionDetails>
                </Accordion>

                <Accordion variant="outlined" style={{ marginBottom: '10px' }}>
                    <AccordionSummary
                        style={{ backgroundColor: "#eeeeee" }}
                        id="capacities-panel-header"
                        aria-controls="capacities-panel-content"
                        expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="h4">Upload Capacities File</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FileUploader
                            id="file-uploader"
                            allowedFileExtensions={['.csv']}
                            uploadMode="useButtons"
                            visible={true}
                            uploadFile={uploadCapacityFile}
                            onUploadError={customizeUploadError}
                        />
                    </AccordionDetails>
                </Accordion>
                <div id="imports-table">
                    <h2 style={{ ...flexBoxStyle, color: '#9F9F9F' }}>
                        Imports History
                    </h2>
                    <DataGrid
                        className={'dx-card wide-card'}
                        dataSource={imports}
                        showBorders={false}
                        keyExpr='id'
                        columnAutoWidth={true}
                        columnHidingEnabled={true}
                        onRowPrepared={onRowPrepared}>
                        <HeaderFilter visible={true} />
                        <Paging defaultPageSize={10} />
                        <Pager showPageSizeSelector={true} showInfo={true} />
                        <FilterRow visible={true} />
                        <Column
                            dataField={'status'}
                            caption={'Status'}
                            cellRender={renderStatusColumn}
                        />
                        <Column
                            dataField={'importType'}
                            caption={'Import Type'}
                        />
                        <Column
                            dataType="date"
                            dataField={'receivedDate'}
                            caption={'Upload Date'}
                            format='d MMM yyyy HH:mm:ss'
                        />
                        <Column
                            dataField={'fileName'}
                            caption={'File Name'}
                        />
                        <Column
                            dataField={'importedBy.userName'}
                            caption={'Imported By'}
                        />
                    </DataGrid>
                </div>
            </PageContainerFull>
        </>);
}
