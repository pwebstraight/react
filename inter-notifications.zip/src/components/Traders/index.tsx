import _ from "lodash"
import { ShipperService } from 'src/api/services/ShipperService';
import { useAppDispatch } from "src/store/configureStore";
import { loadShipperCash } from "src/store/shipperSlice";

import DataGrid, {
    Column,
    Editing,
    Paging,
    HeaderFilter,
    Button,
    RequiredRule,
    Selection
} from 'devextreme-react/data-grid';

const Traders = (prevProps) =>
{
    const dispatch = useAppDispatch();

    function onTraderRowUpdating(e)
    {
        let gridTrader = _.cloneDeep(e.oldData);
        const updatedProperties = Object.keys(e.newData);
        const updatedValues = Object.values(e.newData);

        updatedProperties.forEach(function (key, index)
        {
            gridTrader[key] = updatedValues[index];
        });

        let currentShipper = _.cloneDeep(prevProps.data.data);
        var currentIndex = currentShipper.traders.findIndex(t => t.id == gridTrader.id);
        currentShipper.traders[currentIndex] = gridTrader;
        saveShippers(currentShipper);
    }

    function onTraderRowInserting(e)
    {
        let gridTrader = _.cloneDeep(e.data);
        let currentShipper = _.cloneDeep(prevProps.data.data);
        currentShipper.traders.push(gridTrader)
        saveShippers(currentShipper);
    }

    async function saveShippers(shipper)
    {
        await ShipperService.postApiShipperSave(shipper);
        dispatch(loadShipperCash([]));
    }

    return (
        <DataGrid
            dataSource={prevProps.data.data.traders}
            keyExpr="id"
            showBorders={true}
            onRowUpdating={onTraderRowUpdating}
            onRowInserting={onTraderRowInserting}
        >
            <Selection mode="single" />
            <HeaderFilter visible={true} />
            <Paging enabled={false} />
            <Editing
                mode="row"
                useIcons={true}
                allowUpdating={true}
                allowAdding={true}
            />
            <Column dataField="firstName" caption="First Name" width={350} >
                <RequiredRule />
            </Column>
            <Column dataField="lastName" caption="LastName" width={250} >
                <RequiredRule />
            </Column>
            <Column dataField="email" caption="Email" width={250} >
                <RequiredRule />
            </Column>
            <Column dataField="postingId" caption="Posting Id" width={200} />
                
            <Column type="buttons" width={110}>
                <Button name="edit" />
            </Column>
        </DataGrid>
    );

}

export default Traders;
