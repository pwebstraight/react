import React, { useState } from 'react';
import DropDownBox from 'devextreme-react/drop-down-box';
import TreeView from 'devextreme-react/tree-view';
import _ from "lodash"

const PeriodFilter = (props) => {
  
  const {   
    period, 
    onTreeViewItemSelectionChanged,  
    onSyncTreeViewSelection,
    showAll,  
  } = props;

  const [treeBoxValue, setTreeBoxValue] = useState("1_1");
  const [isTreeBoxOpened, setIsTreeBoxOpened] = useState(false);
  const [periodRanges, setPeriodRanges] = useState([]);
    
  if (periodRanges.length == 0) {   
    let periods = _.cloneDeep(period);
    if (showAll) {
      periods.unshift({
        id: "0", name: "All", expanded: false
      })
    }
    setPeriodRanges(periods);
  }

  function treeViewItemSelectionChanged(e) {
    const selectedValue = e.component.getSelectedNodeKeys();
    
    if (selectedValue.length > 0) {      
      if (selectedValue[0].indexOf("-") > 0 || selectedValue == "0") {
        setTreeBoxValue(selectedValue);        
        onTreeViewItemSelectionChanged(selectedValue);
      } else {          
        alert("Please specify exact period.");
      }
    }
  }

  function syncTreeViewSelection(e) { 
    setTreeBoxValue(e.value);
    if (onSyncTreeViewSelection)
      onSyncTreeViewSelection(e.value);
  }

  function treeViewRender() {

    return (
      <TreeView dataSource={periodRanges}      
        selectedIndex={-1}              
        dataStructure="plain"
        keyExpr="id"
        parentIdExpr="categoryId"
        selectionMode="single"
        displayExpr="name"
        selectByClick={true}
        onContentReady={treeViewOnContentReady}
        onItemClick={onTreeItemClick}
        onItemSelectionChanged={treeViewItemSelectionChanged}
      />
    );
  }

  function onTreeItemClick() {
    
    setIsTreeBoxOpened(false);    
  }
  
  function onTreeBoxOpened(e) {
    
    if (e.name === 'opened') {      
      setIsTreeBoxOpened(e.value);      
    }
  }
  function  treeViewOnContentReady(e) {    
    e.component.selectItem(treeBoxValue);
  }

  return (
    <DropDownBox        
        value={treeBoxValue}
        opened={isTreeBoxOpened}
        valueExpr="id"
        displayExpr="name"
        placeholder="Select a value..."
        showClearButton={true}
        dataSource={periodRanges}
        onValueChanged={syncTreeViewSelection}
        onOptionChanged={onTreeBoxOpened}
        contentRender={treeViewRender}
        />
  );
}

export default PeriodFilter;