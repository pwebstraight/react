
import React, { useState, useEffect } from 'react';
import { useOktaAuth } from '@okta/okta-react';
import { toRelativeUrl } from '@okta/okta-auth-js';
import { Outlet } from 'react-router-dom';
import { useAppDispatch } from "src/store/configureStore";
import { User } from '../models/user';

export const RequiredAuth = () => {

 const { oktaAuth, authState } = useOktaAuth();
 
 if (!authState || !authState?.isAuthenticated) {
           
   const originalUri = toRelativeUrl(window.location.href, window.location.origin);
   
   oktaAuth.setOriginalUri(originalUri);
   oktaAuth.signInWithRedirect();

   return (<Loading />);
 } else {  
    
    let currentUser = localStorage.getItem("currentUser");      
    
     if (currentUser == null)
     {
      const newUser: User = {      
        userName: authState.idToken.claims.email,      
        token: authState.idToken.idToken 
      }    
      localStorage.setItem("currentUser", JSON.stringify(newUser));
    }    
    return (<Outlet />);
 } 
}

const Loading = () => {
    return (
      <h3 id='loading-icon'>Loading...</h3>
    );
  };