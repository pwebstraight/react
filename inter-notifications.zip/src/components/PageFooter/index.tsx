import { FC, ReactNode } from 'react';

interface PageFooterFullWrapperProps {
  children?: ReactNode;
}

const PageFooter: FC<PageFooterFullWrapperProps> = ({ children }) => {
  return (
    <div style={{backgroundColor: 'rgb(241, 244, 248)', height: '70px', marginTop: '1rem', padding: '1rem', position: 'fixed', bottom: '0', left: '200px', width: '100%'}}>         
        {children}         
    </div>
  )
};

export default PageFooter;
