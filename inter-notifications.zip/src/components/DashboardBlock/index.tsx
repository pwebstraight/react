import {    
    Card,
    Typography,    
    Box,    
    CardContent,    
  } from "@mui/material";

const DashboardBlock = (props) => {

    return (
        <Card style={{backgroundColor: props.color}}>
            <CardContent>
                <Box display="flex" alignItems="center">                
                <Typography
                    sx={{
                    ml: 1
                    }}
                    variant="body1"
                    color="text.secondary"
                    component="div"
                >
                    {props.title}
                </Typography>
                </Box>
                <Box
                display="flex"
                alignItems="center"
                sx={{
                    ml: -1.5,
                    py: 3,
                    justifyContent: 'center'
                }}
                >                
                    <Typography variant="h1" color="text.primary">
                        {props.quantity}
                    </Typography>
                </Box>
                <Typography
                align="center"
                variant="body2"
                color="text.secondary"
                component="div"
                >
                {props.description}
                </Typography>
                <Typography
                align="center"
                variant="body2"
                color="text.secondary"
                component="div"
                >
                {props.detailedDescription}                
                </Typography>
            </CardContent>
        </Card>

    );

}

export default DashboardBlock;
