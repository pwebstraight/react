import React, { useRef, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import ExpandMoreTwoToneIcon from '@mui/icons-material/ExpandMoreTwoTone';
import Chart from 'react-apexcharts';
import type { ApexOptions } from 'apexcharts';

import {
  Container,
  Grid,
  Button,
  Card,
  Typography,
  Divider,
  styled,
  CardActions,
  Menu,
  MenuItem,
  Box,
  CardHeader,
  CardContent,
  useTheme
} from "@mui/material";

const CardActionsWrapper = styled(CardActions)(
    ({ theme }) => `
        background-color: ${theme.colors.alpha.black[5]};
        padding: 0;
        display: block;
  `
  );

const DashboardLineChart = () => {

    const { t }: { t: any } = useTranslation();

    const periods = [
      {
        value: 'today',
        text: t('Today')
      },
      {
        value: 'yesterday',
        text: t('Yesterday')
      },
      {
        value: 'last_month',
        text: t('Last month')
      },
      {
        value: 'last_year',
        text: t('Last year')
      }
    ];
    const audiences = [
      {
        value: 'users',
        text: t('Total')
      },
      {
        value: 'new_users',
        text: t('UK to Belgium')
      },
      {
        value: 'page_views',
        text: t('Belgium to UK')
      },  
    ];
    
    const actionRef1 = useRef<any>(null);
    const actionRef2 = useRef<any>(null);
    const [openPeriod, setOpenMenuPeriod] = useState<boolean>(false);
    const [openAudience, setOpenMenuAudience] = useState<boolean>(false);
    const [period, setPeriod] = useState<string>(periods[3].text);
    const [audience, setAudience] = useState<string>(audiences[1].text);
    
    const theme = useTheme();

const ChartSparklineOptions: ApexOptions = {
  chart: {
    background: 'transparent',
    toolbar: {
      show: false
    },
    sparkline: {
      enabled: true
    },
    zoom: {
      enabled: false
    }
  },
  colors: [theme.colors.primary.main],
  dataLabels: {
    enabled: false
  },
  theme: {
    mode: theme.palette.mode
  },
  fill: {
    opacity: 1,
    colors: [theme.colors.primary.main],
    type: 'solid'
  },
  grid: {
    padding: {
      top: 2
    }
  },
  stroke: {
    show: true,
    colors: [theme.colors.primary.main],
    width: 2
  },
  legend: {
    show: false
  },
  labels: [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ],
  tooltip: {
    enabled: false
  },
  xaxis: {
    labels: {
      show: false
    },
    axisBorder: {
      show: false
    },
    axisTicks: {
      show: false
    }
  },
  yaxis: {
    show: false
  }
};

const ChartAudienceOptions: ApexOptions = {
  chart: {
    background: 'transparent',
    toolbar: {
      show: false
    },
    zoom: {
      enabled: false
    }
  },
  colors: [theme.colors.primary.main],
  labels: [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ],
  dataLabels: {
    enabled: false
  },
  fill: {
    opacity: 1
  },
  grid: {
    xaxis: {
      lines: {
        show: false
      }
    },
    yaxis: {
      lines: {
        show: true
      }
    },
    strokeDashArray: 5,
    borderColor: theme.colors.alpha.black[10]
  },
  legend: {
    show: false
  },
  markers: {
    hover: {
      sizeOffset: 2
    },
    shape: 'circle',
    size: 6,
    strokeWidth: 3,
    strokeOpacity: 1,
    strokeColors: [theme.colors.primary.main],
    colors: [theme.colors.alpha.white[100]]
  },
  stroke: {
    curve: 'smooth',
    lineCap: 'butt',
    width: 3
  },
  theme: {
    mode: theme.palette.mode
  },
  xaxis: {
    axisBorder: {
      show: false
    },
    axisTicks: {
      show: false
    },
    labels: {
      style: {
        colors: theme.palette.text.secondary
      }
    }
  },
  yaxis: {
    tickAmount: 3,
    axisBorder: {
      show: false
    },
    axisTicks: {
      show: false
    },
    labels: {
      style: {
        colors: theme.palette.text.secondary
      }
    }
  }
};

const data = {
  users: 14.586,
  newUsers: 12.847,
  pageViews: 67.492,
  avgSessionDuration: '00:05:21',
  bounceRate: '65.37%',
  sessions: 25.694
};

    return (
        <Grid item lg={11} sm={11} xs={12}>
            <Card>
                <CardHeader
                    action={
                    <>
                        <Button
                        size="small"
                        variant="outlined"
                        ref={actionRef1}
                        onClick={() => setOpenMenuPeriod(true)}
                        endIcon={<ExpandMoreTwoToneIcon fontSize="small" />}
                    >
                        {period}
                        </Button>
                    <Menu
                        disableScrollLock
                        anchorEl={actionRef1.current}
                        onClose={() => setOpenMenuPeriod(false)}
                        open={openPeriod}
                        anchorOrigin={{
                            vertical: 'bottom',
                            horizontal: 'right'
                        }}
                        transformOrigin={{
                            vertical: 'top',
                            horizontal: 'right'
                        }}
                    >
                    {periods.map((_period) => (
                        <MenuItem
                        key={_period.value}
                        onClick={() => {
                            setPeriod(_period.text);
                            setOpenMenuPeriod(false);
                        }}
                        >
                            {_period.text}
                        </MenuItem>
                    ))}
                    </Menu>
                </>
            }
                    title={t('Reserved Quantity')}
                />
                <Divider />
                <CardContent>
                    <Button
                    size="small"
                    variant="outlined"
                    ref={actionRef2}
                    onClick={() => setOpenMenuAudience(true)}
                    endIcon={<ExpandMoreTwoToneIcon fontSize="small" />}
                    >
                    Qty Value Type
                    </Button>
                    <Menu
                    disableScrollLock
                    anchorEl={actionRef2.current}
                    onClose={() => setOpenMenuAudience(false)}
                    open={openAudience}
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left'
                    }}
                    transformOrigin={{
                        vertical: 'top',
                        horizontal: 'left'
                    }}
                    >
                    {audiences.map((_audience) => (
                        <MenuItem
                        key={_audience.value}
                        onClick={() => {
                            setAudience(_audience.text);
                            setOpenMenuAudience(false);
                        }}
                        >
                        {_audience.text}
                        </MenuItem>
                    ))}
                    </Menu>
                    <Box mt={2}>
                    <Chart
                        options={ChartAudienceOptions}
                        series={[
                        {
                            name: 'New Users',
                            data: [
                            324, 315, 578, 576, 227, 459, 473, 282, 214, 623, 477, 401
                            ]
                        }
                        ]}
                        type="line"
                        height={230}
                    />
                    </Box>
                </CardContent>
                <Divider />
                <CardActionsWrapper>
                    <Box>
                    <Grid container alignItems="center">
                        <Grid
                        xs={12}
                        sm={6}
                        md={4}
                        item
                        sx={{
                            position: 'relative'
                        }}
                        >
                        <Box
                            component="span"
                            sx={{
                            display: { xs: 'none', sm: 'inline-block' }
                            }}
                        >
                            <Divider orientation="vertical" flexItem absolute />
                        </Box>
                        
                        
                        <Divider />
                        </Grid>
                        <Grid
                        xs={12}
                        sm={6}
                        md={4}
                        item
                        sx={{
                            position: 'relative'
                        }}
                        >
                        <Box
                            component="span"
                            sx={{
                            display: { xs: 'none', sm: 'inline-block' }
                            }}
                        >
                            <Divider orientation="vertical" flexItem absolute />
                        </Box>
                        
                        <Divider />
                        </Grid>
                        <Grid
                        xs={12}
                        sm={6}
                        md={4}
                        item
                        sx={{
                            position: 'relative'
                        }}
                        >
                        <Box
                            component="span"
                            sx={{
                            display: { xs: 'none', sm: 'inline-block' }
                            }}
                        >
                            <Divider orientation="vertical" flexItem absolute />
                        </Box>
                        
                        <Divider />
                        </Grid>
                        
                        
                    </Grid>
                    </Box>
                </CardActionsWrapper>
            </Card>
        </Grid>
    );

}

export default DashboardLineChart;